<?php
/**
 * 404 template.
 *
 * @package 123AV
 */

get_header();
?>
<main class="feed">
	<div class="wrap">
		<section class="section">
			<div class="section__head">
				<h1 class="section__title"><?php esc_html_e( 'Page not found', 'av123' ); ?></h1>
			</div>
			<p><?php esc_html_e( 'The page you requested could not be found.', 'av123' ); ?></p>
		</section>
	</div>
</main>
<?php
get_footer();

