# Changelog

## 1.6.0 — 2026-09-08

- Added a fallback actor taxonomy so `/actors/`, `/actres/`, single-video actor
  chips, related videos, and archive descriptions all recognize AURUM's own
  `aurum_video_actor` taxonomy whenever the legacy `video_actor` taxonomy
  (owned by a separate, unrelated plugin) is not registered on this site.
- Actor term editing (custom fields, save handler, admin media picker) now
  works identically on both actor taxonomies.
- The actor profile page now resolves its taxonomy and post types dynamically
  instead of assuming `video_actor` + CPT `video`, so it also works on sites
  whose real content model is `post` (e.g. production).
- Actor profile images now fall back to AURUM's external profile image URL
  when no Media Library attachment has been chosen for the term, so pushed
  actors show a photo without ever being re-uploaded into the Media Library.

## 1.5.2 — 2026-09-05

- Build video sitemap pagination from validated entries instead of raw published-post counts.
- Deduplicate watch pages that resolve to the same video media URL, preserving the oldest canonical post.
- Return HTTP 404 for video sitemap page numbers outside the generated inventory.

## 1.5.1 — 2026-09-05

- Refresh Rank Math's persisted sitemap index once after a theme version update so the custom video sitemap is discovered automatically.

## 1.5.0 — 2026-09-05

- Added one accessible homepage H1 and useful introductory copy.
- Added concise homepage/watch-page title filters while retaining Rank Math ownership.
- Added transparent adult-content metadata on explicit theme surfaces.
- Added a shared, provenance-aware video metadata resolver.
- Added duplicate-safe Rank Math `VideoObject` integration using only real metadata.
- Added a cached `/video-sitemap.xml` containing validated canonical watch pages.
- Added responsive fallback image dimensions and retained single-image LCP priority.
- Added taxonomy-related recommendations with latest-content fallback.
- Added deduplicated GA4/data-layer events for video progress and navigation actions.
- Added archive description rendering.
- Added a separate queued IndexNow mu-plugin with local-host submission protection.
- Aligned the theme runtime and stylesheet versions at 1.5.0.
