<?php
/**
 * Paginated video archive.
 *
 * @package 123AV
 */

get_header();
?>
<main class="feed av123-video-archive">
	<div class="wrap">
		<section class="section">
			<div class="section__head">
				<h1 class="section__title"><i aria-hidden="true"></i><?php post_type_archive_title(); ?></h1>
				<?php global $wp_query; ?>
				<span class="av123-video-archive__count"><?php printf( esc_html__( '%s videos', 'av123' ), esc_html( number_format_i18n( $wp_query->found_posts ) ) ); ?></span>
			</div>
			<?php if ( have_posts() ) : ?>
				<div class="grid">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'template-parts/content-card' ); ?>
					<?php endwhile; ?>
				</div>
				<?php
				the_posts_pagination(
					array(
						'mid_size'           => 2,
						'end_size'           => 1,
						'prev_text'          => __( 'Previous', 'av123' ),
						'next_text'          => __( 'Next', 'av123' ),
						'screen_reader_text' => __( 'Video archive pagination', 'av123' ),
					)
				);
				?>
			<?php else : ?>
				<p><?php esc_html_e( 'No videos found.', 'av123' ); ?></p>
			<?php endif; ?>
		</section>
	</div>
</main>
<?php
get_footer();
