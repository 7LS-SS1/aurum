<?php
/**
 * Archive fallback template.
 *
 * @package 123AV
 */

get_header();
?>
<main class="feed">
	<div class="wrap">
		<section class="section">
			<div class="section__head">
				<h1 class="section__title"><?php the_archive_title(); ?></h1>
			</div>
			<?php if ( av123_search_archive_intro() ) : ?>
				<div class="archive-description entry-content"><p><?php echo esc_html( av123_search_archive_intro() ); ?></p></div>
			<?php endif; ?>
			<?php if ( have_posts() ) : ?>
				<div class="grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content-card' );
					endwhile;
					?>
				</div>
				<?php the_posts_pagination(); ?>
			<?php else : ?>
				<p><?php esc_html_e( 'No posts found.', 'av123' ); ?></p>
			<?php endif; ?>
		</section>
	</div>
</main>
<?php
get_footer();
