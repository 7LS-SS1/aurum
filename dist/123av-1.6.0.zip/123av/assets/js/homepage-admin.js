(function ($) {
	'use strict';

	var $sections = $('[data-sections]');
	var nextIndex = Date.now();

	function updateConditionalFields(context) {
		$(context).find('[data-source-select]').each(function () {
			var source = $(this).val();
			var $scope = $(this).closest('.av123-section-card, .av123-admin-panel');
			$scope.find('[data-source-field]').hide();
			$scope.find('[data-source-field="' + source + '"]').show();
		});

		$(context).find('[data-heading-select]').each(function () {
			$(this).siblings('.av123-h1-warning').prop('hidden', $(this).val() !== 'h1');
		});
	}

	function syncBoostIds() {
		var ids = $('[data-boost-order] [data-boost-id]').map(function () {
			return $(this).attr('data-boost-id');
		}).get();
		$('[data-boost-ids]').val(ids.join(','));
	}

	function syncBoostOrderFromSelect() {
		var $select = $('[data-boost-select]');
		var selected = $select.val() || [];
		var $order = $('[data-boost-order]');

		$order.children('[data-boost-id]').each(function () {
			if (selected.indexOf($(this).attr('data-boost-id')) === -1) {
				$(this).remove();
			}
		});

		selected.forEach(function (id) {
			if ($order.children('[data-boost-id="' + id + '"]').length) {
				return;
			}
			var option = $select.find('option[value="' + id + '"]').get(0);
			var label = option ? option.textContent : '#' + id;
			$order.append('<li data-boost-id="' + id + '"><span class="dashicons dashicons-move" aria-hidden="true"></span><span></span><button type="button" class="button-link-delete" data-remove-boost>Remove</button></li>');
			$order.children().last().find('span').eq(1).text(label);
		});

		syncBoostIds();
	}

	function addSection(html) {
		var index = nextIndex++;
		var prepared = html.replace(/__INDEX__/g, index);
		$sections.append(prepared);
		var $card = $sections.children().last();
		$card.find('[data-section-id]').val('section-' + index);
		updateConditionalFields($card);
		$card.find('input[type="text"]').first().trigger('focus');
	}

	$sections.sortable({
		handle: '.av123-section-handle',
		items: '> [data-section-card]',
		axis: 'y'
	});

	$('[data-boost-order]').sortable({
		handle: '.dashicons-move',
		axis: 'y',
		update: syncBoostIds
	});

	$(document).on('change', '[data-source-select], [data-heading-select]', function () {
		updateConditionalFields($(this).closest('.av123-section-card, .av123-admin-panel'));
	});

	$(document).on('input', '[data-section-title]', function () {
		$(this).closest('[data-section-card]').find('[data-section-label]').text($(this).val() || 'Untitled section');
	});

	$('[data-add-section]').on('click', function () {
		var template = document.getElementById('av123-section-template');
		if (template) {
			addSection(template.innerHTML);
		}
	});

	$(document).on('click', '[data-remove-section]', function () {
		if (window.confirm('Delete this homepage section?')) {
			$(this).closest('[data-section-card]').remove();
		}
	});

	$(document).on('click', '[data-duplicate-section]', function () {
		var $original = $(this).closest('[data-section-card]');
		var oldName = ($original.find(':input[name*="[sections]"]').first().attr('name') || '').match(/\[sections\]\[([^\]]+)\]/);
		var index = nextIndex++;
		var html = $original.prop('outerHTML');
		if (oldName) {
			html = html.replace(new RegExp('\\[sections\\]\\[' + oldName[1] + '\\]', 'g'), '[sections][' + index + ']');
		}
		$original.after(html);
		var $clone = $original.next();
		$clone.find('[data-section-id]').val('section-' + index);
		$clone.find('[data-section-title]').val(($clone.find('[data-section-title]').val() || '') + ' copy').trigger('input');
		updateConditionalFields($clone);
	});

	$(document).on('click', '[data-move-up]', function () {
		var $card = $(this).closest('[data-section-card]');
		$card.prev('[data-section-card]').before($card);
	});

	$(document).on('click', '[data-move-down]', function () {
		var $card = $(this).closest('[data-section-card]');
		$card.next('[data-section-card]').after($card);
	});

	$('[data-boost-filter]').on('input', function () {
		var query = $(this).val().toLowerCase();
		$('[data-boost-select] option').each(function () {
			this.hidden = query && this.textContent.toLowerCase().indexOf(query) === -1;
		});
	});

	$('[data-boost-select]').on('change', syncBoostOrderFromSelect);

	$(document).on('click', '[data-remove-boost]', function () {
		var id = $(this).closest('[data-boost-id]').attr('data-boost-id');
		$('[data-boost-select] option[value="' + id + '"]').prop('selected', false);
		$(this).closest('[data-boost-id]').remove();
		syncBoostIds();
	});

	updateConditionalFields(document);
	syncBoostIds();
}(jQuery));
