(function () {
	'use strict';

	document.querySelectorAll('[data-av123-hero]').forEach(function (hero) {
		var viewport = hero.querySelector('[data-hero-viewport]');
		var slides = Array.prototype.slice.call(hero.querySelectorAll('[data-hero-slide]'));
		var dots = Array.prototype.slice.call(hero.querySelectorAll('[data-hero-dot]'));
		var previous = hero.querySelector('[data-hero-prev]');
		var next = hero.querySelector('[data-hero-next]');
		var active = 0;
		var ticking = false;

		if (!viewport || slides.length < 2) {
			return;
		}

		function setActive(index) {
			active = Math.max(0, Math.min(index, slides.length - 1));
			dots.forEach(function (dot, dotIndex) {
				dot.classList.toggle('is-active', dotIndex === active);
			});
		}

		function goTo(index) {
			if (index < 0) {
				index = slides.length - 1;
			} else if (index >= slides.length) {
				index = 0;
			}

			viewport.scrollTo({ left: slides[index].offsetLeft - viewport.offsetLeft, behavior: 'smooth' });
			setActive(index);
		}

		viewport.addEventListener('scroll', function () {
			if (ticking) {
				return;
			}
			ticking = true;
			window.requestAnimationFrame(function () {
				var nearest = 0;
				var distance = Number.POSITIVE_INFINITY;
				slides.forEach(function (slide, index) {
					var currentDistance = Math.abs(slide.offsetLeft - viewport.offsetLeft - viewport.scrollLeft);
					if (currentDistance < distance) {
						distance = currentDistance;
						nearest = index;
					}
				});
				setActive(nearest);
				ticking = false;
			});
		}, { passive: true });

		if (previous) {
			previous.addEventListener('click', function () { goTo(active - 1); });
		}

		if (next) {
			next.addEventListener('click', function () { goTo(active + 1); });
		}
	});
}());
