( function () {
	'use strict';

	var START_DELAY_MS = 150;

	function initialisePreview( poster ) {
		var previewUrl = poster.getAttribute( 'data-av123-preview' );
		var timer = null;
		var video = null;

		if ( ! previewUrl || ! window.matchMedia( '(hover: hover)' ).matches ) {
			return;
		}

		function getVideo() {
			if ( video ) {
				return video;
			}

			video = document.createElement( 'video' );
			video.className = 'av123-card__preview';
			video.src = previewUrl;
			video.muted = true;
			video.defaultMuted = true;
			video.loop = true;
			video.playsInline = true;
			video.preload = 'none';
			video.setAttribute( 'aria-hidden', 'true' );
			poster.appendChild( video );

			return video;
		}

		function start() {
			var preview = getVideo();
			poster.classList.add( 'is-previewing' );
			preview.play().catch( function () {} );
		}

		function stop() {
			window.clearTimeout( timer );
			if ( video ) {
				video.pause();
			}
			poster.classList.remove( 'is-previewing' );
		}

		poster.addEventListener( 'mouseenter', function () {
			timer = window.setTimeout( start, START_DELAY_MS );
		} );
		poster.addEventListener( 'mouseleave', stop );
	}

	function initialise() {
		document.querySelectorAll( '.av123-card__poster[data-av123-preview]' ).forEach( initialisePreview );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', initialise );
	} else {
		initialise();
	}
}() );
