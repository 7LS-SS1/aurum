(function () {
	'use strict';

	var drawer = document.querySelector('[data-av123-drawer]');
	var menuToggle = document.querySelector('[data-av123-menu-toggle]');
	var menuClosers = document.querySelectorAll('[data-av123-menu-close]');
	var searchToggle = document.querySelector('[data-av123-search-toggle]');
	var searchPanel = document.querySelector('[data-av123-search]');
	var header = document.querySelector('[data-av123-header]');

	function setMenu(open) {
		if (!drawer || !menuToggle) {
			return;
		}

		drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
		menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		document.body.classList.toggle('av123-menu-open', open);
	}

	if (menuToggle) {
		menuToggle.addEventListener('click', function () {
			setMenu(drawer && drawer.getAttribute('aria-hidden') === 'true');
		});
	}

	menuClosers.forEach(function (button) {
		button.addEventListener('click', function () {
			setMenu(false);
		});
	});

	if (searchToggle && searchPanel) {
		searchToggle.addEventListener('click', function () {
			var open = searchPanel.hasAttribute('hidden');
			searchPanel.toggleAttribute('hidden', !open);
			searchToggle.setAttribute('aria-expanded', open ? 'true' : 'false');

			if (open) {
				var field = searchPanel.querySelector('input[type="search"]');
				if (field) {
					field.focus();
				}
			}
		});
	}

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape') {
			setMenu(false);
			if (searchPanel && !searchPanel.hasAttribute('hidden')) {
				searchPanel.setAttribute('hidden', '');
				searchToggle.setAttribute('aria-expanded', 'false');
			}
		}
	});

	if (header) {
		window.addEventListener('scroll', function () {
			header.classList.toggle('is-stuck', window.scrollY > 10);
		}, { passive: true });
	}
}());
