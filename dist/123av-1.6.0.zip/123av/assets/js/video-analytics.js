(function () {
	'use strict';

	var config = window.AV123VideoAnalytics || {};
	var states = new WeakMap();

	function send(name, parameters) {
		var payload = Object.assign({
			content_id: String(config.contentId || ''),
			content_type: String(config.contentType || '')
		}, parameters || {});
		if (typeof window.gtag === 'function') {
			window.gtag('event', name, payload);
		} else {
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push(Object.assign({event: name}, payload));
		}
	}

	function stateFor(video) {
		var source = video.currentSrc || (video.querySelector('source') || {}).src || '';
		var state = states.get(video);
		if (!state || state.source !== source) {
			state = {source: source, started: false, completed: false, progress: {25: false, 50: false, 75: false}};
			states.set(video, state);
		}
		return state;
	}

	document.querySelectorAll('video[data-av123-video], [data-av123-player] video').forEach(function (video) {
		video.addEventListener('playing', function () {
			var state = stateFor(video);
			if (!state.started && video.currentTime > 0) {
				state.started = true;
				send('video_start', {player_type: 'html5', duration_bucket: isFinite(video.duration) ? Math.ceil(video.duration / 300) * 5 + 'm' : 'unknown'});
			}
		});
		video.addEventListener('timeupdate', function () {
			if (!isFinite(video.duration) || video.duration <= 0) { return; }
			var percent = video.currentTime / video.duration * 100;
			var state = stateFor(video);
			[25, 50, 75].forEach(function (mark) {
				if (percent >= mark && !state.progress[mark]) {
					state.progress[mark] = true;
					send('video_progress', {percent: mark});
				}
			});
			if (percent >= 95 && !state.completed) {
				state.completed = true;
				send('video_complete');
			}
		});
		video.addEventListener('ended', function () {
			var state = stateFor(video);
			if (!state.completed) { state.completed = true; send('video_complete'); }
		});
	});

	document.addEventListener('click', function (event) {
		var related = event.target.closest('[data-av123-related-link]');
		if (related) {
			send('select_related_video', {target_content_id: related.getAttribute('data-target-id') || '', relation_type: 'related'});
			return;
		}
		var actor = event.target.closest('[data-av123-actor-links] a');
		if (actor) { send('click_actor', {target_path: actor.pathname}); return; }
		var category = event.target.closest('[data-av123-category-links] a');
		if (category) { send('click_category', {target_path: category.pathname}); }
	});

	document.addEventListener('submit', function (event) {
		var form = event.target.closest('form[role="search"], form.search-form');
		if (!form) { return; }
		var input = form.querySelector('input[type="search"], input[name="s"]');
		var length = input ? String(input.value || '').trim().length : 0;
		if (length) { send('site_search', {search_term_length: Math.min(length, 200)}); }
	});
}());
