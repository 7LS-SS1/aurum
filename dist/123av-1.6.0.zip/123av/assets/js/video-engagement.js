(function () {
	'use strict';

	var config = window.AV123VideoEngagement || {};

	function likeVideo(button) {
		if (button.disabled || !config.ajaxUrl || !config.nonce) {
			return;
		}

		button.disabled = true;
		var payload = new URLSearchParams();
		payload.append('action', 'sevenls_vp_like_video');
		payload.append('nonce', config.nonce);
		payload.append('post_id', button.getAttribute('data-post-id') || '');

		fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
			body: payload.toString()
		})
			.then(function (response) { return response.json(); })
			.then(function (response) {
				if (response && response.success && response.data) {
					var counter = button.querySelector('[data-av123-like-count]');
					if (counter) {
						counter.textContent = String(response.data.count);
					}
					button.classList.add('is-liked');
				}
			})
			.finally(function () { button.disabled = false; });
	}

	function loadMoreRelated(button) {
		var grid = document.querySelector('[data-av123-related-grid]');
		if (button.disabled || !grid || !config.ajaxUrl || !config.relatedNonce) {
			return;
		}

		button.disabled = true;
		button.classList.add('is-loading');

		var exclude = Array.prototype.map.call(grid.querySelectorAll('[data-post-id]'), function (card) {
			return card.getAttribute('data-post-id');
		});

		var payload = new URLSearchParams();
		payload.append('action', 'av123_load_more_related');
		payload.append('nonce', config.relatedNonce);
		payload.append('post_id', button.getAttribute('data-post-id') || '');
		exclude.forEach(function (id) {
			payload.append('exclude[]', id);
		});

		fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
			body: payload.toString()
		})
			.then(function (response) { return response.json(); })
			.then(function (response) {
				if (response && response.success && response.data) {
					grid.insertAdjacentHTML('beforeend', response.data.html);
					if (!response.data.hasMore) {
						var wrap = button.closest('[data-av123-load-more-wrap]');
						if (wrap) {
							wrap.remove();
						}
					}
				}
			})
			.finally(function () {
				button.disabled = false;
				button.classList.remove('is-loading');
			});
	}

	document.addEventListener('click', function (event) {
		var likeButton = event.target.closest('[data-av123-like]');
		if (likeButton) {
			likeVideo(likeButton);
			return;
		}

		var loadMoreButton = event.target.closest('[data-av123-load-more]');
		if (loadMoreButton) {
			loadMoreRelated(loadMoreButton);
		}
	});
}());
