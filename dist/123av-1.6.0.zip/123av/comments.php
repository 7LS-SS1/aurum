<?php
/**
 * Native WordPress comments for video pages.
 *
 * @package 123AV
 */

if ( post_password_required() ) {
	return;
}
?>
<section id="comments" class="av123-comments">
	<h2>
		<?php
		printf(
			/* translators: %s: comment count. */
			esc_html__( 'Comments (%s)', 'av123' ),
			esc_html( number_format_i18n( get_comments_number() ) )
		);
		?>
	</h2>
	<?php if ( have_comments() ) : ?>
		<ol class="av123-comments__list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 42,
				)
			);
			?>
		</ol>
		<?php the_comments_pagination(); ?>
	<?php endif; ?>

	<?php if ( comments_open() ) : ?>
		<?php comment_form(); ?>
	<?php elseif ( ! have_comments() ) : ?>
		<p class="av123-comments__closed"><?php esc_html_e( 'Comments are closed.', 'av123' ); ?></p>
	<?php endif; ?>
</section>
