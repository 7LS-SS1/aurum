	<footer class="footer">
		<div class="wrap">
			<div class="footer__top">
				<div class="footer__brand">
					<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><b>123</b><span>AV</span><i></i></a>
					<?php if ( get_bloginfo( 'description' ) ) : ?>
						<p class="footer__tag"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
					<?php endif; ?>
				</div>
				<div class="footer__cols">
					<div class="footer__col">
						<h2><?php esc_html_e( 'Categories', 'av123' ); ?></h2>
						<ul>
							<?php
							$footer_categories = get_categories(
								array(
									'hide_empty' => true,
									'number'     => 8,
								)
							);
							foreach ( $footer_categories as $footer_category ) :
								?>
								<li><a href="<?php echo esc_url( get_category_link( $footer_category ) ); ?>"><?php echo esc_html( $footer_category->name ); ?></a></li>
							<?php endforeach; ?>
						</ul>
					</div>
					<div class="footer__col">
						<h2><?php esc_html_e( 'Links', 'av123' ); ?></h2>
						<?php
						wp_nav_menu(
							array(
								'theme_location' => 'footer',
								'container'      => false,
								'menu_class'     => 'av123-footer-menu',
								'fallback_cb'    => false,
								'depth'          => 1,
							)
						);
						?>
					</div>
				</div>
			</div>
			<div class="footer__bottom">
				<span class="footer__badge">18+</span>
				<span class="footer__note">&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
			</div>
		</div>
	</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
