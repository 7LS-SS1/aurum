<?php
/**
 * Dynamic homepage template.
 *
 * @package 123AV
 */

get_header();
av123_render_homepage();
get_footer();
