<?php
/**
 * Theme setup and assets.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AV123_VERSION', '1.6.0' );

require_once get_theme_file_path( 'inc/homepage-settings.php' );
require_once get_theme_file_path( 'inc/video-boost.php' );
require_once get_theme_file_path( 'inc/homepage-query.php' );
require_once get_theme_file_path( 'inc/homepage-render.php' );
require_once get_theme_file_path( 'inc/video-player.php' );
require_once get_theme_file_path( 'inc/directory-pages.php' );
require_once get_theme_file_path( 'inc/actor-profile.php' );
require_once get_theme_file_path( 'inc/theme-setup.php' );
require_once get_theme_file_path( 'inc/search-optimization.php' );

/**
 * Set up theme supports and menu locations.
 */
function av123_setup() {
	load_theme_textdomain( 'av123', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 240,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );

	add_image_size( 'av123-card', 640, 360, true );
	add_image_size( 'av123-hero', 1280, 720, true );

	register_nav_menus( array(
		'primary' => esc_html__( 'Primary Menu', 'av123' ),
		'footer'  => esc_html__( 'Footer Menu', 'av123' ),
	) );
}
add_action( 'after_setup_theme', 'av123_setup' );

/**
 * Get a cache-busting version from a theme file.
 *
 * @param string $relative_path Relative path inside the theme.
 * @return string
 */
function av123_asset_version( $relative_path ) {
	$file = get_theme_file_path( $relative_path );

	return file_exists( $file ) ? (string) filemtime( $file ) : AV123_VERSION;
}

/**
 * Enqueue original static assets through WordPress.
 */
function av123_enqueue_assets() {
	wp_enqueue_style(
		'av123-fonts',
		'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap',
		array(),
		null
	);

	wp_enqueue_style(
		'av123-app',
		get_theme_file_uri( 'assets/css/app.css' ),
		array( 'av123-fonts' ),
		av123_asset_version( 'assets/css/app.css' )
	);

	wp_enqueue_style(
		'av123-style',
		get_stylesheet_uri(),
		array( 'av123-app' ),
		av123_asset_version( 'style.css' )
	);

	wp_enqueue_script(
		'av123-theme',
		get_theme_file_uri( 'assets/js/theme.js' ),
		array(),
		av123_asset_version( 'assets/js/theme.js' ),
		true
	);

	if ( is_front_page() ) {
		wp_enqueue_style(
			'av123-homepage',
			get_theme_file_uri( 'assets/css/homepage.css' ),
			array( 'av123-app' ),
			av123_asset_version( 'assets/css/homepage.css' )
		);

		wp_enqueue_script(
			'av123-homepage',
			get_theme_file_uri( 'assets/js/homepage.js' ),
			array(),
			av123_asset_version( 'assets/js/homepage.js' ),
			true
		);
	}

	if ( is_page_template( array( 'template-categories.php', 'template-tags.php', 'template-actors.php' ) ) ) {
		wp_enqueue_style(
			'av123-directory',
			get_theme_file_uri( 'assets/css/directory.css' ),
			array( 'av123-style' ),
			av123_asset_version( 'assets/css/directory.css' )
		);
	}

	if ( av123_is_actor_profile_request() ) {
		wp_enqueue_style(
			'av123-actor-profile',
			get_theme_file_uri( 'assets/css/actor-profile.css' ),
			array( 'av123-style' ),
			av123_asset_version( 'assets/css/actor-profile.css' )
		);
	}

	if ( is_embed() ) {
		// This stylesheet forces html,body{height:100%;overflow:hidden} for a bare
		// full-bleed #player frame. It belongs only to the oEmbed response page —
		// loading it on regular singular pages breaks scrolling site-wide.
		wp_enqueue_style(
			'av123-plyr',
			get_theme_file_uri( 'assets/css/plyr.min.css' ),
			array( 'av123-app' ),
			av123_asset_version( 'assets/css/plyr.min.css' )
		);
		wp_enqueue_style(
			'av123-embed',
			get_theme_file_uri( 'assets/css/embed.css' ),
			array( 'av123-plyr' ),
			av123_asset_version( 'assets/css/embed.css' )
		);
	}

	if ( av123_is_video_singular() ) {
		wp_enqueue_style(
			'av123-single-video',
			get_theme_file_uri( 'assets/css/single-video.css' ),
			array( 'av123-style' ),
			av123_asset_version( 'assets/css/single-video.css' )
		);
		wp_enqueue_script(
			'av123-video-engagement',
			get_theme_file_uri( 'assets/js/video-engagement.js' ),
			array(),
			av123_asset_version( 'assets/js/video-engagement.js' ),
			true
		);
		wp_localize_script(
			'av123-video-engagement',
			'AV123VideoEngagement',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonce'        => wp_create_nonce( 'sevenls-vp-like-video' ),
				'relatedNonce' => wp_create_nonce( 'av123_related_videos' ),
			)
		);
	}
	wp_enqueue_script(
		'av123-video-analytics',
		get_theme_file_uri( 'assets/js/video-analytics.js' ),
		array(),
		av123_asset_version( 'assets/js/video-analytics.js' ),
		true
	);
	wp_localize_script(
		'av123-video-analytics',
		'AV123VideoAnalytics',
		array(
			'contentId'   => get_queried_object_id(),
			'contentType' => get_queried_object_id() ? get_post_type( get_queried_object_id() ) : '',
		)
	);

	wp_enqueue_script(
		'av123-app',
		get_theme_file_uri( 'assets/js/app.js' ),
		array(),
		av123_asset_version( 'assets/js/app.js' ),
		true
	);

	wp_enqueue_style(
		'av123-hover-preview',
		get_theme_file_uri( 'assets/css/hover-preview.css' ),
		array( 'av123-app' ),
		av123_asset_version( 'assets/css/hover-preview.css' )
	);

	wp_enqueue_script(
		'av123-hover-preview',
		get_theme_file_uri( 'assets/js/hover-preview.js' ),
		array( 'av123-app' ),
		av123_asset_version( 'assets/js/hover-preview.js' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'av123_enqueue_assets' );

/**
 * Load the original application bundle as an ES module.
 *
 * @param string $tag    Script tag.
 * @param string $handle Script handle.
 * @param string $src    Script source.
 * @return string
 */
function av123_script_loader_tag( $tag, $handle, $src ) {
	$module_handles = array( 'av123-app' );

	if ( in_array( $handle, $module_handles, true ) ) {
		return sprintf(
			'<script type="module" src="%s" defer></script>' . "\n",
			esc_url( $src )
		);
	}

	return $tag;
}
add_filter( 'script_loader_tag', 'av123_script_loader_tag', 10, 3 );

/** Use a stable page size for the video archive and preserve core paged vars. */
function av123_video_archive_query( $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_post_type_archive( 'video' ) ) {
		return;
	}

	$query->set( 'posts_per_page', 24 );
}
add_action( 'pre_get_posts', 'av123_video_archive_query' );

/** Use a stable page size for category and tag archives, independent of Settings → Reading. */
function av123_term_archive_query( $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! ( $query->is_category() || $query->is_tag() ) ) {
		return;
	}

	$query->set( 'posts_per_page', 20 );
}
add_action( 'pre_get_posts', 'av123_term_archive_query' );

/**
 * Render a safe internal fallback menu when no WordPress menu is assigned.
 *
 * @param array|object $args Menu arguments.
 */
function av123_primary_menu_fallback( $args = array() ) {
	$menu_class = is_object( $args ) && ! empty( $args->menu_class ) ? $args->menu_class : 'av123-menu';
	?>
	<ul class="<?php echo esc_attr( $menu_class ); ?>">
		<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'av123' ); ?></a></li>
		<?php
		$categories = get_categories(
			array(
				'hide_empty' => true,
				'number'     => 6,
			)
		);

		foreach ( $categories as $category ) :
			?>
			<li><a href="<?php echo esc_url( get_category_link( $category ) ); ?>"><?php echo esc_html( $category->name ); ?></a></li>
		<?php endforeach; ?>
	</ul>
	<?php
}
