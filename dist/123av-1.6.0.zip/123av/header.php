<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="app">
	<header class="header is-stuck" data-av123-header>
		<div class="header__inner">
			<button class="menu-toggle" type="button" aria-label="<?php esc_attr_e( 'Open menu', 'av123' ); ?>" aria-expanded="false" data-av123-menu-toggle>
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"></path></svg>
			</button>

			<div class="av123-brand">
				<?php if ( has_custom_logo() ) : ?>
					<?php the_custom_logo(); ?>
				<?php else : ?>
					<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><b>123</b><span>AV</span><i></i></a>
				<?php endif; ?>
			</div>

			<nav class="nav av123-primary-nav" aria-label="<?php esc_attr_e( 'Primary menu', 'av123' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'av123-menu',
						'fallback_cb'    => 'av123_primary_menu_fallback',
						'depth'          => 2,
					)
				);
				?>
			</nav>

			<div class="spacer"></div>
			<div class="header__actions">
				<button class="iconbtn" type="button" aria-label="<?php esc_attr_e( 'Search', 'av123' ); ?>" aria-expanded="false" data-av123-search-toggle>
					<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="M20 20l-4.2-4.2"></path></svg>
				</button>
			</div>
		</div>

		<div class="av123-header-search" hidden data-av123-search>
			<div class="wrap"><?php get_search_form(); ?></div>
		</div>
	</header>

	<div class="drawer" aria-hidden="true" data-av123-drawer>
		<button class="drawer__scrim" type="button" aria-label="<?php esc_attr_e( 'Close menu', 'av123' ); ?>" data-av123-menu-close></button>
		<aside class="drawer__panel" aria-label="<?php esc_attr_e( 'Mobile menu', 'av123' ); ?>">
			<div class="drawer__head">
				<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><b>123</b><span>AV</span><i></i></a>
				<button class="drawer__close" type="button" aria-label="<?php esc_attr_e( 'Close menu', 'av123' ); ?>" data-av123-menu-close>&times;</button>
			</div>
			<nav class="drawer__nav" aria-label="<?php esc_attr_e( 'Mobile menu', 'av123' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'av123-mobile-menu',
						'fallback_cb'    => 'av123_primary_menu_fallback',
						'depth'          => 2,
					)
				);
				?>
			</nav>
		</aside>
	</div>
