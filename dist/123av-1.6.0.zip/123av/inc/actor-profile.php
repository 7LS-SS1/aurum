<?php
/**
 * Actor profile data, editor fields, and the /actres/{actor}/ public route.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function av123_actor_profile_fields() {
	return array(
		'profile_image_id' => array( 'label' => __( 'Profile image', 'av123' ), 'type' => 'image' ),
		'age'              => array( 'label' => __( 'Age', 'av123' ), 'type' => 'number' ),
		'height'           => array( 'label' => __( 'Height (cm)', 'av123' ), 'type' => 'number' ),
		'weight'           => array( 'label' => __( 'Weight (kg)', 'av123' ), 'type' => 'number' ),
		'bust'             => array( 'label' => __( 'Bust (cm)', 'av123' ), 'type' => 'number' ),
		'waist'            => array( 'label' => __( 'Waist (cm)', 'av123' ), 'type' => 'number' ),
		'hips'             => array( 'label' => __( 'Hips (cm)', 'av123' ), 'type' => 'number' ),
		'bio'              => array( 'label' => __( 'Biography', 'av123' ), 'type' => 'textarea' ),
	);
}

function av123_actor_profile_meta( $term_id ) {
	$values = array();
	foreach ( av123_actor_profile_fields() as $key => $field ) {
		$values[ $key ] = get_term_meta( $term_id, '_av123_actor_' . $key, true );
	}
	return $values;
}

/** Actor taxonomy currently registered: the legacy plugin's `video_actor`, or AURUM's own `aurum_video_actor`. */
function av123_actor_profile_taxonomy() {
	return av123_directory_taxonomy( array( 'video_actor', 'aurum_video_actor' ) );
}

/**
 * Resolve a term's display image: an uploaded Media Library attachment first
 * (manually set in the term editor), otherwise AURUM's external profile
 * image URL (`_av123_actor_profile_image_url`, set by the actor push sync —
 * never re-uploaded here, per the "images are external URLs" contract).
 */
function av123_actor_profile_image_url( $term_id, $size = 'medium' ) {
	$attachment_id = get_term_meta( $term_id, '_av123_actor_profile_image_id', true );
	if ( $attachment_id ) {
		$url = wp_get_attachment_image_url( absint( $attachment_id ), $size );
		if ( $url ) {
			return $url;
		}
	}
	$external_url = get_term_meta( $term_id, '_av123_actor_profile_image_url', true );
	return is_string( $external_url ) ? $external_url : '';
}

function av123_actor_profile_fields_form( $term = null ) {
	$term_id = $term instanceof WP_Term ? $term->term_id : 0;
	$meta    = $term_id ? av123_actor_profile_meta( $term_id ) : array();
	foreach ( av123_actor_profile_fields() as $key => $field ) {
		$value = $meta[ $key ] ?? '';
		if ( 'image' === $field['type'] ) {
			// Falls back to AURUM's external profile image URL when no attachment
			// has been manually chosen here; the hidden field itself stays
			// attachment-only, so saving this form never touches that URL.
			$image = $value ? wp_get_attachment_image_url( absint( $value ), 'medium' ) : av123_actor_profile_image_url( $term_id );
			echo '<tr class="form-field av123-actor-image-field"><th><label>' . esc_html( $field['label'] ) . '</label></th><td><img class="av123-actor-image-preview" src="' . esc_url( $image ) . '" alt=""' . ( $image ? '' : ' hidden' ) . '><input class="av123-actor-image-id" type="hidden" name="av123_actor_' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '"><button type="button" class="button av123-actor-image-select">' . esc_html__( 'Choose image', 'av123' ) . '</button> <button type="button" class="button-link-delete av123-actor-image-remove"' . ( $image ? '' : ' hidden' ) . '>' . esc_html__( 'Remove image', 'av123' ) . '</button></td></tr>';
			continue;
		}
		if ( 'textarea' === $field['type'] ) {
			echo '<tr class="form-field"><th><label for="av123_actor_' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td><textarea name="av123_actor_' . esc_attr( $key ) . '" id="av123_actor_' . esc_attr( $key ) . '" rows="6" class="large-text">' . esc_textarea( $value ) . '</textarea></td></tr>';
			continue;
		}
		echo '<tr class="form-field"><th><label for="av123_actor_' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td><input type="number" min="0" step="0.1" name="av123_actor_' . esc_attr( $key ) . '" id="av123_actor_' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" class="small-text"></td></tr>';
	}
}
add_action( 'video_actor_edit_form_fields', 'av123_actor_profile_fields_form', 10, 1 );
add_action( 'aurum_video_actor_edit_form_fields', 'av123_actor_profile_fields_form', 10, 1 );

function av123_save_actor_profile_fields( $term_id ) {
	if ( ! current_user_can( 'manage_categories' ) ) {
		return;
	}
	foreach ( av123_actor_profile_fields() as $key => $field ) {
		$input = isset( $_POST[ 'av123_actor_' . $key ] ) ? wp_unslash( $_POST[ 'av123_actor_' . $key ] ) : '';
		$value = 'bio' === $key ? wp_kses_post( $input ) : ( 'image' === $field['type'] ? absint( $input ) : ( '' === $input ? '' : floatval( $input ) ) );
		if ( '' === $value || 0 === $value ) {
			delete_term_meta( $term_id, '_av123_actor_' . $key );
		} else {
			update_term_meta( $term_id, '_av123_actor_' . $key, $value );
		}
	}
}
add_action( 'edited_video_actor', 'av123_save_actor_profile_fields' );
add_action( 'edited_aurum_video_actor', 'av123_save_actor_profile_fields' );

function av123_actor_profile_admin_assets( $hook ) {
	$taxonomy = (string) ( $_GET['taxonomy'] ?? '' );
	if ( 'term.php' !== $hook || ! in_array( $taxonomy, array( 'video_actor', 'aurum_video_actor' ), true ) ) {
		return;
	}
	wp_enqueue_media();
	wp_add_inline_script( 'jquery', <<<'JS'
jQuery(function($){$(document).on('click','.av123-actor-image-select',function(e){e.preventDefault();var row=$(this).closest('td'),frame=wp.media({title:'Choose profile image',multiple:false,library:{type:'image'}});frame.on('select',function(){var a=frame.state().get('selection').first().toJSON();row.find('.av123-actor-image-id').val(a.id);row.find('.av123-actor-image-preview').attr('src',a.sizes.medium?a.sizes.medium.url:a.url).prop('hidden',false);row.find('.av123-actor-image-remove').prop('hidden',false);});frame.open();});$(document).on('click','.av123-actor-image-remove',function(e){e.preventDefault();var row=$(this).closest('td');row.find('.av123-actor-image-id').val('');row.find('.av123-actor-image-preview').attr('src','').prop('hidden',true);$(this).prop('hidden',true);});});
JS
	);
}
add_action( 'admin_enqueue_scripts', 'av123_actor_profile_admin_assets' );

function av123_register_actor_profile_route() {
	add_rewrite_rule( '^actres/?$', 'index.php?av123_actor_directory=1', 'top' );
	add_rewrite_rule( '^actres/([^/]+)/?$', 'index.php?av123_actor=$matches[1]', 'top' );
}
add_action( 'init', 'av123_register_actor_profile_route' );

function av123_actor_profile_query_var( $vars ) { $vars[] = 'av123_actor'; $vars[] = 'av123_actor_directory'; return $vars; }
add_filter( 'query_vars', 'av123_actor_profile_query_var' );

function av123_is_actor_profile_request() { return '' !== (string) get_query_var( 'av123_actor' ) || (bool) get_query_var( 'av123_actor_directory' ); }

function av123_actor_profile_template( $template ) {
	if ( get_query_var( 'av123_actor_directory' ) ) { return get_theme_file_path( 'template-actres-directory.php' ); }
	if ( get_query_var( 'av123_actor' ) ) { return get_theme_file_path( 'template-actres.php' ); }
	return $template;
}
add_filter( 'template_include', 'av123_actor_profile_template' );

function av123_actor_profile_term_link( $url, $term, $taxonomy ) {
	if ( in_array( $taxonomy, array( 'video_actor', 'aurum_video_actor' ), true ) ) { return home_url( user_trailingslashit( 'actres/' . $term->slug ) ); }
	return $url;
}
add_filter( 'term_link', 'av123_actor_profile_term_link', 10, 3 );

function av123_actor_profile_flush_rules() {
	if ( get_option( 'av123_actor_profile_rules_version' ) !== AV123_VERSION ) {
		flush_rewrite_rules( false );
		update_option( 'av123_actor_profile_rules_version', AV123_VERSION, false );
	}
}
add_action( 'init', 'av123_actor_profile_flush_rules', 99 );
