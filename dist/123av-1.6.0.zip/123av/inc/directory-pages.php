<?php
/**
 * Shared data helpers for category, tag and actor directory pages.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the first registered taxonomy from a preferred list.
 *
 * @param string[] $taxonomies Preferred taxonomy slugs.
 * @return string
 */
function av123_directory_taxonomy( $taxonomies ) {
	foreach ( (array) $taxonomies as $taxonomy ) {
		if ( taxonomy_exists( $taxonomy ) ) {
			return $taxonomy;
		}
	}

	return '';
}

/**
 * Return the display configuration for a directory page.
 *
 * @param string $directory Directory key.
 * @return array
 */
function av123_directory_config( $directory ) {
	$configs = array(
		'categories' => array(
			'key'            => 'categories',
			'taxonomies'     => array( 'video_category', 'category' ),
			'description'    => __( 'Browse every video category and jump directly to the clips you want to watch.', 'av123' ),
			'search_label'   => __( 'Search categories', 'av123' ),
			'empty_message'  => __( 'No categories matched your search.', 'av123' ),
			'per_page'       => 48,
		),
		'tags'       => array(
			'key'            => 'tags',
			'taxonomies'     => array( 'video_tag', 'post_tag' ),
			'description'    => __( 'Explore popular topics and discover videos through detailed tags.', 'av123' ),
			'search_label'   => __( 'Search tags', 'av123' ),
			'empty_message'  => __( 'No tags matched your search.', 'av123' ),
			'per_page'       => 60,
		),
		'actors'     => array(
			'key'            => 'actors',
			'taxonomies'     => array( 'video_actor', 'aurum_video_actor' ),
			'description'    => __( 'Find performers and open their complete video collections.', 'av123' ),
			'search_label'   => __( 'Search actors', 'av123' ),
			'empty_message'  => __( 'No actors matched your search.', 'av123' ),
			'per_page'       => 48,
		),
	);

	return isset( $configs[ $directory ] ) ? $configs[ $directory ] : array();
}

/**
 * Query a filtered and paginated set of terms for a directory page.
 *
 * @param array $config Directory configuration.
 * @return array
 */
function av123_directory_data( $config ) {
	$taxonomy = av123_directory_taxonomy( $config['taxonomies'] ?? array() );
	$search   = isset( $_GET['directory_search'] ) ? sanitize_text_field( wp_unslash( $_GET['directory_search'] ) ) : '';
	$sort     = isset( $_GET['directory_sort'] ) ? sanitize_key( wp_unslash( $_GET['directory_sort'] ) ) : 'popular';
	$sort     = in_array( $sort, array( 'popular', 'name' ), true ) ? $sort : 'popular';
	$per_page = max( 1, min( 100, absint( $config['per_page'] ?? 48 ) ) );
	$page     = isset( $_GET['directory_page'] ) ? max( 1, absint( $_GET['directory_page'] ) ) : 1;

	$result = array(
		'taxonomy'    => $taxonomy,
		'terms'       => array(),
		'search'      => $search,
		'sort'        => $sort,
		'page'        => $page,
		'per_page'    => $per_page,
		'total'       => 0,
		'total_pages' => 0,
		'range_start' => 0,
		'range_end'   => 0,
		'error'       => null,
	);

	if ( ! $taxonomy ) {
		return $result;
	}

	$base_args = array(
		'taxonomy'   => $taxonomy,
		'hide_empty' => true,
	);

	if ( '' !== $search ) {
		$base_args['search'] = $search;
	}

	$count_args           = $base_args;
	$count_args['fields'] = 'ids';
	$term_ids             = get_terms( $count_args );

	if ( is_wp_error( $term_ids ) ) {
		$result['error'] = $term_ids;
		return $result;
	}

	$result['total']       = count( $term_ids );
	$result['total_pages'] = $result['total'] ? (int) ceil( $result['total'] / $per_page ) : 0;

	if ( $result['total_pages'] && $page > $result['total_pages'] ) {
		$page           = $result['total_pages'];
		$result['page'] = $page;
	}

	$query_args = array_merge(
		$base_args,
		array(
			'number'  => $per_page,
			'offset'  => ( $page - 1 ) * $per_page,
			'orderby' => 'name' === $sort ? 'name' : 'count',
			'order'   => 'name' === $sort ? 'ASC' : 'DESC',
		)
	);
	$terms      = get_terms( $query_args );

	if ( is_wp_error( $terms ) ) {
		$result['error'] = $terms;
		return $result;
	}

	$result['terms']       = $terms;
	$result['range_start'] = $result['total'] ? ( ( $page - 1 ) * $per_page ) + 1 : 0;
	$result['range_end']   = $result['total'] ? min( $result['total'], $result['range_start'] + count( $terms ) - 1 ) : 0;

	return $result;
}
