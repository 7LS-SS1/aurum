<?php
/**
 * Homepage content queries and media helpers.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve enabled public content types.
 *
 * @param array|null $settings Homepage settings.
 * @return string[]
 */
function av123_homepage_content_types( $settings = null ) {
	$settings = is_array( $settings ) ? $settings : av123_get_homepage_settings();
	$wanted   = isset( $settings['content_types'] ) && is_array( $settings['content_types'] ) ? $settings['content_types'] : array( 'post', 'video' );
	$public   = get_post_types( array( 'public' => true ), 'names' );
	$types    = array_values( array_intersect( array_map( 'sanitize_key', $wanted ), $public ) );

	if ( empty( $types ) ) {
		$types = array( 'post' );
	}

	return array_values( array_unique( apply_filters( 'av123_homepage_content_types', $types, $settings ) ) );
}

/**
 * Build safe query arguments for a homepage source.
 *
 * @param array $config      Source configuration.
 * @param int[] $exclude_ids IDs already rendered.
 * @param array $settings    Homepage settings.
 * @return array
 */
function av123_homepage_query_args( $config, $exclude_ids, $settings ) {
	$source = isset( $config['source_type'] ) ? sanitize_key( $config['source_type'] ) : 'latest';
	$count  = av123_homepage_int_range( $config['count'] ?? 12, 1, 48, 12 );
	$args   = array(
		'post_type'              => av123_homepage_content_types( $settings ),
		'post_status'            => 'publish',
		'posts_per_page'         => $count,
		'orderby'                => 'date',
		'order'                  => 'DESC',
		'ignore_sticky_posts'    => true,
		'no_found_rows'          => true,
		'post__not_in'           => array_values( array_unique( array_map( 'absint', $exclude_ids ) ) ),
		'update_post_term_cache' => true,
		'update_post_meta_cache' => true,
	);

	if ( in_array( $source, array( 'category', 'tag' ), true ) ) {
		$term_id  = absint( $config['term_id'] ?? 0 );
		$taxonomy = 'category' === $source ? 'category' : 'post_tag';

		if ( $term_id && term_exists( $term_id, $taxonomy ) ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => $taxonomy,
					'field'    => 'term_id',
					'terms'    => array( $term_id ),
				),
			);
		} else {
			$args['post__in'] = array( 0 );
		}
	} elseif ( 'manual' === $source ) {
		$ids = av123_homepage_sanitize_ids( $config['manual_ids'] ?? array() );
		$ids = array_values( array_diff( $ids, $args['post__not_in'] ) );
		$args['post__in']       = $ids ? $ids : array( 0 );
		$args['orderby']        = 'post__in';
		$args['posts_per_page'] = min( $count, max( 1, count( $ids ) ) );
	}

	return apply_filters( 'av123_homepage_query_args', $args, $config, $exclude_ids, $settings );
}

/**
 * Query posts for a source and return post objects.
 *
 * @param array $config      Source configuration.
 * @param int[] $exclude_ids IDs already rendered.
 * @param array $settings    Homepage settings.
 * @return WP_Post[]
 */
function av123_homepage_get_posts( $config, $exclude_ids, $settings ) {
	$query = new WP_Query( av123_homepage_query_args( $config, $exclude_ids, $settings ) );

	return $query->posts;
}

/**
 * Query posts for the hero source.
 *
 * @param array $settings Homepage settings.
 * @param int[] $exclude_ids IDs already rendered.
 * @return WP_Post[]
 */
function av123_homepage_get_hero_posts( $settings, $exclude_ids = array() ) {
	$hero  = $settings['hero'];
	$count = av123_homepage_int_range( $hero['count'] ?? 10, 1, 20, 10 );

	return av123_homepage_get_posts( $hero, $exclude_ids, $settings );
}

/**
 * Resolve a section's View More URL.
 *
 * @param array $section  Section settings.
 * @param array $settings Homepage settings.
 * @return string
 */
function av123_homepage_section_link( $section, $settings ) {
	if ( empty( $section['show_more'] ) || 'none' === $section['more_link_mode'] ) {
		return '';
	}

	if ( 'custom' === $section['more_link_mode'] ) {
		return esc_url_raw( $section['custom_url'] ?? '' );
	}

	$source  = $section['source_type'] ?? 'latest';
	$term_id = absint( $section['term_id'] ?? 0 );

	if ( 'category' === $source && $term_id ) {
		$link = get_category_link( $term_id );
		return is_wp_error( $link ) ? '' : $link;
	}

	if ( 'tag' === $source && $term_id ) {
		$link = get_tag_link( $term_id );
		return is_wp_error( $link ) ? '' : $link;
	}

	$types = av123_homepage_content_types( $settings );
	if ( 1 === count( $types ) && 'post' !== $types[0] ) {
		$link = get_post_type_archive_link( $types[0] );
		return $link ? $link : '';
	}

	$page_for_posts = absint( get_option( 'page_for_posts' ) );
	if ( $page_for_posts && ! is_front_page() ) {
		return get_permalink( $page_for_posts );
	}

	return '';
}

/**
 * Resolve a thumbnail URL when no featured image exists.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function av123_homepage_fallback_thumbnail_url( $post_id ) {
	$url = '';

	foreach ( array( '_sevenls_vp_thumbnail_url', 'aurum_thumbnail_url', 'thumbnail_url', 'thumb', 'thumbnail', 'poster', 'image' ) as $meta_key ) {
		$candidate = trim( (string) get_post_meta( $post_id, $meta_key, true ) );
		if ( $candidate && wp_http_validate_url( $candidate ) ) {
			$url = $candidate;
			break;
		}
	}

	if ( ! $url ) {
		$url = get_theme_file_uri( 'assets/images/video-placeholder.svg' );
	}

	return apply_filters( 'av123_homepage_thumbnail_url', $url, $post_id );
}

/**
 * Resolve an AURUM-compatible hover preview URL for a video card.
 *
 * The canonical AURUM field is checked first, followed by its legacy alias.
 * Only HTTP(S) URLs are exposed to the browser.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function av123_homepage_preview_url( $post_id ) {
	$url = '';

	foreach ( array( 'aurum_preview_url', 'preview_url' ) as $meta_key ) {
		$candidate = trim( (string) get_post_meta( $post_id, $meta_key, true ) );
		if ( $candidate && wp_http_validate_url( $candidate ) ) {
			$url = $candidate;
			break;
		}
	}

	return apply_filters( 'av123_homepage_preview_url', $url, $post_id );
}

/**
 * Return a responsive image tag for a post.
 *
 * @param int    $post_id Post ID.
 * @param string $size    Registered image size.
 * @param string $class   CSS class.
 * @param bool   $eager   Whether to load eagerly.
 * @return string
 */
function av123_homepage_image_html( $post_id, $size, $class, $eager = false ) {
	$thumbnail_id = get_post_thumbnail_id( $post_id );
	$alt          = '';

	if ( $thumbnail_id ) {
		$alt = trim( (string) get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true ) );
	}

	if ( ! $alt ) {
		$alt = get_the_title( $post_id );
	}

	$attributes = array(
		'class'    => $class,
		'alt'      => $alt,
		'decoding' => 'async',
		'loading'  => $eager ? 'eager' : 'lazy',
	);

	if ( $eager ) {
		$attributes['fetchpriority'] = 'high';
	}

	if ( $thumbnail_id ) {
		return wp_get_attachment_image( $thumbnail_id, $size, false, $attributes );
	}

	return sprintf(
		'<img class="%1$s" src="%2$s" alt="%3$s" width="%6$d" height="%7$d" loading="%4$s" decoding="async"%5$s>',
		esc_attr( $class ),
		esc_url( av123_homepage_fallback_thumbnail_url( $post_id ) ),
		esc_attr( $alt ),
		$eager ? 'eager' : 'lazy',
		$eager ? ' fetchpriority="high"' : '',
		'av123-hero' === $size ? 1280 : 640,
		'av123-hero' === $size ? 720 : 360
	);
}

/**
 * Return a display-ready video duration from supported metadata.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function av123_homepage_duration( $post_id ) {
	$value = '';

	foreach ( array( '_sevenls_vp_duration', 'aurum_duration', 'video_duration', 'duration' ) as $meta_key ) {
		$candidate = get_post_meta( $post_id, $meta_key, true );
		if ( '' !== $candidate && null !== $candidate ) {
			$value = $candidate;
			break;
		}
	}

	if ( is_numeric( $value ) ) {
		$seconds = absint( $value );
		if ( 0 === $seconds ) {
			return '';
		}
		$hours   = floor( $seconds / 3600 );
		$minutes = floor( ( $seconds % 3600 ) / 60 );
		$seconds = $seconds % 60;

		return $hours ? sprintf( '%d:%02d:%02d', $hours, $minutes, $seconds ) : sprintf( '%d:%02d', $minutes, $seconds );
	}

	$value = sanitize_text_field( (string) $value );

	return preg_match( '/^\d{1,3}:\d{2}(?::\d{2})?$/', $value ) ? $value : '';
}
