<?php
/**
 * Dynamic homepage renderer.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Render the complete homepage. */
function av123_render_homepage() {
	$settings = apply_filters( 'av123_homepage_settings', av123_get_homepage_settings() );
	$seen     = array();
	?>
	<main class="feed av123-home">
		<div class="wrap">
			<header class="av123-home__intro">
				<h1><?php esc_html_e( 'หนัง AV ซับไทยและคลิป OnlyFans อัปเดตล่าสุด', 'av123' ); ?></h1>
				<p><?php esc_html_e( 'ค้นหาวิดีโอตามรหัสเรื่อง นักแสดง และหมวดหมู่ พร้อมรายการอัปเดตล่าสุดที่เปิดดูได้บนมือถือและเดสก์ท็อป', 'av123' ); ?></p>
			</header>
			<?php
			if ( ! empty( $settings['hero']['enabled'] ) ) {
				$hero_posts = av123_homepage_get_hero_posts( $settings, $seen );

				if ( $hero_posts ) {
					get_template_part(
						'template-parts/home/hero',
						null,
						array(
							'posts'       => $hero_posts,
							'title'       => __( 'Featured videos', 'av123' ),
							'heading_tag' => 'h2',
						)
					);

					if ( ! empty( $settings['deduplicate'] ) ) {
						$seen = array_merge( $seen, wp_list_pluck( $hero_posts, 'ID' ) );
					}
				}
			}

			foreach ( $settings['sections'] as $section ) {
				if ( empty( $section['enabled'] ) ) {
					continue;
				}

				$exclude = ! empty( $settings['deduplicate'] ) ? $seen : array();
				$posts   = av123_homepage_get_posts( $section, $exclude, $settings );

				if ( empty( $posts ) ) {
					continue;
				}

				get_template_part(
					'template-parts/home/section',
					null,
					array(
						'section' => $section,
						'posts'   => $posts,
						'link'    => av123_homepage_section_link( $section, $settings ),
					)
				);

				if ( ! empty( $settings['deduplicate'] ) ) {
					$seen = array_merge( $seen, wp_list_pluck( $posts, 'ID' ) );
				}
			}

			av123_render_front_page_content();
			?>
		</div>
	</main>
	<?php
}

/** Render assigned static front-page content after dynamic sections. */
function av123_render_front_page_content() {
	$page_id = get_queried_object_id();

	if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) {
		return;
	}

	$content = (string) get_post_field( 'post_content', $page_id );

	if ( '' === trim( $content ) ) {
		return;
	}
	?>
	<section class="section av123-home__page-content">
		<div class="entry-content"><?php echo apply_filters( 'the_content', $content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
	</section>
	<?php
}
