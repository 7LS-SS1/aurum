<?php
/**
 * Homepage settings, sanitization and admin screen.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AV123_HOMEPAGE_OPTION', 'av123_homepage_settings' );
define( 'AV123_HOMEPAGE_PAGE', 'av123-homepage' );

/**
 * Default settings used before the first admin save.
 *
 * @return array
 */
function av123_homepage_defaults() {
	return array(
		'schema_version' => 2,
		'content_types'  => array( 'post', 'video' ),
		'deduplicate'    => 1,
		'hero'           => array(
			'enabled'     => 1,
			'source_type' => 'latest',
			'term_id'     => 0,
			'count'       => 10,
		),
		'boost'          => array(
			'enabled'           => 0,
			'interval'          => 'hourly',
			'target_count'      => 20,
			'views_min'         => 10,
			'views_max'         => 50,
			'likes_min'         => 1,
			'likes_max'         => 5,
			'comments_min'      => 0,
			'comments_max'      => 1,
			'comment_authors'   => "ผู้ชม\nสมาชิก",
			'comment_templates' => "ขอบคุณสำหรับคลิป\nชอบคลิปนี้",
		),
		'sections'       => array(
			array(
				'id'              => 'latest-videos',
				'enabled'         => 1,
				'title'           => __( 'Latest videos', 'av123' ),
				'heading_tag'     => 'h2',
				'source_type'     => 'latest',
				'term_id'         => 0,
				'manual_ids'      => array(),
				'count'           => 12,
				'show_more'       => 0,
				'more_label'      => __( 'View more', 'av123' ),
				'more_link_mode'  => 'automatic',
				'custom_url'      => '',
				'columns_desktop' => 4,
				'columns_tablet'  => 3,
				'columns_mobile'  => 2,
			),
		),
	);
}

/**
 * Return saved settings merged with current defaults.
 *
 * @return array
 */
function av123_get_homepage_settings() {
	$defaults = av123_homepage_defaults();
	$saved    = get_option( AV123_HOMEPAGE_OPTION, array() );

	if ( ! is_array( $saved ) ) {
		return $defaults;
	}

	// Release 1.1 used "boost" as a featured-video list. Do not carry those
	// values into the engagement automation introduced by schema version 2.
	if ( absint( $saved['schema_version'] ?? 0 ) < 2 ) {
		$saved['schema_version'] = 2;
		$saved['boost']          = $defaults['boost'];
		if ( 'boost' === ( $saved['hero']['source_type'] ?? '' ) ) {
			$saved['hero']['source_type'] = 'latest';
		}
	}

	$settings                  = array_merge( $defaults, $saved );
	$settings['hero']          = array_merge( $defaults['hero'], isset( $saved['hero'] ) && is_array( $saved['hero'] ) ? $saved['hero'] : array() );
	$settings['boost']         = array_merge( $defaults['boost'], isset( $saved['boost'] ) && is_array( $saved['boost'] ) ? $saved['boost'] : array() );
	$settings['sections']      = isset( $saved['sections'] ) && is_array( $saved['sections'] ) ? $saved['sections'] : $defaults['sections'];
	$settings['content_types'] = isset( $saved['content_types'] ) && is_array( $saved['content_types'] ) ? $saved['content_types'] : $defaults['content_types'];

	return $settings;
}

/**
 * Constrain an integer to a known range.
 *
 * @param mixed $value Value to constrain.
 * @param int   $min   Minimum.
 * @param int   $max   Maximum.
 * @param int   $fallback Fallback.
 * @return int
 */
function av123_homepage_int_range( $value, $min, $max, $fallback ) {
	$value = absint( $value );

	if ( $value < $min || $value > $max ) {
		return $fallback;
	}

	return $value;
}

/**
 * Sanitize a comma-separated or array list of post IDs.
 *
 * @param mixed $value Raw value.
 * @return int[]
 */
function av123_homepage_sanitize_ids( $value ) {
	if ( is_string( $value ) ) {
		$value = preg_split( '/[\s,]+/', $value );
	}

	if ( ! is_array( $value ) ) {
		return array();
	}

	$ids = array_values( array_unique( array_filter( array_map( 'absint', $value ) ) ) );

	return array_slice( $ids, 0, 200 );
}

/**
 * Sanitize the complete homepage option.
 *
 * @param mixed $input Raw settings.
 * @return array
 */
function av123_sanitize_homepage_settings( $input ) {
	$defaults = av123_homepage_defaults();
	$input    = is_array( $input ) ? $input : array();
	$output   = $defaults;

	$public_types = get_post_types( array( 'public' => true ), 'names' );
	$types        = isset( $input['content_types'] ) && is_array( $input['content_types'] ) ? array_map( 'sanitize_key', $input['content_types'] ) : array();
	$types        = array_values( array_intersect( $types, $public_types ) );

	if ( empty( $types ) ) {
		$types = array( 'post' );
	}

	$output['schema_version'] = 2;
	$output['content_types']  = array_values( array_unique( $types ) );
	$output['deduplicate']    = empty( $input['deduplicate'] ) ? 0 : 1;

	$hero_sources = array( 'latest', 'category', 'tag' );
	$hero_input   = isset( $input['hero'] ) && is_array( $input['hero'] ) ? $input['hero'] : array();
	$hero_source  = isset( $hero_input['source_type'] ) ? sanitize_key( $hero_input['source_type'] ) : $defaults['hero']['source_type'];
	$hero_source  = in_array( $hero_source, $hero_sources, true ) ? $hero_source : 'latest';
	$hero_term    = 0;

	if ( 'category' === $hero_source ) {
		$hero_term = isset( $hero_input['category_id'] ) ? absint( $hero_input['category_id'] ) : absint( $hero_input['term_id'] ?? 0 );
	} elseif ( 'tag' === $hero_source ) {
		$hero_term = isset( $hero_input['tag_id'] ) ? absint( $hero_input['tag_id'] ) : absint( $hero_input['term_id'] ?? 0 );
	}

	$output['hero'] = array(
		'enabled'     => empty( $hero_input['enabled'] ) ? 0 : 1,
		'source_type' => $hero_source,
		'term_id'     => $hero_term,
		'count'       => av123_homepage_int_range( $hero_input['count'] ?? 10, 1, 20, 10 ),
	);

	$boost_input   = isset( $input['boost'] ) && is_array( $input['boost'] ) ? $input['boost'] : array();
	$allowed_heads = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' );
	$intervals     = array( 'av123_fifteen_minutes', 'hourly', 'twicedaily', 'daily' );
	$interval      = sanitize_key( $boost_input['interval'] ?? $defaults['boost']['interval'] );
	$interval      = in_array( $interval, $intervals, true ) ? $interval : 'hourly';
	$views_min     = min( 10000, absint( $boost_input['views_min'] ?? $defaults['boost']['views_min'] ) );
	$views_max     = min( 10000, absint( $boost_input['views_max'] ?? $defaults['boost']['views_max'] ) );
	$likes_min     = min( 1000, absint( $boost_input['likes_min'] ?? $defaults['boost']['likes_min'] ) );
	$likes_max     = min( 1000, absint( $boost_input['likes_max'] ?? $defaults['boost']['likes_max'] ) );
	$comments_min  = min( 5, absint( $boost_input['comments_min'] ?? $defaults['boost']['comments_min'] ) );
	$comments_max  = min( 5, absint( $boost_input['comments_max'] ?? $defaults['boost']['comments_max'] ) );

	$output['boost'] = array(
		'enabled'           => empty( $boost_input['enabled'] ) ? 0 : 1,
		'interval'          => $interval,
		'target_count'      => av123_homepage_int_range( $boost_input['target_count'] ?? 20, 1, 100, 20 ),
		'views_min'         => min( $views_min, $views_max ),
		'views_max'         => max( $views_min, $views_max ),
		'likes_min'         => min( $likes_min, $likes_max ),
		'likes_max'         => max( $likes_min, $likes_max ),
		'comments_min'      => min( $comments_min, $comments_max ),
		'comments_max'      => max( $comments_min, $comments_max ),
		'comment_authors'   => av123_video_boost_sanitize_lines( $boost_input['comment_authors'] ?? $defaults['boost']['comment_authors'], 50, 80 ),
		'comment_templates' => av123_video_boost_sanitize_lines( $boost_input['comment_templates'] ?? $defaults['boost']['comment_templates'], 100, 500 ),
	);

	$output['sections'] = array();
	$section_input      = isset( $input['sections'] ) && is_array( $input['sections'] ) ? array_slice( $input['sections'], 0, 30 ) : array();
	$seen_ids           = array();
	$allowed_sources    = array( 'latest', 'category', 'tag', 'manual' );
	$allowed_link_modes = array( 'automatic', 'custom', 'none' );

	foreach ( $section_input as $position => $section ) {
		if ( ! is_array( $section ) ) {
			continue;
		}

		$source = isset( $section['source_type'] ) ? sanitize_key( $section['source_type'] ) : 'latest';
		$source = in_array( $source, $allowed_sources, true ) ? $source : 'latest';
		$term   = 0;

		if ( 'category' === $source ) {
			$term = isset( $section['category_id'] ) ? absint( $section['category_id'] ) : absint( $section['term_id'] ?? 0 );
		} elseif ( 'tag' === $source ) {
			$term = isset( $section['tag_id'] ) ? absint( $section['tag_id'] ) : absint( $section['term_id'] ?? 0 );
		}

		$heading = isset( $section['heading_tag'] ) ? strtolower( sanitize_key( $section['heading_tag'] ) ) : 'h2';
		$heading = in_array( $heading, $allowed_heads, true ) ? $heading : 'h2';
		$id      = isset( $section['id'] ) ? sanitize_title( $section['id'] ) : '';

		if ( '' === $id ) {
			$id = 'section-' . ( $position + 1 );
		}

		$base_id = $id;
		$suffix  = 2;
		while ( in_array( $id, $seen_ids, true ) ) {
			$id = $base_id . '-' . $suffix;
			++$suffix;
		}
		$seen_ids[] = $id;

		$link_mode = isset( $section['more_link_mode'] ) ? sanitize_key( $section['more_link_mode'] ) : 'automatic';
		$link_mode = in_array( $link_mode, $allowed_link_modes, true ) ? $link_mode : 'automatic';

		$output['sections'][] = array(
			'id'              => $id,
			'enabled'         => empty( $section['enabled'] ) ? 0 : 1,
			'title'           => sanitize_text_field( $section['title'] ?? '' ),
			'heading_tag'     => $heading,
			'source_type'     => $source,
			'term_id'         => $term,
			'manual_ids'      => av123_homepage_sanitize_ids( $section['manual_ids'] ?? array() ),
			'count'           => av123_homepage_int_range( $section['count'] ?? 12, 1, 48, 12 ),
			'show_more'       => empty( $section['show_more'] ) ? 0 : 1,
			'more_label'      => sanitize_text_field( $section['more_label'] ?? __( 'View more', 'av123' ) ),
			'more_link_mode'  => $link_mode,
			'custom_url'      => esc_url_raw( $section['custom_url'] ?? '' ),
			'columns_desktop' => av123_homepage_int_range( $section['columns_desktop'] ?? 4, 2, 6, 4 ),
			'columns_tablet'  => av123_homepage_int_range( $section['columns_tablet'] ?? 3, 2, 4, 3 ),
			'columns_mobile'  => av123_homepage_int_range( $section['columns_mobile'] ?? 2, 1, 3, 2 ),
		);
	}

	return $output;
}

/** Register the setting. */
function av123_register_homepage_settings() {
	register_setting(
		'av123_homepage',
		AV123_HOMEPAGE_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'av123_sanitize_homepage_settings',
			'default'           => av123_homepage_defaults(),
		)
	);
}
add_action( 'admin_init', 'av123_register_homepage_settings' );

/** Add the Appearance submenu. */
function av123_add_homepage_page() {
	add_theme_page(
		__( 'Homepage Control', 'av123' ),
		__( 'Homepage Control', 'av123' ),
		'edit_theme_options',
		AV123_HOMEPAGE_PAGE,
		'av123_render_homepage_admin_page'
	);
}
add_action( 'admin_menu', 'av123_add_homepage_page' );

/**
 * Load admin assets only on the homepage settings screen.
 *
 * @param string $hook_suffix Current admin hook.
 */
function av123_homepage_admin_assets( $hook_suffix ) {
	if ( 'appearance_page_' . AV123_HOMEPAGE_PAGE !== $hook_suffix ) {
		return;
	}

	wp_enqueue_style( 'av123-homepage-admin', get_theme_file_uri( 'assets/css/homepage-admin.css' ), array(), av123_asset_version( 'assets/css/homepage-admin.css' ) );
	wp_enqueue_script( 'av123-homepage-admin', get_theme_file_uri( 'assets/js/homepage-admin.js' ), array( 'jquery', 'jquery-ui-sortable' ), av123_asset_version( 'assets/js/homepage-admin.js' ), true );
}
add_action( 'admin_enqueue_scripts', 'av123_homepage_admin_assets' );

/**
 * Return terms for an admin selector.
 *
 * @param string $taxonomy Taxonomy name.
 * @return WP_Term[]
 */
function av123_homepage_admin_terms( $taxonomy ) {
	$terms = get_terms(
		array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'number'     => 500,
			'orderby'    => 'name',
		)
	);

	return is_wp_error( $terms ) ? array() : $terms;
}

/**
 * Render heading choices.
 *
 * @param string $selected Selected heading.
 */
function av123_homepage_heading_options( $selected ) {
	foreach ( array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ) as $heading ) {
		printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $heading ), selected( $selected, $heading, false ), esc_html( strtoupper( $heading ) ) );
	}
}

/**
 * Render one repeatable section card.
 *
 * @param array      $section Section values.
 * @param int|string $index   Field index.
 */
function av123_render_home_section_admin( $section, $index ) {
	$defaults   = av123_homepage_defaults();
	$section    = array_merge( $defaults['sections'][0], is_array( $section ) ? $section : array() );
	$categories = av123_homepage_admin_terms( 'category' );
	$tags       = av123_homepage_admin_terms( 'post_tag' );
	$prefix     = AV123_HOMEPAGE_OPTION . '[sections][' . $index . ']';
	$field_id   = 'av123-section-' . $index;
	?>
	<article class="av123-section-card" data-section-card>
		<div class="av123-section-card__bar">
			<span class="dashicons dashicons-move av123-section-handle" aria-hidden="true"></span>
			<strong data-section-label><?php echo esc_html( $section['title'] ?: __( 'Untitled section', 'av123' ) ); ?></strong>
			<div class="av123-section-card__actions">
				<button type="button" class="button-link" data-move-up aria-label="<?php esc_attr_e( 'Move up', 'av123' ); ?>">&uarr;</button>
				<button type="button" class="button-link" data-move-down aria-label="<?php esc_attr_e( 'Move down', 'av123' ); ?>">&darr;</button>
				<button type="button" class="button-link" data-duplicate-section><?php esc_html_e( 'Clone', 'av123' ); ?></button>
				<button type="button" class="button-link-delete" data-remove-section><?php esc_html_e( 'Delete', 'av123' ); ?></button>
			</div>
		</div>

		<div class="av123-section-card__body">
			<input type="hidden" name="<?php echo esc_attr( $prefix ); ?>[id]" value="<?php echo esc_attr( $section['id'] ); ?>" data-section-id>
			<label class="av123-check"><input type="checkbox" name="<?php echo esc_attr( $prefix ); ?>[enabled]" value="1" <?php checked( $section['enabled'] ); ?>> <?php esc_html_e( 'Enable this section', 'av123' ); ?></label>

			<div class="av123-fields">
				<label><span><?php esc_html_e( 'Section title', 'av123' ); ?></span><input type="text" name="<?php echo esc_attr( $prefix ); ?>[title]" value="<?php echo esc_attr( $section['title'] ); ?>" data-section-title></label>
				<label><span><?php esc_html_e( 'Heading', 'av123' ); ?></span><select name="<?php echo esc_attr( $prefix ); ?>[heading_tag]" data-heading-select><?php av123_homepage_heading_options( $section['heading_tag'] ); ?></select><small class="av123-h1-warning" hidden><?php esc_html_e( 'Use H1 only when the page has no other H1.', 'av123' ); ?></small></label>
				<label><span><?php esc_html_e( 'Content source', 'av123' ); ?></span>
					<select name="<?php echo esc_attr( $prefix ); ?>[source_type]" data-source-select>
						<option value="latest" <?php selected( $section['source_type'], 'latest' ); ?>><?php esc_html_e( 'Latest', 'av123' ); ?></option>
						<option value="category" <?php selected( $section['source_type'], 'category' ); ?>><?php esc_html_e( 'Category', 'av123' ); ?></option>
						<option value="tag" <?php selected( $section['source_type'], 'tag' ); ?>><?php esc_html_e( 'Tag', 'av123' ); ?></option>
						<option value="manual" <?php selected( $section['source_type'], 'manual' ); ?>><?php esc_html_e( 'Manual IDs', 'av123' ); ?></option>
					</select>
				</label>
				<label data-source-field="category"><span><?php esc_html_e( 'Category', 'av123' ); ?></span><select name="<?php echo esc_attr( $prefix ); ?>[category_id]"><option value="0"><?php esc_html_e( 'Select a category', 'av123' ); ?></option><?php foreach ( $categories as $term ) : ?><option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( 'category' === $section['source_type'] ? $section['term_id'] : 0, $term->term_id ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select></label>
				<label data-source-field="tag"><span><?php esc_html_e( 'Tag', 'av123' ); ?></span><select name="<?php echo esc_attr( $prefix ); ?>[tag_id]"><option value="0"><?php esc_html_e( 'Select a tag', 'av123' ); ?></option><?php foreach ( $tags as $term ) : ?><option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( 'tag' === $section['source_type'] ? $section['term_id'] : 0, $term->term_id ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select></label>
				<label data-source-field="manual"><span><?php esc_html_e( 'Post/video IDs', 'av123' ); ?></span><input type="text" name="<?php echo esc_attr( $prefix ); ?>[manual_ids]" value="<?php echo esc_attr( implode( ', ', av123_homepage_sanitize_ids( $section['manual_ids'] ) ) ); ?>" placeholder="123, 456, 789"></label>
				<label><span><?php esc_html_e( 'Number of videos', 'av123' ); ?></span><input type="number" min="1" max="48" name="<?php echo esc_attr( $prefix ); ?>[count]" value="<?php echo esc_attr( $section['count'] ); ?>"></label>
			</div>

			<fieldset class="av123-columns"><legend><?php esc_html_e( 'Grid columns', 'av123' ); ?></legend>
				<label><?php esc_html_e( 'Desktop', 'av123' ); ?><input type="number" min="2" max="6" name="<?php echo esc_attr( $prefix ); ?>[columns_desktop]" value="<?php echo esc_attr( $section['columns_desktop'] ); ?>"></label>
				<label><?php esc_html_e( 'Tablet', 'av123' ); ?><input type="number" min="2" max="4" name="<?php echo esc_attr( $prefix ); ?>[columns_tablet]" value="<?php echo esc_attr( $section['columns_tablet'] ); ?>"></label>
				<label><?php esc_html_e( 'Mobile', 'av123' ); ?><input type="number" min="1" max="3" name="<?php echo esc_attr( $prefix ); ?>[columns_mobile]" value="<?php echo esc_attr( $section['columns_mobile'] ); ?>"></label>
			</fieldset>

			<div class="av123-more-settings">
				<label class="av123-check"><input type="checkbox" name="<?php echo esc_attr( $prefix ); ?>[show_more]" value="1" <?php checked( $section['show_more'] ); ?>> <?php esc_html_e( 'Show “View more” button', 'av123' ); ?></label>
				<label><span><?php esc_html_e( 'Button label', 'av123' ); ?></span><input type="text" name="<?php echo esc_attr( $prefix ); ?>[more_label]" value="<?php echo esc_attr( $section['more_label'] ); ?>"></label>
				<label><span><?php esc_html_e( 'Link mode', 'av123' ); ?></span><select name="<?php echo esc_attr( $prefix ); ?>[more_link_mode]"><option value="automatic" <?php selected( $section['more_link_mode'], 'automatic' ); ?>><?php esc_html_e( 'Automatic archive', 'av123' ); ?></option><option value="custom" <?php selected( $section['more_link_mode'], 'custom' ); ?>><?php esc_html_e( 'Custom URL', 'av123' ); ?></option><option value="none" <?php selected( $section['more_link_mode'], 'none' ); ?>><?php esc_html_e( 'No link', 'av123' ); ?></option></select></label>
				<label><span><?php esc_html_e( 'Custom URL', 'av123' ); ?></span><input type="url" name="<?php echo esc_attr( $prefix ); ?>[custom_url]" value="<?php echo esc_attr( $section['custom_url'] ); ?>"></label>
			</div>
		</div>
	</article>
	<?php
}

/** Render the complete Homepage Control screen. */
function av123_render_homepage_admin_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	$settings      = av123_get_homepage_settings();
	$defaults      = av123_homepage_defaults();
	$categories    = av123_homepage_admin_terms( 'category' );
	$tags          = av123_homepage_admin_terms( 'post_tag' );
	$content_types = get_post_types( array( 'public' => true ), 'objects' );
	$last_boost    = av123_video_boost_last_run();
	?>
	<div class="wrap av123-homepage-admin">
		<h1><?php esc_html_e( 'Homepage Control', 'av123' ); ?></h1>
		<p><?php esc_html_e( 'Control the hero, automated Video Boost engagement and every repeatable section on the homepage.', 'av123' ); ?></p>
		<?php settings_errors(); ?>

		<form action="options.php" method="post">
			<?php settings_fields( 'av123_homepage' ); ?>

			<section class="av123-admin-panel">
				<h2><?php esc_html_e( 'General and hero', 'av123' ); ?></h2>
				<div class="av123-fields">
					<fieldset><legend><?php esc_html_e( 'Content types', 'av123' ); ?></legend>
						<?php foreach ( $content_types as $post_type ) : ?>
							<?php if ( in_array( $post_type->name, array( 'attachment' ), true ) ) { continue; } ?>
							<label class="av123-check"><input type="checkbox" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[content_types][]" value="<?php echo esc_attr( $post_type->name ); ?>" <?php checked( in_array( $post_type->name, $settings['content_types'], true ) ); ?>> <?php echo esc_html( $post_type->labels->singular_name ); ?></label>
						<?php endforeach; ?>
					</fieldset>
					<label class="av123-check"><input type="checkbox" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[deduplicate]" value="1" <?php checked( $settings['deduplicate'] ); ?>> <?php esc_html_e( 'Prevent duplicate videos across hero and sections', 'av123' ); ?></label>
					<label class="av123-check"><input type="checkbox" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[hero][enabled]" value="1" <?php checked( $settings['hero']['enabled'] ); ?>> <?php esc_html_e( 'Enable hero slider', 'av123' ); ?></label>
					<label><span><?php esc_html_e( 'Hero source', 'av123' ); ?></span><select name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[hero][source_type]" data-source-select><option value="latest" <?php selected( $settings['hero']['source_type'], 'latest' ); ?>><?php esc_html_e( 'Latest', 'av123' ); ?></option><option value="category" <?php selected( $settings['hero']['source_type'], 'category' ); ?>><?php esc_html_e( 'Category', 'av123' ); ?></option><option value="tag" <?php selected( $settings['hero']['source_type'], 'tag' ); ?>><?php esc_html_e( 'Tag', 'av123' ); ?></option></select></label>
					<label data-source-field="category"><span><?php esc_html_e( 'Hero category', 'av123' ); ?></span><select name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[hero][category_id]"><option value="0"><?php esc_html_e( 'Select a category', 'av123' ); ?></option><?php foreach ( $categories as $term ) : ?><option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( 'category' === $settings['hero']['source_type'] ? $settings['hero']['term_id'] : 0, $term->term_id ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select></label>
					<label data-source-field="tag"><span><?php esc_html_e( 'Hero tag', 'av123' ); ?></span><select name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[hero][tag_id]"><option value="0"><?php esc_html_e( 'Select a tag', 'av123' ); ?></option><?php foreach ( $tags as $term ) : ?><option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( 'tag' === $settings['hero']['source_type'] ? $settings['hero']['term_id'] : 0, $term->term_id ); ?>><?php echo esc_html( $term->name ); ?></option><?php endforeach; ?></select></label>
					<label><span><?php esc_html_e( 'Hero video count', 'av123' ); ?></span><input type="number" min="1" max="20" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[hero][count]" value="<?php echo esc_attr( $settings['hero']['count'] ); ?>"></label>
				</div>
			</section>

			<section class="av123-admin-panel">
				<h2><?php esc_html_e( 'Video Boost', 'av123' ); ?></h2>
				<p><?php esc_html_e( 'Automatically add views, likes and native WordPress comments to the latest published videos. This is disabled by default.', 'av123' ); ?></p>
				<label class="av123-check"><input type="checkbox" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][enabled]" value="1" <?php checked( $settings['boost']['enabled'] ); ?>> <?php esc_html_e( 'Enable automatic Video Boost', 'av123' ); ?></label>
				<div class="av123-fields">
					<label><span><?php esc_html_e( 'Schedule', 'av123' ); ?></span><select name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][interval]"><?php foreach ( av123_video_boost_interval_options() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['boost']['interval'], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
					<label><span><?php esc_html_e( 'Latest videos per run', 'av123' ); ?></span><input type="number" min="1" max="100" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][target_count]" value="<?php echo esc_attr( $settings['boost']['target_count'] ); ?>"></label>
					<label><span><?php esc_html_e( 'Views min per video', 'av123' ); ?></span><input type="number" min="0" max="10000" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][views_min]" value="<?php echo esc_attr( $settings['boost']['views_min'] ); ?>"></label>
					<label><span><?php esc_html_e( 'Views max per video', 'av123' ); ?></span><input type="number" min="0" max="10000" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][views_max]" value="<?php echo esc_attr( $settings['boost']['views_max'] ); ?>"></label>
					<label><span><?php esc_html_e( 'Likes min per video', 'av123' ); ?></span><input type="number" min="0" max="1000" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][likes_min]" value="<?php echo esc_attr( $settings['boost']['likes_min'] ); ?>"></label>
					<label><span><?php esc_html_e( 'Likes max per video', 'av123' ); ?></span><input type="number" min="0" max="1000" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][likes_max]" value="<?php echo esc_attr( $settings['boost']['likes_max'] ); ?>"></label>
					<label><span><?php esc_html_e( 'Comments min per video', 'av123' ); ?></span><input type="number" min="0" max="5" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][comments_min]" value="<?php echo esc_attr( $settings['boost']['comments_min'] ); ?>"></label>
					<label><span><?php esc_html_e( 'Comments max per video', 'av123' ); ?></span><input type="number" min="0" max="5" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][comments_max]" value="<?php echo esc_attr( $settings['boost']['comments_max'] ); ?>"></label>
				</div>
				<div class="av123-boost-textareas">
					<label><span><?php esc_html_e( 'Comment authors (one per line)', 'av123' ); ?></span><textarea rows="6" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][comment_authors]"><?php echo esc_textarea( $settings['boost']['comment_authors'] ); ?></textarea></label>
					<label><span><?php esc_html_e( 'Comment messages (one per line)', 'av123' ); ?></span><textarea rows="6" name="<?php echo esc_attr( AV123_HOMEPAGE_OPTION ); ?>[boost][comment_templates]"><?php echo esc_textarea( $settings['boost']['comment_templates'] ); ?></textarea></label>
				</div>
				<p class="description"><?php esc_html_e( 'Generated comments are approved automatically and tagged with _av123_video_boost for auditing.', 'av123' ); ?></p>
				<?php if ( $last_boost ) : ?><p><strong><?php esc_html_e( 'Last run:', 'av123' ); ?></strong> <?php echo esc_html( av123_video_boost_last_run_summary( $last_boost ) ); ?></p><?php endif; ?>
				<p><a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=av123_run_video_boost' ), 'av123_run_video_boost' ) ); ?>"><?php esc_html_e( 'Run Video Boost now', 'av123' ); ?></a></p>
			</section>

			<section class="av123-admin-panel">
				<div class="av123-admin-panel__heading"><div><h2><?php esc_html_e( 'Homepage sections', 'av123' ); ?></h2><p><?php esc_html_e( 'Drag, clone, add or delete sections. Category and tag links are generated automatically.', 'av123' ); ?></p></div><button type="button" class="button button-secondary" data-add-section><?php esc_html_e( 'Add section', 'av123' ); ?></button></div>
				<div class="av123-sections" data-sections>
					<?php foreach ( $settings['sections'] as $index => $section ) : ?><?php av123_render_home_section_admin( $section, $index ); ?><?php endforeach; ?>
				</div>
				<template id="av123-section-template"><?php av123_render_home_section_admin( $defaults['sections'][0], '__INDEX__' ); ?></template>
			</section>

			<?php submit_button( __( 'Save homepage', 'av123' ) ); ?>
		</form>
	</div>
	<?php
}
