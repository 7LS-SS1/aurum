<?php
/**
 * Search, VideoObject and video sitemap integration.
 *
 * Rank Math remains the owner of canonical, social metadata and the JSON-LD
 * graph. This module supplies validated video data and narrowly-scoped filters.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Preserve a JSON boolean through Rank Math's wp_kses_post_deep pass. */
final class AV123_JSON_Boolean_False implements JsonSerializable {
	#[ReturnTypeWillChange]
	public function jsonSerialize() {
		return false;
	}
}

/** Whether a post is a published, public watch page. */
function av123_search_is_watch_post( $post_id ) {
	$post = get_post( $post_id );
	return $post instanceof WP_Post && 'publish' === $post->post_status && in_array( $post->post_type, av123_homepage_content_types(), true ) && (bool) av123_get_video_url( $post_id );
}

/** Return a meaningful plain-text description without inventing content. */
function av123_search_description( $post_id ) {
	foreach ( array( 'rank_math_description', '_yoast_wpseo_metadesc' ) as $key ) {
		$value = trim( wp_strip_all_tags( (string) get_post_meta( $post_id, $key, true ) ) );
		if ( $value ) {
			return wp_html_excerpt( $value, 300, '…' );
		}
	}

	$value = trim( wp_strip_all_tags( (string) get_post_field( 'post_excerpt', $post_id ) ) );
	if ( ! $value ) {
		$value = trim( wp_strip_all_tags( strip_shortcodes( (string) get_post_field( 'post_content', $post_id ) ) ) );
	}

	return $value && $value !== trim( wp_strip_all_tags( get_the_title( $post_id ) ) ) ? wp_html_excerpt( $value, 300, '…' ) : '';
}

/** Return a validated thumbnail URL and its provenance. */
function av123_search_thumbnail( $post_id ) {
	if ( has_post_thumbnail( $post_id ) ) {
		$url = get_the_post_thumbnail_url( $post_id, 'full' );
		if ( $url && wp_http_validate_url( $url ) ) {
			return array( 'url' => esc_url_raw( $url ), 'source' => 'featured_image' );
		}
	}

	foreach ( array( '_sevenls_vp_thumbnail_url', 'aurum_thumbnail_url', 'thumbnail_url', 'thumb', 'poster' ) as $key ) {
		$url = trim( (string) get_post_meta( $post_id, $key, true ) );
		if ( $url && wp_http_validate_url( $url ) ) {
			return array( 'url' => esc_url_raw( $url ), 'source' => $key );
		}
	}

	return array( 'url' => '', 'source' => '' );
}

/** Normalize a supported duration value to ISO 8601. */
function av123_search_duration_iso( $post_id ) {
	foreach ( array( '_sevenls_vp_duration', 'aurum_duration', 'video_duration', 'duration' ) as $key ) {
		$raw = trim( (string) get_post_meta( $post_id, $key, true ) );
		if ( ! $raw ) {
			continue;
		}
		if ( preg_match( '/^PT(?:\d+H)?(?:\d+M)?(?:\d+S)?$/i', $raw ) ) {
			return strtoupper( $raw );
		}
		if ( ctype_digit( $raw ) ) {
			$seconds = absint( $raw );
		} elseif ( preg_match( '/^(?:(\d+):)?([0-5]?\d):([0-5]?\d)$/', $raw, $parts ) ) {
			$seconds = (int) ( $parts[1] ?? 0 ) * HOUR_IN_SECONDS + (int) $parts[2] * MINUTE_IN_SECONDS + (int) $parts[3];
		} else {
			continue;
		}
		if ( $seconds > 0 ) {
			$hours = intdiv( $seconds, HOUR_IN_SECONDS );
			$minutes = intdiv( $seconds % HOUR_IN_SECONDS, MINUTE_IN_SECONDS );
			$remainder = $seconds % MINUTE_IN_SECONDS;
			return 'PT' . ( $hours ? $hours . 'H' : '' ) . ( $minutes ? $minutes . 'M' : '' ) . ( $remainder || ( ! $hours && ! $minutes ) ? $remainder . 'S' : '' );
		}
	}
	return '';
}

/** Build the one normalized metadata contract used by schema and sitemap. */
function av123_search_video_metadata( $post_id ) {
	$post = get_post( $post_id );
	if ( ! $post || ! av123_search_is_watch_post( $post_id ) ) {
		return array();
	}

	$thumbnail = av123_search_thumbnail( $post_id );
	$data = array(
		'id'            => (int) $post_id,
		'name'          => trim( wp_strip_all_tags( get_the_title( $post_id ) ) ),
		'description'   => av123_search_description( $post_id ),
		'thumbnail_url' => $thumbnail['url'],
		'thumbnail_from'=> $thumbnail['source'],
		'content_url'   => av123_get_video_url( $post_id ),
		'canonical'     => get_permalink( $post_id ),
		'upload_date'   => get_post_time( DATE_W3C, true, $post_id ),
		'modified_date' => get_post_modified_time( DATE_W3C, true, $post_id ),
		'duration'      => av123_search_duration_iso( $post_id ),
	);

	foreach ( array( 'aurum_iframe_url', 'iframe_url' ) as $key ) {
		$url = trim( (string) get_post_meta( $post_id, $key, true ) );
		if ( $url && wp_http_validate_url( $url ) ) {
			$data['embed_url'] = esc_url_raw( $url );
			break;
		}
	}

	if ( ! $data['name'] || ! $data['description'] || ! $data['thumbnail_url'] || ! $data['canonical'] || ( ! $data['content_url'] && empty( $data['embed_url'] ) ) ) {
		return array();
	}

	return apply_filters( 'av123_search_video_metadata', $data, $post_id );
}

/** Concise title for homepage and video watch pages. */
function av123_search_title( $title ) {
	if ( is_front_page() ) {
		return 'หนัง AV ซับไทยและคลิป OnlyFans อัปเดตล่าสุด | ThaiTube';
	}
	if ( av123_is_video_singular() ) {
		$raw = trim( wp_strip_all_tags( get_the_title( get_queried_object_id() ) ) );
		if ( $raw ) {
			return wp_html_excerpt( $raw, 66, '…' ) . ' | ThaiTube';
		}
	}
	return $title;
}
add_filter( 'rank_math/frontend/title', 'av123_search_title', 30 );
add_filter( 'pre_get_document_title', 'av123_search_title', 30 );

/** Use a real archive description when Rank Math has none. */
function av123_search_meta_description( $description ) {
	if ( ! $description && ( is_category() || is_tag() || is_tax() ) ) {
		$description = av123_search_archive_intro();
	}
	return $description;
}
add_filter( 'rank_math/frontend/description', 'av123_search_meta_description', 30 );

/** Return editorial description or a factual, term-specific archive introduction. */
function av123_search_archive_intro() {
	$description = trim( wp_strip_all_tags( term_description() ) );
	if ( $description ) {
		return $description;
	}
	$term = get_queried_object();
	if ( ! $term instanceof WP_Term ) {
		return '';
	}
	if ( is_tag() ) {
		return sprintf( 'สำรวจวิดีโอที่เกี่ยวข้องกับ %s พร้อมรายการอัปเดตและลิงก์ไปยังเนื้อหาที่เกี่ยวข้อง', $term->name );
	}
	if ( in_array( $term->taxonomy, array( 'actors', 'video_actor', 'aurum_video_actor' ), true ) ) {
		return sprintf( 'รวมผลงานวิดีโอของ %s ที่เผยแพร่บนเว็บไซต์และสามารถเลือกดูตามรายการได้', $term->name );
	}
	return sprintf( 'รวมวิดีโอในหมวด %s พร้อมรายการอัปเดตล่าสุดและหน้าถัดไปสำหรับค้นหาเนื้อหาเพิ่มเติม', $term->name );
}

/** Transparent explicit-content signal. */
function av123_search_adult_meta() {
	if ( ! is_admin() && ( is_front_page() || is_archive() || av123_is_video_singular() ) ) {
		echo '<meta name="rating" content="adult">' . "\n";
	}
}
add_action( 'wp_head', 'av123_search_adult_meta', 2 );

/** Add exactly one VideoObject to the Rank Math graph. */
function av123_search_rank_math_video_object( $data, $jsonld = null ) {
	if ( ! av123_is_video_singular() ) {
		return $data;
	}
	foreach ( $data as $entity ) {
		$type = isset( $entity['@type'] ) ? (array) $entity['@type'] : array();
		if ( in_array( 'VideoObject', $type, true ) ) {
			return $data;
		}
	}

	$meta = av123_search_video_metadata( get_queried_object_id() );
	if ( ! $meta ) {
		return $data;
	}
	$entity = array(
		'@type'            => 'VideoObject',
		'@id'              => $meta['canonical'] . '#video',
		'name'             => $meta['name'],
		'description'      => $meta['description'],
		'thumbnailUrl'     => array( $meta['thumbnail_url'] ),
		'uploadDate'       => $meta['upload_date'],
		'isFamilyFriendly' => new AV123_JSON_Boolean_False(),
		'mainEntityOfPage' => array( '@id' => $meta['canonical'] . '#webpage' ),
	);
	if ( $meta['content_url'] ) {
		$entity['contentUrl'] = $meta['content_url'];
	}
	if ( ! empty( $meta['embed_url'] ) ) {
		$entity['embedUrl'] = $meta['embed_url'];
	}
	if ( $meta['duration'] ) {
		$entity['duration'] = $meta['duration'];
	}
	$data['av123-video'] = $entity;
	return $data;
}
add_filter( 'rank_math/json_ld', 'av123_search_rank_math_video_object', 90, 2 );

/** Add the custom video sitemap to Rank Math's sitemap index. */
function av123_search_sitemap_index( $xml ) {
	$lastmod = mysql2date( DATE_W3C, get_lastpostmodified( 'GMT' ), false );
	$xml .= '<sitemap><loc>' . esc_url( home_url( '/video-sitemap.xml' ) ) . '</loc><lastmod>' . esc_html( $lastmod ) . '</lastmod></sitemap>';
	return $xml;
}
add_filter( 'rank_math/sitemap/index', 'av123_search_sitemap_index' );

/**
 * Invalidate Rank Math's persisted sitemap index once after a theme update.
 *
 * Rank Math can serve an index generated before the custom video sitemap
 * filter existed. Tying the invalidation marker to the theme version makes
 * deployments self-healing without clearing the cache on every request.
 */
function av123_search_refresh_rank_math_sitemap_cache() {
	if ( ! class_exists( '\\RankMath\\Sitemap\\Cache' ) ) {
		return;
	}

	$version = (string) wp_get_theme()->get( 'Version' );
	if ( $version === (string) get_option( 'av123_rank_math_sitemap_version', '' ) ) {
		return;
	}

	\RankMath\Sitemap\Cache::invalidate_storage();
	update_option( 'av123_rank_math_sitemap_version', $version, false );
}
add_action( 'init', 'av123_search_refresh_rank_math_sitemap_cache', 99 );

/**
 * Build the validated, deduplicated inventory used by every sitemap page.
 *
 * Oldest content wins when two posts resolve to the same media URL. This
 * preserves the original URL rather than a later WordPress "-2" duplicate.
 */
function av123_search_video_sitemap_entries() {
	$query = new WP_Query(
		array(
			'post_type'              => av123_homepage_content_types(),
			'post_status'            => 'publish',
			'posts_per_page'         => -1,
			'orderby'                => array( 'date' => 'ASC', 'ID' => 'ASC' ),
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_meta_cache' => true,
		)
	);

	$entries    = array();
	$seen_media = array();
	foreach ( $query->posts as $post_id ) {
		$meta = av123_search_video_metadata( $post_id );
		if ( ! $meta ) {
			continue;
		}
		$media_key = ! empty( $meta['embed_url'] ) ? $meta['embed_url'] : $meta['content_url'];
		if ( isset( $seen_media[ $media_key ] ) ) {
			continue;
		}
		$seen_media[ $media_key ] = true;
		$entries[]                 = $meta;
	}

	usort(
		$entries,
		static function ( $left, $right ) {
			return strcmp( $right['modified_date'], $left['modified_date'] );
		}
	);

	return $entries;
}

/** Render a standards-based video sitemap from validated metadata. */
function av123_search_maybe_render_video_sitemap() {
	$path = trim( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' );
	$is_index = 'video-sitemap.xml' === $path;
	if ( ! $is_index && ! preg_match( '/^video-sitemap-(\d+)\.xml$/', $path, $matches ) ) {
		return;
	}
	$page      = $is_index ? 0 : max( 1, absint( $matches[1] ) );
	$cache_key = 'av123_video_sitemap_xml_' . $page;
	$cached    = get_transient( $cache_key );
	if ( is_string( $cached ) && '' !== $cached ) {
		status_header( 200 );
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex, follow', true );
		echo $cached; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	$per_page = 1000;
	$entries  = av123_search_video_sitemap_entries();
	if ( $is_index ) {
		$pages = (int) ceil( count( $entries ) / $per_page );
		$xml   = '<?xml version="1.0" encoding="UTF-8"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
		for ( $number = 1; $number <= $pages; $number++ ) {
			$xml .= '<sitemap><loc>' . esc_xml( home_url( '/video-sitemap-' . $number . '.xml' ) ) . '</loc><lastmod>' . esc_xml( mysql2date( DATE_W3C, get_lastpostmodified( 'GMT' ), false ) ) . '</lastmod></sitemap>';
		}
		$xml .= '</sitemapindex>';
		set_transient( $cache_key, $xml, HOUR_IN_SECONDS );
		status_header( 200 );
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex, follow', true );
		echo $xml; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	$entries = array_slice( $entries, ( $page - 1 ) * $per_page, $per_page );
	if ( ! $entries ) {
		status_header( 404 );
		header( 'Content-Type: text/plain; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex, nofollow', true );
		echo 'Video sitemap page not found.';
		exit;
	}

	status_header( 200 );
	header( 'Content-Type: application/xml; charset=UTF-8' );
	header( 'X-Robots-Tag: noindex, follow', true );
	ob_start();
	echo '<?xml version="1.0" encoding="UTF-8"?>';
	echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">';
	foreach ( $entries as $meta ) {
		echo '<url><loc>' . esc_xml( $meta['canonical'] ) . '</loc><lastmod>' . esc_xml( $meta['modified_date'] ) . '</lastmod><video:video>';
		echo '<video:thumbnail_loc>' . esc_xml( $meta['thumbnail_url'] ) . '</video:thumbnail_loc>';
		echo '<video:title>' . esc_xml( $meta['name'] ) . '</video:title><video:description>' . esc_xml( $meta['description'] ) . '</video:description>';
		if ( ! empty( $meta['embed_url'] ) ) {
			echo '<video:player_loc>' . esc_xml( $meta['embed_url'] ) . '</video:player_loc>';
		} else {
			echo '<video:content_loc>' . esc_xml( $meta['content_url'] ) . '</video:content_loc>';
		}
		echo '<video:publication_date>' . esc_xml( $meta['upload_date'] ) . '</video:publication_date><video:family_friendly>no</video:family_friendly>';
		echo '</video:video></url>';
	}
	echo '</urlset>';
	$xml = ob_get_clean();
	set_transient( $cache_key, $xml, HOUR_IN_SECONDS );
	echo $xml; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	exit;
}
add_action( 'template_redirect', 'av123_search_maybe_render_video_sitemap', 0 );

/** Invalidate sitemap cache only when published content or its metadata changes. */
function av123_search_invalidate_video_sitemap( $post_id = 0 ) {
	if ( ! $post_id || in_array( get_post_type( $post_id ), av123_homepage_content_types(), true ) ) {
		global $wpdb;
		$prefix = '_transient_av123_video_sitemap_xml_';
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( $prefix ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
	}
}
add_action( 'save_post', 'av123_search_invalidate_video_sitemap' );
add_action( 'deleted_post', 'av123_search_invalidate_video_sitemap' );
