<?php
/**
 * Theme Setup: safe, admin-triggered creation of the theme's base pages.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AV123_THEME_SETUP_OPTION', 'av123_theme_setup_pages' );
define( 'AV123_THEME_SETUP_PAGE', 'av123-theme-setup' );

/**
 * Placeholder body copy for the non-directory pages.
 *
 * Copy is intentionally generic and is not legal advice; it exists so a
 * freshly created page is not blank, and only appears on pages this screen
 * creates itself (never written into a page that already exists).
 *
 * @param string $key Page definition key.
 * @return string
 */
function av123_theme_setup_placeholder_content( $key ) {
	$paragraphs = array(
		'dmca'           => array(
			__( 'This is a placeholder DMCA notice. Replace this text with your own policy before publishing this page.', 'av123' ),
			__( 'Describe how copyright holders can submit takedown requests and how your team responds to them.', 'av123' ),
		),
		'privacy_policy' => array(
			__( 'This is a placeholder Privacy Policy. Replace this text with your own policy before publishing this page.', 'av123' ),
			__( 'Describe what data you collect, how it is used, and how visitors can contact you about their data.', 'av123' ),
		),
		'terms_of_use'   => array(
			__( 'This is a placeholder Terms of Use page. Replace this text with your own terms before publishing this page.', 'av123' ),
			__( 'Describe the rules visitors must follow when using this website.', 'av123' ),
		),
		'submit_video'   => array(
			__( 'This is a placeholder page for video submissions. Replace this text with your own instructions.', 'av123' ),
			__( 'This page does not include an upload form; add your own submission method here.', 'av123' ),
		),
	);

	$lines   = isset( $paragraphs[ $key ] ) ? $paragraphs[ $key ] : array();
	$content = '';

	foreach ( $lines as $line ) {
		$content .= '<!-- wp:paragraph --><p>' . esc_html( $line ) . '</p><!-- /wp:paragraph -->' . "\n\n";
	}

	return trim( $content );
}

/**
 * Definitions for every page this screen is allowed to create.
 *
 * @return array<string,array{title:string,slug:string,template:string,content:string}>
 */
function av123_theme_setup_page_definitions() {
	$definitions = array(
		'categories'     => array(
			'title'    => __( 'Categories', 'av123' ),
			'slug'     => 'categories',
			'template' => 'template-categories.php',
			'content'  => '',
		),
		'tags'           => array(
			'title'    => __( 'Tags', 'av123' ),
			'slug'     => 'tags',
			'template' => 'template-tags.php',
			'content'  => '',
		),
		'actors'         => array(
			'title'    => __( 'Actors', 'av123' ),
			'slug'     => 'actors',
			'template' => 'template-actors.php',
			'content'  => '',
		),
		'dmca'           => array(
			'title'    => __( 'DMCA', 'av123' ),
			'slug'     => 'dmca',
			'template' => '',
			'content'  => av123_theme_setup_placeholder_content( 'dmca' ),
		),
		'privacy_policy' => array(
			'title'    => __( 'Privacy Policy', 'av123' ),
			'slug'     => 'privacy-policy',
			'template' => '',
			'content'  => av123_theme_setup_placeholder_content( 'privacy_policy' ),
		),
		'terms_of_use'   => array(
			'title'    => __( 'Terms of Use', 'av123' ),
			'slug'     => 'terms-of-use',
			'template' => '',
			'content'  => av123_theme_setup_placeholder_content( 'terms_of_use' ),
		),
		'submit_video'   => array(
			'title'    => __( 'Submit a video', 'av123' ),
			'slug'     => 'submit-a-video',
			'template' => '',
			'content'  => av123_theme_setup_placeholder_content( 'submit_video' ),
		),
	);

	/**
	 * Filter the page definitions offered on the Theme Setup screen.
	 *
	 * Every definition, including filtered-in ones, is re-validated: an
	 * invalid key, missing title/slug, or a template that is not an actual
	 * registered page template is dropped.
	 *
	 * @param array $definitions Key => definition map.
	 */
	$definitions = apply_filters( 'av123_theme_setup_page_definitions', $definitions );

	return av123_theme_setup_validate_definitions( $definitions );
}

/**
 * Re-validate page definitions so a filter cannot introduce something unsafe.
 *
 * @param array $definitions Raw definitions.
 * @return array
 */
function av123_theme_setup_validate_definitions( $definitions ) {
	$available_templates = array_keys( wp_get_theme()->get_page_templates() );
	$validated            = array();

	foreach ( (array) $definitions as $key => $definition ) {
		$key = sanitize_key( $key );

		if ( '' === $key || ! is_array( $definition ) ) {
			continue;
		}

		$title = isset( $definition['title'] ) ? sanitize_text_field( $definition['title'] ) : '';
		$slug  = isset( $definition['slug'] ) ? sanitize_title( $definition['slug'] ) : '';

		if ( '' === $title || '' === $slug ) {
			continue;
		}

		$template = isset( $definition['template'] ) ? sanitize_text_field( $definition['template'] ) : '';

		if ( '' !== $template && ! in_array( $template, $available_templates, true ) ) {
			continue;
		}

		$validated[ $key ] = array(
			'title'    => $title,
			'slug'     => $slug,
			'template' => $template,
			'content'  => isset( $definition['content'] ) ? (string) $definition['content'] : '',
		);
	}

	return $validated;
}

/**
 * Read the saved page-ID status option.
 *
 * @return array<string,int>
 */
function av123_get_theme_setup_pages() {
	$saved = get_option( AV123_THEME_SETUP_OPTION, array() );

	if ( ! is_array( $saved ) ) {
		return array();
	}

	$clean = array();

	foreach ( $saved as $key => $id ) {
		$id = absint( $id );

		if ( $id ) {
			$clean[ sanitize_key( $key ) ] = $id;
		}
	}

	return $clean;
}

/**
 * Resolve an existing page for one definition: saved ID first, then slug.
 *
 * Never creates, modifies or deletes anything; a resolved page here is
 * treated as untouchable by the create action.
 *
 * @param string $key        Definition key.
 * @param array  $definition Page definition.
 * @param array  $saved      Saved key => page ID map.
 * @return WP_Post|null
 */
function av123_theme_setup_resolve_page( $key, $definition, $saved ) {
	$saved_id = isset( $saved[ $key ] ) ? absint( $saved[ $key ] ) : 0;

	if ( $saved_id ) {
		$post = get_post( $saved_id );

		if ( $post && 'page' === $post->post_type && 'trash' !== $post->post_status ) {
			return $post;
		}
	}

	$by_slug = get_page_by_path( $definition['slug'], OBJECT, 'page' );

	if ( $by_slug instanceof WP_Post && 'trash' !== $by_slug->post_status ) {
		return $by_slug;
	}

	return null;
}

/** Add the Appearance submenu screen. */
function av123_add_theme_setup_page() {
	add_theme_page(
		__( 'Theme Setup', 'av123' ),
		__( 'Theme Setup', 'av123' ),
		'edit_theme_options',
		AV123_THEME_SETUP_PAGE,
		'av123_render_theme_setup_admin_page'
	);
}
add_action( 'admin_menu', 'av123_add_theme_setup_page' );

/**
 * Handle the "Create missing selected pages" submission.
 *
 * Only ever inserts brand-new pages for keys that are (a) on the built-in
 * allow-list of definitions and (b) still unresolved at submit time. Pages
 * that already resolve by saved ID or slug are left completely untouched.
 */
function av123_theme_setup_admin_create() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die(
			esc_html__( 'You are not allowed to create these pages.', 'av123' ),
			esc_html__( 'Forbidden', 'av123' ),
			array( 'response' => 403 )
		);
	}

	check_admin_referer( 'av123_theme_setup_create' );

	$definitions = av123_theme_setup_page_definitions();
	$requested   = isset( $_POST['av123_theme_setup_pages'] ) ? (array) wp_unslash( $_POST['av123_theme_setup_pages'] ) : array();
	$requested   = array_map( 'sanitize_key', $requested );
	$selected    = array_values( array_intersect( $requested, array_keys( $definitions ) ) );

	$saved   = av123_get_theme_setup_pages();
	$results = array();

	foreach ( $definitions as $key => $definition ) {
		$resolved = av123_theme_setup_resolve_page( $key, $definition, $saved );

		if ( $resolved ) {
			$saved[ $key ] = $resolved->ID;
			continue;
		}

		if ( ! in_array( $key, $selected, true ) ) {
			continue;
		}

		$new_id = wp_insert_post(
			array(
				'post_title'   => $definition['title'],
				'post_name'    => $definition['slug'],
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => $definition['content'],
			),
			true
		);

		if ( is_wp_error( $new_id ) ) {
			$results[ $key ] = array(
				'status'  => 'error',
				'message' => $new_id->get_error_message(),
			);
			continue;
		}

		if ( '' !== $definition['template'] ) {
			update_post_meta( $new_id, '_wp_page_template', $definition['template'] );
		}

		$saved[ $key ]   = $new_id;
		$results[ $key ] = array( 'status' => 'ready' );
	}

	update_option( AV123_THEME_SETUP_OPTION, $saved );
	set_transient( 'av123_theme_setup_notice_' . get_current_user_id(), $results, MINUTE_IN_SECONDS );

	wp_safe_redirect( admin_url( 'themes.php?page=' . AV123_THEME_SETUP_PAGE ) );
	exit;
}
add_action( 'admin_post_av123_theme_setup_create', 'av123_theme_setup_admin_create' );

/**
 * Print the status label for one table row.
 *
 * @param string $status One of existing|ready|will_create|error.
 */
function av123_theme_setup_status_label( $status ) {
	$labels = array(
		'existing'    => __( 'Existing', 'av123' ),
		'ready'       => __( 'Ready (just created)', 'av123' ),
		'will_create' => __( 'Will create', 'av123' ),
		'error'       => __( 'Error', 'av123' ),
	);

	echo esc_html( isset( $labels[ $status ] ) ? $labels[ $status ] : $status );
}

/** Render the Theme Setup screen. */
function av123_render_theme_setup_admin_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	$definitions = av123_theme_setup_page_definitions();
	$saved       = av123_get_theme_setup_pages();

	$notice_key = 'av123_theme_setup_notice_' . get_current_user_id();
	$results    = get_transient( $notice_key );
	$results    = is_array( $results ) ? $results : array();

	if ( $results ) {
		delete_transient( $notice_key );
	}

	$created_count = 0;

	foreach ( $results as $result ) {
		if ( isset( $result['status'] ) && 'ready' === $result['status'] ) {
			++$created_count;
		}
	}

	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Theme Setup', 'av123' ); ?></h1>
		<p><?php esc_html_e( 'Create the base pages this theme expects. Existing pages are never overwritten, modified, deleted or duplicated — only pages that are still missing are created, and only when you select them.', 'av123' ); ?></p>

		<?php if ( $created_count > 0 ) : ?>
			<div class="notice notice-success is-dismissible"><p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of pages created. */
						_n( '%d page created.', '%d pages created.', $created_count, 'av123' ),
						$created_count
					)
				);
				?>
			</p></div>
		<?php endif; ?>

		<?php foreach ( $results as $key => $result ) : ?>
			<?php if ( isset( $result['status'] ) && 'error' === $result['status'] ) : ?>
				<div class="notice notice-error is-dismissible"><p>
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: page title, 2: error message. */
							__( 'Could not create "%1$s": %2$s', 'av123' ),
							isset( $definitions[ $key ]['title'] ) ? $definitions[ $key ]['title'] : $key,
							isset( $result['message'] ) ? $result['message'] : ''
						)
					);
					?>
				</p></div>
			<?php endif; ?>
		<?php endforeach; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="av123_theme_setup_create">
			<?php wp_nonce_field( 'av123_theme_setup_create' ); ?>

			<table class="widefat striped">
				<thead>
					<tr>
						<th class="check-column"></th>
						<th><?php esc_html_e( 'Page', 'av123' ); ?></th>
						<th><?php esc_html_e( 'Slug', 'av123' ); ?></th>
						<th><?php esc_html_e( 'Template', 'av123' ); ?></th>
						<th><?php esc_html_e( 'Status', 'av123' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $definitions as $key => $definition ) : ?>
						<?php
						$resolved = av123_theme_setup_resolve_page( $key, $definition, $saved );

						if ( $resolved ) {
							$status = ( isset( $results[ $key ]['status'] ) && 'ready' === $results[ $key ]['status'] ) ? 'ready' : 'existing';
						} elseif ( isset( $results[ $key ]['status'] ) && 'error' === $results[ $key ]['status'] ) {
							$status = 'error';
						} else {
							$status = 'will_create';
						}

						$field_id = 'av123-setup-' . $key;
						?>
						<tr>
							<td class="check-column">
								<?php if ( ! $resolved ) : ?>
									<input type="checkbox" name="av123_theme_setup_pages[]" value="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $field_id ); ?>" checked>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( $resolved ) : ?>
									<?php echo esc_html( $definition['title'] ); ?>
								<?php else : ?>
									<label for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $definition['title'] ); ?></label>
								<?php endif; ?>
							</td>
							<td>/<?php echo esc_html( $definition['slug'] ); ?>/</td>
							<td><?php echo esc_html( '' !== $definition['template'] ? $definition['template'] : __( 'Default page template', 'av123' ) ); ?></td>
							<td>
								<?php av123_theme_setup_status_label( $status ); ?>
								<?php if ( $resolved ) : ?>
									 &mdash; <a href="<?php echo esc_url( get_edit_post_link( $resolved->ID ) ); ?>"><?php esc_html_e( 'Edit', 'av123' ); ?></a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php submit_button( __( 'Create missing selected pages', 'av123' ) ); ?>
		</form>
	</div>
	<?php
}

/** Flag that a one-time, link-only notice should appear after a theme switch. */
function av123_theme_setup_flag_switch_notice() {
	if ( current_user_can( 'edit_theme_options' ) ) {
		set_transient( 'av123_theme_setup_switch_notice', 1, WEEK_IN_SECONDS );
	}
}
add_action( 'after_switch_theme', 'av123_theme_setup_flag_switch_notice' );

/**
 * Show a link to the Theme Setup screen after activation.
 *
 * This never creates pages by itself; it only points the admin to the
 * screen where creation requires an explicit, nonce-verified action.
 */
function av123_theme_setup_switch_notice() {
	if ( ! current_user_can( 'edit_theme_options' ) || ! get_transient( 'av123_theme_setup_switch_notice' ) ) {
		return;
	}

	printf(
		'<div class="notice notice-info is-dismissible"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
		esc_html__( 'This theme can create a few base pages for you (Categories, Tags, Actors, DMCA, Privacy Policy, Terms of Use, Submit a video).', 'av123' ),
		esc_url( admin_url( 'themes.php?page=' . AV123_THEME_SETUP_PAGE ) ),
		esc_html__( 'Open Theme Setup', 'av123' )
	);
}
add_action( 'admin_notices', 'av123_theme_setup_switch_notice' );
