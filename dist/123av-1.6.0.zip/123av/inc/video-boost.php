<?php
/**
 * Automated Video Boost engagement counters.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AV123_VIDEO_BOOST_HOOK', 'av123_video_boost_event' );
define( 'AV123_VIDEO_BOOST_LAST_RUN_OPTION', 'av123_video_boost_last_run' );

/** Add the shortest supported Video Boost schedule. */
function av123_video_boost_cron_schedules( $schedules ) {
	$schedules['av123_fifteen_minutes'] = array(
		'interval' => 15 * MINUTE_IN_SECONDS,
		'display'  => __( 'Every 15 minutes', 'av123' ),
	);

	return $schedules;
}
add_filter( 'cron_schedules', 'av123_video_boost_cron_schedules' );

/** Return selectable schedules. */
function av123_video_boost_interval_options() {
	return array(
		'av123_fifteen_minutes' => __( 'Every 15 minutes', 'av123' ),
		'hourly'                => __( 'Hourly', 'av123' ),
		'twicedaily'            => __( 'Twice daily', 'av123' ),
		'daily'                 => __( 'Daily', 'av123' ),
	);
}

/** Sanitize a newline-delimited list while retaining its admin-editable form. */
function av123_video_boost_sanitize_lines( $value, $max_lines = 100, $max_length = 500 ) {
	$value = is_array( $value ) ? implode( "\n", $value ) : (string) $value;
	$lines = preg_split( '/\R/u', wp_unslash( $value ) );
	$clean = array();

	foreach ( $lines as $line ) {
		$line = trim( sanitize_text_field( $line ) );
		if ( '' === $line ) {
			continue;
		}
		$clean[] = function_exists( 'mb_substr' ) ? mb_substr( $line, 0, $max_length ) : substr( $line, 0, $max_length );
		if ( count( $clean ) >= $max_lines ) {
			break;
		}
	}

	return implode( "\n", array_values( array_unique( $clean ) ) );
}

/** Convert a saved newline list to values. */
function av123_video_boost_lines( $value ) {
	$value = av123_video_boost_sanitize_lines( $value );
	return '' === $value ? array() : explode( "\n", $value );
}

/** Keep the recurring event aligned with the saved setting. */
function av123_video_boost_maybe_schedule() {
	$settings = av123_get_homepage_settings();
	$boost    = $settings['boost'];
	$wanted   = sanitize_key( $boost['interval'] ?? 'hourly' );
	$current  = wp_get_schedule( AV123_VIDEO_BOOST_HOOK );

	if ( empty( $boost['enabled'] ) ) {
		if ( $current ) {
			wp_clear_scheduled_hook( AV123_VIDEO_BOOST_HOOK );
		}
		return;
	}

	if ( ! isset( av123_video_boost_interval_options()[ $wanted ] ) ) {
		$wanted = 'hourly';
	}

	if ( $current && $current !== $wanted ) {
		wp_clear_scheduled_hook( AV123_VIDEO_BOOST_HOOK );
		$current = false;
	}

	if ( ! $current && ! wp_next_scheduled( AV123_VIDEO_BOOST_HOOK ) ) {
		wp_schedule_event( time() + MINUTE_IN_SECONDS, $wanted, AV123_VIDEO_BOOST_HOOK );
	}
}
add_action( 'init', 'av123_video_boost_maybe_schedule', 30 );
add_action( 'after_switch_theme', 'av123_video_boost_maybe_schedule' );

/** Clear this theme's scheduled job when another theme is activated. */
function av123_video_boost_clear_schedule() {
	wp_clear_scheduled_hook( AV123_VIDEO_BOOST_HOOK );
}
add_action( 'switch_theme', 'av123_video_boost_clear_schedule' );

/** Reconcile cron immediately after Homepage Control is saved. */
function av123_video_boost_option_updated() {
	av123_video_boost_maybe_schedule();
}
add_action( 'update_option_' . AV123_HOMEPAGE_OPTION, 'av123_video_boost_option_updated', 10, 0 );

/** Return the stored view counter. */
function av123_get_video_views( $post_id ) {
	return max( 0, (int) get_post_meta( $post_id, '_sevenls_vp_view_count', true ) );
}

/** Return the 7LS-compatible like counter. */
function av123_get_video_likes( $post_id ) {
	return max( 0, (int) get_post_meta( $post_id, '_sevenls_vp_like_count', true ) );
}

/**
 * Run one Video Boost batch.
 *
 * @param bool $dry_run Calculate the batch without writing counters/comments.
 * @return array|WP_Error
 */
function av123_video_boost_run( $dry_run = false ) {
	$settings = av123_get_homepage_settings();
	$boost    = $settings['boost'];

	if ( empty( $boost['enabled'] ) && ! $dry_run ) {
		return new WP_Error( 'av123_boost_disabled', __( 'Video Boost is disabled.', 'av123' ) );
	}

	// Not every site registers a dedicated `video` post type — some store
	// videos as regular `post` entries with a resolvable video URL instead.
	// Boost whichever public content types the homepage is already
	// configured to use, same as the rest of the theme's query layer.
	$content_types = av123_homepage_content_types( $settings );
	if ( empty( $content_types ) ) {
		return new WP_Error( 'av123_boost_no_video_type', __( 'No usable content type is registered for Video Boost.', 'av123' ) );
	}
	if ( get_transient( 'av123_video_boost_lock' ) ) {
		return new WP_Error( 'av123_boost_locked', __( 'Another Video Boost batch is still running.', 'av123' ) );
	}

	set_transient( 'av123_video_boost_lock', 1, 10 * MINUTE_IN_SECONDS );
	$ids = get_posts(
		array(
			'post_type'              => $content_types,
			'post_status'            => 'publish',
			'posts_per_page'         => absint( $boost['target_count'] ),
			'orderby'                => 'date',
			'order'                  => 'DESC',
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		)
	);

	$authors   = av123_video_boost_lines( $boost['comment_authors'] );
	$messages  = av123_video_boost_lines( $boost['comment_templates'] );
	$result    = array(
		'ran_at_gmt'    => current_time( 'mysql', true ),
		'videos'        => count( $ids ),
		'views_added'   => 0,
		'likes_added'   => 0,
		'comments_added' => 0,
		'dry_run'       => (bool) $dry_run,
	);

	foreach ( $ids as $post_id ) {
		$views   = wp_rand( absint( $boost['views_min'] ), absint( $boost['views_max'] ) );
		$likes   = wp_rand( absint( $boost['likes_min'] ), absint( $boost['likes_max'] ) );
		$comments = ( $authors && $messages ) ? wp_rand( absint( $boost['comments_min'] ), absint( $boost['comments_max'] ) ) : 0;

		$result['views_added'] += $views;
		$result['likes_added'] += $likes;

		if ( ! $dry_run ) {
			update_post_meta( $post_id, '_sevenls_vp_view_count', av123_get_video_views( $post_id ) + $views );
			update_post_meta( $post_id, '_sevenls_vp_like_count', av123_get_video_likes( $post_id ) + $likes );
		}

		for ( $i = 0; $i < $comments; $i++ ) {
			if ( $dry_run ) {
				++$result['comments_added'];
				continue;
			}

			$comment_id = wp_insert_comment(
				array(
					'comment_post_ID'      => $post_id,
					'comment_author'       => $authors[ wp_rand( 0, count( $authors ) - 1 ) ],
					'comment_author_email' => '',
					'comment_author_url'   => '',
					'comment_content'      => $messages[ wp_rand( 0, count( $messages ) - 1 ) ],
					'comment_type'         => 'comment',
					'comment_approved'     => 1,
					'comment_agent'        => '123AV Video Boost',
					'comment_date'         => current_time( 'mysql' ),
					'comment_date_gmt'     => current_time( 'mysql', true ),
				)
			);

			if ( $comment_id ) {
				add_comment_meta( $comment_id, '_av123_video_boost', 1, true );
				++$result['comments_added'];
			}
		}
	}

	delete_transient( 'av123_video_boost_lock' );
	if ( ! $dry_run ) {
		update_option( AV123_VIDEO_BOOST_LAST_RUN_OPTION, $result, false );
	}

	return $result;
}
add_action( AV123_VIDEO_BOOST_HOOK, 'av123_video_boost_run' );

/** Return the most recent completed batch. */
function av123_video_boost_last_run() {
	$value = get_option( AV123_VIDEO_BOOST_LAST_RUN_OPTION, array() );
	return is_array( $value ) ? $value : array();
}

/** Format the last-run data for the admin screen. */
function av123_video_boost_last_run_summary( $result ) {
	$date = ! empty( $result['ran_at_gmt'] ) ? get_date_from_gmt( $result['ran_at_gmt'], 'Y-m-d H:i:s' ) : __( 'Unknown time', 'av123' );
	return sprintf(
		/* translators: 1: date, 2: videos, 3: views, 4: likes, 5: comments. */
		__( '%1$s — %2$d videos, +%3$d views, +%4$d likes, +%5$d comments', 'av123' ),
		$date,
		absint( $result['videos'] ?? 0 ),
		absint( $result['views_added'] ?? 0 ),
		absint( $result['likes_added'] ?? 0 ),
		absint( $result['comments_added'] ?? 0 )
	);
}

/** Handle the authenticated Run now control. */
function av123_video_boost_admin_run() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die(
			esc_html__( 'You are not allowed to run Video Boost.', 'av123' ),
			esc_html__( 'Forbidden', 'av123' ),
			array( 'response' => 403 )
		);
	}
	check_admin_referer( 'av123_run_video_boost' );

	$result = av123_video_boost_run();
	set_transient( 'av123_video_boost_notice_' . get_current_user_id(), $result, MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'themes.php?page=' . AV123_HOMEPAGE_PAGE ) );
	exit;
}
add_action( 'admin_post_av123_run_video_boost', 'av123_video_boost_admin_run' );

/** Show the result of a manual batch once. */
function av123_video_boost_admin_notice() {
	if ( empty( $_GET['page'] ) || AV123_HOMEPAGE_PAGE !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
		return;
	}
	$key    = 'av123_video_boost_notice_' . get_current_user_id();
	$result = get_transient( $key );
	if ( false === $result ) {
		return;
	}
	delete_transient( $key );

	if ( is_wp_error( $result ) ) {
		printf( '<div class="notice notice-error is-dismissible"><p>%s</p></div>', esc_html( $result->get_error_message() ) );
		return;
	}
	printf( '<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html( av123_video_boost_last_run_summary( $result ) ) );
}
add_action( 'admin_notices', 'av123_video_boost_admin_notice' );
