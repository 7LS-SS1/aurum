<?php
/**
 * Video URL and native player compatibility helpers.
 *
 * @package 123AV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Whether the queried singular post should render as a video (CPT `video` or a post with a resolvable video URL). */
function av123_is_video_singular() {
	if ( ! is_singular() ) {
		return false;
	}

	$post_id = get_queried_object_id();

	return 'video' === get_post_type( $post_id ) || (bool) av123_get_video_url( $post_id );
}

/** Resolve the first supported video URL without changing plugin-owned data. */
function av123_get_video_url( $post_id ) {
	foreach ( array( '_sevenls_vp_playback_url', '_sevenls_vp_video_url', 'aurum_video_url', 'video_url', '_misiav_video_url' ) as $meta_key ) {
		$url = trim( (string) get_post_meta( $post_id, $meta_key, true ) );
		if ( $url && wp_http_validate_url( $url ) ) {
			return esc_url_raw( $url );
		}
	}

	$content = (string) get_post_field( 'post_content', $post_id );
	if ( preg_match( '~https?://[^\s"\'<>]+\.(?:mp4|m3u8|webm|ogg)(?:\?[^\s"\'<>]*)?~i', $content, $match ) ) {
		return esc_url_raw( html_entity_decode( $match[0] ) );
	}

	return '';
}

/**
 * Strip the raw "aurum-video" embed block some imported posts carry in
 * post_content (an `<!-- aurum-video -->` marker plus a `.aurum-video` div
 * with its own "Watch video" link to the unproxied source URL). The theme's
 * native player already extracts and plays that same URL, so showing this
 * block too is redundant and exposes the raw CDN link needlessly.
 */
function av123_strip_aurum_video_embed( $content ) {
	if ( ! av123_is_video_singular() ) {
		return $content;
	}

	$content = preg_replace( '~<div\b[^>]*\bclass=["\'][^"\']*\baurum-video\b[^"\']*["\'][^>]*>.*?</div>~is', '', $content );
	$content = preg_replace( '~<p>\s*<!--\s*aurum-video\s*-->\s*</p>~i', '', $content );
	$content = preg_replace( '~<!--\s*aurum-video\s*-->~i', '', $content );

	return $content;
}
add_filter( 'the_content', 'av123_strip_aurum_video_embed', 5 );

/** Return a safe native/embedded video player for the single-video template. */
function av123_video_player_html( $post_id ) {
	$url    = av123_get_video_url( $post_id );
	// The post's Featured Image is the intended cover for the single-video
	// player.  The card helper deliberately omits it because cards resolve that
	// image independently, so prefer it here before falling back to publisher
	// thumbnail metadata or the theme placeholder.
	$poster = has_post_thumbnail( $post_id )
		? get_the_post_thumbnail_url( $post_id, 'full' )
		: av123_homepage_fallback_thumbnail_url( $post_id );
	$title  = get_the_title( $post_id );

	if ( ! $url ) {
		return '<div class="av123-player-message">' . esc_html__( 'No playable video URL is available.', 'av123' ) . '</div>';
	}

	if ( preg_match( '~(?:youtube\.com/watch\?v=|youtu\.be/)([A-Za-z0-9_-]+)~', $url, $match ) ) {
		return sprintf(
			'<div class="av123-player-frame"><iframe src="https://www.youtube.com/embed/%1$s" title="%2$s" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>',
			esc_attr( $match[1] ),
			esc_attr( $title )
		);
	}

	if ( preg_match( '~vimeo\.com/(\d+)~', $url, $match ) ) {
		return sprintf(
			'<div class="av123-player-frame"><iframe src="https://player.vimeo.com/video/%1$s" title="%2$s" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe></div>',
			esc_attr( $match[1] ),
			esc_attr( $title )
		);
	}

	$path      = (string) wp_parse_url( $url, PHP_URL_PATH );
	$extension = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

	// Let the active 7LS publisher supply HLS.js for m3u8 sources when present.
	if ( 'm3u8' === $extension && shortcode_exists( 'sevenls_video_post' ) ) {
		return '<div data-av123-player>' . do_shortcode( '[sevenls_video_post id="' . absint( $post_id ) . '" height="70vh" min_height="260px" max_height="760px" fit="contain" radius="14px"]' ) . '</div>';
	}

	$mime = array(
		'mp4'  => 'video/mp4',
		'webm' => 'video/webm',
		'ogg'  => 'video/ogg',
	)[ $extension ] ?? '';

	return sprintf(
		'<div class="av123-player-frame" data-av123-player><video controls playsinline preload="metadata" data-av123-video%1$s><source src="%2$s"%3$s>%4$s</video></div>',
		$poster ? ' poster="' . esc_url( $poster ) . '"' : '',
		esc_url( $url ),
		$mime ? ' type="' . esc_attr( $mime ) . '"' : '',
		esc_html__( 'Your browser does not support the video tag.', 'av123' )
	);
}

/**
 * Return chip-link markup for a video taxonomy's assigned terms.
 *
 * @param int    $post_id  Post ID.
 * @param string|string[] $taxonomy Taxonomy slug or preferred taxonomy slugs.
 * @return string Empty string when the post has no terms in this taxonomy.
 */
function av123_video_taxonomy_chips( $post_id, $taxonomy ) {
	$terms = array();
	foreach ( (array) $taxonomy as $candidate_taxonomy ) {
		if ( ! taxonomy_exists( $candidate_taxonomy ) ) {
			continue;
		}

		$candidate_terms = get_the_terms( $post_id, $candidate_taxonomy );
		if ( is_array( $candidate_terms ) && $candidate_terms ) {
			$terms = $candidate_terms;
			break;
		}
	}

	if ( ! $terms ) {
		return '';
	}

	$links = array();
	foreach ( $terms as $term ) {
		$links[] = sprintf(
			'<a class="chip" href="%1$s">%2$s</a>',
			esc_url( get_term_link( $term ) ),
			esc_html( $term->name )
		);
	}

	return implode( '', $links );
}

/** Format a large count compactly, e.g. 13200 -> "13.2K". */
function av123_format_compact_number( $number ) {
	$number = (float) $number;

	if ( $number >= 1000000 ) {
		return rtrim( rtrim( number_format_i18n( $number / 1000000, 1 ), '0' ), '.' ) . 'M';
	}

	if ( $number >= 1000 ) {
		return rtrim( rtrim( number_format_i18n( $number / 1000, 1 ), '0' ), '.' ) . 'K';
	}

	return number_format_i18n( $number );
}

/** Build a related-video query from real assigned taxonomy terms. */
function av123_related_query_args( $post_id, $posts_per_page, $exclude = array() ) {
	$tax_query = array( 'relation' => 'OR' );
	foreach ( array( 'video_actor', 'aurum_video_actor', 'actors', 'video_category', 'category', 'video_tag', 'post_tag' ) as $taxonomy ) {
		if ( ! taxonomy_exists( $taxonomy ) || ! is_object_in_taxonomy( get_post_type( $post_id ), $taxonomy ) ) {
			continue;
		}
		$term_ids = wp_get_object_terms( $post_id, $taxonomy, array( 'fields' => 'ids' ) );
		if ( ! is_wp_error( $term_ids ) && $term_ids ) {
			$tax_query[] = array( 'taxonomy' => $taxonomy, 'field' => 'term_id', 'terms' => array_map( 'absint', $term_ids ) );
		}
	}

	$args = array(
		'post_type'              => av123_homepage_content_types(),
		'post_status'            => 'publish',
		'posts_per_page'         => absint( $posts_per_page ),
		'post__not_in'           => array_values( array_unique( array_filter( array_map( 'absint', array_merge( array( $post_id ), (array) $exclude ) ) ) ) ),
		'ignore_sticky_posts'    => true,
		'orderby'                => 'date',
		'order'                  => 'DESC',
		'no_found_rows'          => true,
		'update_post_meta_cache' => true,
		'update_post_term_cache' => true,
	);
	if ( count( $tax_query ) > 1 ) {
		$args['tax_query'] = $tax_query;
	}
	return apply_filters( 'av123_related_query_args', $args, $post_id );
}

/** AJAX: return more "You might like" video cards, excluding IDs already shown. */
function av123_ajax_load_more_related() {
	check_ajax_referer( 'av123_related_videos', 'nonce' );

	$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
	$exclude = isset( $_POST['exclude'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['exclude'] ) ) : array();
	$exclude[] = $post_id;

	$per_page = 8;
	$query    = new WP_Query( av123_related_query_args( $post_id, $per_page + 1, $exclude ) );

	$posts    = $query->posts;
	$has_more = count( $posts ) > $per_page;
	$posts    = array_slice( $posts, 0, $per_page );

	ob_start();
	foreach ( $posts as $related_post ) {
		get_template_part( 'template-parts/home/card', null, array( 'post' => $related_post ) );
	}
	$html = ob_get_clean();

	wp_send_json_success(
		array(
			'html'    => $html,
			'hasMore' => $has_more,
		)
	);
}
add_action( 'wp_ajax_av123_load_more_related', 'av123_ajax_load_more_related' );
add_action( 'wp_ajax_nopriv_av123_load_more_related', 'av123_ajax_load_more_related' );
