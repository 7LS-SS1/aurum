<?php
/**
 * Page template.
 *
 * @package 123AV
 */

get_header();
?>
<main class="feed">
	<div class="wrap">
		<div class="av123-page">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<h1><?php the_title(); ?></h1>
				<?php the_content(); ?>
				<?php
			endwhile;
			?>
		</div>
	</div>
</main>
<?php
get_footer();

