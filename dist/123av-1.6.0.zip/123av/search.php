<?php
/**
 * Search results template.
 *
 * @package 123AV
 */

get_header();
?>
<main class="feed">
	<div class="wrap">
		<section class="section">
			<div class="section__head">
				<h1 class="section__title">
					<?php
					printf(
						/* translators: %s: search query. */
						esc_html__( 'Search results for: %s', 'av123' ),
						esc_html( get_search_query() )
					);
					?>
				</h1>
			</div>
			<?php if ( have_posts() ) : ?>
				<div class="grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content-card' );
					endwhile;
					?>
				</div>
				<?php the_posts_pagination(); ?>
			<?php else : ?>
				<p><?php esc_html_e( 'No results found.', 'av123' ); ?></p>
			<?php endif; ?>
		</section>
	</div>
</main>
<?php
get_footer();

