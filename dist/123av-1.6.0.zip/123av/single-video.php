<?php
/**
 * Theme-owned single video page with a native player and engagement UI.
 *
 * @package 123AV
 */

// The Ads Banner Add-on normally auto-places video_top/video_bottom banners
// two ways: wrapping the_content() (inject_content_banners) and, as a
// fallback for themes with a separate player markup, DOM-placement
// <template> tags moved by its front-end JS (render_dom_fallbacks). This
// template renders both positions itself — video_top at the top of <main>,
// above the player — so both automatic paths are unhooked to avoid showing
// the same banner twice.
if ( class_exists( 'Retrotube_Banner_Frontend' ) ) {
	$av123_rtb_banner_frontend = Retrotube_Banner_Frontend::instance();
	remove_filter( 'the_content', array( $av123_rtb_banner_frontend, 'inject_content_banners' ), 20 );
	remove_action( 'wp_footer', array( $av123_rtb_banner_frontend, 'render_dom_fallbacks' ), 5 );
}

get_header();
?>
<main class="feed av123-video-page">
	<div class="wrap watch">
		<?php if ( function_exists( 'ads_banner_addon_render' ) ) : ?>
			<div class="av123-video-page__ad av123-video-page__ad--top">
				<?php ads_banner_addon_render( 'video_top' ); ?>
			</div>
		<?php endif; ?>
		<?php
		while ( have_posts() ) :
			the_post();
			$post_id = get_the_ID();
			// Keep the single-page recommendations aligned with Homepage Control.
			// Production may store videos as normal posts, while a local install can
			// use the dedicated `video` post type.
			$related_per_page = 12;
			$related           = new WP_Query( av123_related_query_args( $post_id, $related_per_page + 1 ) );
			$related_posts    = $related->posts;
			$related_has_more = count( $related_posts ) > $related_per_page;
			$related_posts    = array_slice( $related_posts, 0, $related_per_page );

			$recommended = new WP_Query( av123_related_query_args( $post_id, 10, wp_list_pluck( $related_posts, 'ID' ) ) );

			$views    = av123_get_video_views( $post_id );
			$likes    = av123_get_video_likes( $post_id );
			$comments = get_comments_number( $post_id );

			// Imported content can use WordPress's built-in taxonomies while the
			// publisher plugin uses video_* taxonomies. Prefer the video taxonomy,
			// then gracefully show the assigned built-in terms instead of hiding data.
			$category_chips = av123_video_taxonomy_chips( $post_id, array( 'video_category', 'category' ) );
			$tag_chips       = av123_video_taxonomy_chips( $post_id, array( 'video_tag', 'post_tag' ) );
			$actor_chips     = av123_video_taxonomy_chips( $post_id, array( 'video_actor', 'aurum_video_actor', 'actors' ) );

			$raw_content       = trim( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) );
			$raw_title         = trim( wp_strip_all_tags( get_the_title( $post_id ) ) );
			$show_description  = '' !== $raw_content && $raw_content !== $raw_title;
			?>
			<div class="watch-layout">
				<div class="watch-main">
					<div class="watch__main">
						<section class="av123-video__player" aria-label="<?php esc_attr_e( 'Video player', 'av123' ); ?>">
							<?php echo av123_video_player_html( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</section>

						<div class="watch__head">
							<div class="watch__headinfo">
								<h1 class="watch__title"><?php the_title(); ?></h1>
								<div class="watch__meta watch__meta--stats">
									<span class="watch__metaitem">
										<svg class="watch__metaicon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 3"></path></svg>
										<?php
										printf(
											/* translators: %s: relative time, e.g. "2 hours". */
											esc_html__( '%s ago', 'av123' ),
											esc_html( human_time_diff( get_the_time( 'U', $post_id ), current_time( 'timestamp' ) ) )
										);
										?>
									</span>
									<span class="watch__metaitem">
										<svg class="watch__metaicon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12S5 5 12 5s11 7 11 7-4 7-11 7-11-7-11-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
										<?php printf( esc_html__( '%s views', 'av123' ), esc_html( av123_format_compact_number( $views ) ) ); ?>
									</span>
								</div>
							</div>
							<button type="button" class="watch__save" data-av123-like data-post-id="<?php echo esc_attr( $post_id ); ?>">
								<span aria-hidden="true">♥</span>
								<?php esc_html_e( 'Like', 'av123' ); ?>
								<strong data-av123-like-count><?php echo esc_html( number_format_i18n( $likes ) ); ?></strong>
							</button>
						</div>

						<?php if ( $show_description ) : ?>
							<div class="watch__block">
								<h2 class="watch__bhead"><?php esc_html_e( 'About this video', 'av123' ); ?></h2>
								<div class="watch__desc">
									<div class="watch__desc-text entry-content"><?php the_content(); ?></div>
								</div>
							</div>
						<?php endif; ?>

						<?php if ( function_exists( 'ads_banner_addon_render' ) ) : ?>
							<div class="av123-video-page__ad av123-video-page__ad--bottom">
								<?php ads_banner_addon_render( 'video_bottom' ); ?>
							</div>
						<?php endif; ?>

						<div class="watch__block">
							<h2 class="watch__bhead"><?php esc_html_e( 'Details', 'av123' ); ?></h2>
							<dl class="watch__info">
								<div class="watch__info-row">
									<dt><?php esc_html_e( 'Published', 'av123' ); ?></dt>
									<dd><time datetime="<?php echo esc_attr( get_the_date( DATE_W3C, $post_id ) ); ?>"><?php echo esc_html( get_the_date( '', $post_id ) ); ?></time></dd>
								</div>
								<div class="watch__info-row">
									<dt><?php esc_html_e( 'Comments', 'av123' ); ?></dt>
									<dd><a href="#comments"><?php echo esc_html( number_format_i18n( $comments ) ); ?></a></dd>
								</div>
								<?php if ( $category_chips ) : ?>
									<div class="watch__info-row">
										<dt><?php esc_html_e( 'Category', 'av123' ); ?></dt>
										<dd class="chips" data-av123-category-links><?php echo $category_chips; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></dd>
									</div>
								<?php endif; ?>
								<?php if ( $tag_chips ) : ?>
									<div class="watch__info-row">
										<dt><?php esc_html_e( 'Tags', 'av123' ); ?></dt>
										<dd class="chips"><?php echo $tag_chips; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></dd>
									</div>
								<?php endif; ?>
								<?php if ( $actor_chips ) : ?>
									<div class="watch__info-row">
										<dt><?php esc_html_e( 'Actor', 'av123' ); ?></dt>
										<dd class="chips av123-video-actor-chips" data-av123-actor-links><?php echo $actor_chips; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></dd>
									</div>
								<?php endif; ?>
							</dl>
						</div>
					</div>

					<?php comments_template(); ?>

					<?php if ( $related_posts ) : ?>
						<section class="rec__section">
							<div class="section__head"><h2 class="section__title"><i aria-hidden="true"></i><?php esc_html_e( 'You might like', 'av123' ); ?></h2></div>
							<div class="grid" data-av123-related-grid>
								<?php foreach ( $related_posts as $related_post ) : ?>
									<?php get_template_part( 'template-parts/home/card', null, array( 'post' => $related_post ) ); ?>
								<?php endforeach; ?>
							</div>
							<?php if ( $related_has_more ) : ?>
								<div class="rec__more" data-av123-load-more-wrap>
									<button type="button" class="rec__more-btn" data-av123-load-more data-post-id="<?php echo esc_attr( $post_id ); ?>">
										<?php esc_html_e( 'Load more', 'av123' ); ?>
									</button>
								</div>
							<?php endif; ?>
						</section>
					<?php endif; ?>
				</div>

				<?php if ( $recommended->have_posts() ) : ?>
					<aside class="watch-side">
						<h2 class="watch-side__title"><?php esc_html_e( 'Recommended', 'av123' ); ?></h2>
						<ul class="watch-side__list">
							<?php
							while ( $recommended->have_posts() ) :
								$recommended->the_post();
								$side_id       = get_the_ID();
								$side_duration = av123_homepage_duration( $side_id );
								$side_thumb    = has_post_thumbnail( $side_id ) ? get_the_post_thumbnail_url( $side_id, 'av123-card' ) : av123_homepage_fallback_thumbnail_url( $side_id );
								?>
								<li>
									<a class="vside" href="<?php the_permalink(); ?>">
										<span class="vside__thumb" style="background-image:url('<?php echo esc_url( $side_thumb ); ?>')">
											<?php if ( $side_duration ) : ?><span class="vside__dur"><?php echo esc_html( $side_duration ); ?></span><?php endif; ?>
										</span>
										<span class="vside__body">
											<span class="vside__title"><?php the_title(); ?></span>
											<span class="vside__meta">
												<?php
												printf(
													/* translators: 1: relative time, e.g. "2 hours"; 2: view count. */
													esc_html__( '%1$s ago · %2$s views', 'av123' ),
													esc_html( human_time_diff( get_the_time( 'U', $side_id ), current_time( 'timestamp' ) ) ),
													esc_html( av123_format_compact_number( av123_get_video_views( $side_id ) ) )
												);
												?>
											</span>
										</span>
									</a>
								</li>
							<?php endwhile; ?>
						</ul>
					</aside>
					<?php wp_reset_postdata(); ?>
				<?php endif; ?>
			</div>
		<?php endwhile; ?>
	</div>
</main>
<?php
get_footer();
