<?php
/**
 * Dynamic single post/video template.
 *
 * @package 123AV
 */

if ( av123_is_video_singular() ) {
	get_template_part( 'single-video' );
	return;
}

get_header();
?>
<main class="feed av123-single">
	<div class="wrap">
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article <?php post_class( 'av123-entry' ); ?>>
				<header class="av123-entry__header">
					<h1 class="av123-entry__title"><?php the_title(); ?></h1>
					<div class="av123-entry__meta">
						<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
						<?php the_category( ', ' ); ?>
					</div>
				</header>
				<div class="entry-content av123-entry__content">
					<?php the_content(); ?>
				</div>
				<?php the_tags( '<div class="av123-entry__tags">', ' ', '</div>' ); ?>
			</article>
		<?php endwhile; ?>
	</div>
</main>
<?php
get_footer();
