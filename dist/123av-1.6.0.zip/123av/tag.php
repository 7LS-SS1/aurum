<?php
/**
 * Tag archive template.
 *
 * @package 123AV
 */

get_template_part( 'archive' );
