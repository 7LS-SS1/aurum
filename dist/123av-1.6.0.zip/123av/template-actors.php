<?php
/**
 * Template Name: Actors
 *
 * @package 123AV
 */

get_header();

while ( have_posts() ) {
	the_post();
	get_template_part( 'template-parts/term-directory', null, array( 'config' => av123_directory_config( 'actors' ) ) );
}

get_footer();
