<?php
/** Actor directory at /actres/. @package 123AV */
get_header();
$config = av123_directory_config( 'actors' );
$config['title'] = __( 'Actors', 'av123' );
$config['url']   = home_url( '/actres/' );
get_template_part( 'template-parts/term-directory', null, array( 'config' => $config ) );
get_footer();
