<?php
/** Actor profile at /actres/{actor-slug}/. @package 123AV */
get_header();
$av123_actor_taxonomy = av123_actor_profile_taxonomy();
$actor = $av123_actor_taxonomy ? get_term_by( 'slug', sanitize_title( (string) get_query_var( 'av123_actor' ) ), $av123_actor_taxonomy ) : false;
if ( ! $actor || is_wp_error( $actor ) ) { global $wp_query; $wp_query->set_404(); status_header( 404 ); get_template_part( '404' ); get_footer(); return; }
$meta  = av123_actor_profile_meta( $actor->term_id );
$image = av123_actor_profile_image_url( $actor->term_id );
// The actor's own taxonomy (not a hardcoded one) and the site's real content
// post types (`post` on production, `video` where the 7M plugin's CPT is
// active) — same pattern already used by av123_related_query_args().
$videos = new WP_Query( array( 'post_type' => av123_homepage_content_types(), 'post_status' => 'publish', 'posts_per_page' => 24, 'tax_query' => array( array( 'taxonomy' => $actor->taxonomy, 'field' => 'term_id', 'terms' => $actor->term_id ) ) ) );
?>
<main class="feed av123-actor-profile"><div class="wrap">
	<a class="av123-actor-profile__back" href="<?php echo esc_url( home_url( '/actors/' ) ); ?>">← <?php esc_html_e( 'All actors', 'av123' ); ?></a>
	<header class="av123-actor-profile__hero">
		<div class="av123-actor-profile__portrait"><?php if ( $image ) : ?><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $actor->name ); ?>"><?php else : ?><span><?php echo esc_html( function_exists( 'mb_substr' ) ? mb_substr( $actor->name, 0, 1 ) : substr( $actor->name, 0, 1 ) ); ?></span><?php endif; ?></div>
		<div><p class="av123-actor-profile__eyebrow"><?php esc_html_e( 'Performer profile', 'av123' ); ?></p><h1><?php echo esc_html( $actor->name ); ?></h1><p class="av123-actor-profile__count"><?php echo esc_html( sprintf( _n( '%s video', '%s videos', $actor->count, 'av123' ), number_format_i18n( $actor->count ) ) ); ?></p></div>
	</header>
	<?php if ( $meta['bio'] ?? '' ) : ?><section class="av123-actor-profile__bio entry-content"><?php echo wp_kses_post( wpautop( $meta['bio'] ) ); ?></section><?php endif; ?>
	<?php $stats=array_filter(array( 'Age' => $meta['age'] ?? '', 'Height' => ! empty($meta['height']) ? $meta['height'].' cm' : '', 'Weight' => ! empty($meta['weight']) ? $meta['weight'].' kg' : '', 'Measurements' => array_filter(array($meta['bust'] ?? '',$meta['waist'] ?? '',$meta['hips'] ?? '')) ? implode('–',array_filter(array($meta['bust'] ?? '',$meta['waist'] ?? '',$meta['hips'] ?? ''))).' cm' : '' )); if($stats): ?><dl class="av123-actor-profile__stats"><?php foreach($stats as $label=>$value): ?><div><dt><?php echo esc_html__( $label, 'av123' ); ?></dt><dd><?php echo esc_html( $value ); ?></dd></div><?php endforeach; ?></dl><?php endif; ?>
	<section class="av123-actor-profile__videos"><h2><?php esc_html_e( 'Videos', 'av123' ); ?></h2><?php if($videos->have_posts()): ?><div class="grid"><?php while($videos->have_posts()):$videos->the_post(); get_template_part('template-parts/home/card'); endwhile; wp_reset_postdata(); ?></div><?php else: ?><p><?php esc_html_e( 'No videos are available for this actor yet.', 'av123' ); ?></p><?php endif; ?></section>
</div></main>
<?php get_footer();
