<?php
/**
 * Template Name: Categories
 *
 * @package 123AV
 */

get_header();

while ( have_posts() ) {
	the_post();
	get_template_part( 'template-parts/term-directory', null, array( 'config' => av123_directory_config( 'categories' ) ) );
}

get_footer();
