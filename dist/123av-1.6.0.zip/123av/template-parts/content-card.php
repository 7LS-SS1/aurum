<?php
/**
 * Post card used by dynamic WordPress fallback loops.
 *
 * @package 123AV
 */

$post = get_post();
get_template_part( 'template-parts/home/card', null, array( 'post' => $post ) );
