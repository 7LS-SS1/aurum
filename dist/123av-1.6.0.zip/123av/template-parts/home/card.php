<?php
/**
 * Dynamic post/video card.
 *
 * @package 123AV
 */

$post = isset( $args['post'] ) && $args['post'] instanceof WP_Post ? $args['post'] : get_post();

if ( ! $post ) {
	return;
}

$duration = av123_homepage_duration( $post->ID );
$is_video = 'video' === $post->post_type;
$preview  = $is_video ? av123_homepage_preview_url( $post->ID ) : '';
?>
<article <?php post_class( 'card av123-card', $post->ID ); ?> data-post-id="<?php echo esc_attr( $post->ID ); ?>">
	<div class="card__poster av123-card__poster"<?php if ( $preview ) : ?> data-av123-preview="<?php echo esc_url( $preview ); ?>"<?php endif; ?>>
		<a class="card__cover" href="<?php echo esc_url( get_permalink( $post ) ); ?>" data-av123-related-link data-target-id="<?php echo esc_attr( $post->ID ); ?>">
			<?php echo av123_homepage_image_html( $post->ID, 'av123-card', 'card__img' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<span class="card__shade"></span>
			<?php if ( $duration ) : ?><span class="card__dur"><?php echo esc_html( $duration ); ?></span><?php endif; ?>
		</a>
	</div>
	<div class="card__body">
		<h3 class="card__title"><a class="card__link" href="<?php echo esc_url( get_permalink( $post ) ); ?>" data-av123-related-link data-target-id="<?php echo esc_attr( $post->ID ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a></h3>
		<div class="card__meta">
			<time datetime="<?php echo esc_attr( get_the_date( DATE_W3C, $post ) ); ?>"><?php echo esc_html( get_the_date( '', $post ) ); ?></time>
			<?php if ( $is_video ) : ?>
				<span class="card__engagement" aria-label="<?php esc_attr_e( 'Video engagement', 'av123' ); ?>">
					<span title="<?php esc_attr_e( 'Views', 'av123' ); ?>">◉ <?php echo esc_html( number_format_i18n( av123_get_video_views( $post->ID ) ) ); ?></span>
					<span title="<?php esc_attr_e( 'Likes', 'av123' ); ?>">♥ <?php echo esc_html( number_format_i18n( av123_get_video_likes( $post->ID ) ) ); ?></span>
				</span>
			<?php endif; ?>
		</div>
	</div>
</article>
