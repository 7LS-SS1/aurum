<?php
/**
 * Homepage hero slider.
 *
 * @package 123AV
 */

$posts       = isset( $args['posts'] ) && is_array( $args['posts'] ) ? $args['posts'] : array();
$title       = isset( $args['title'] ) ? $args['title'] : '';
$heading_tag = isset( $args['heading_tag'] ) && in_array( $args['heading_tag'], array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ? $args['heading_tag'] : 'h2';

if ( ! $posts ) {
	return;
}
?>
<section class="section av123-hero" data-av123-hero aria-label="<?php echo esc_attr( $title ?: __( 'Featured videos', 'av123' ) ); ?>">
	<?php if ( $title ) : ?>
		<div class="section__head av123-hero__head">
			<<?php echo tag_escape( $heading_tag ); ?> class="section__title av123-hero__title"><i></i><?php echo esc_html( $title ); ?></<?php echo tag_escape( $heading_tag ); ?>>
		</div>
	<?php endif; ?>

	<div class="av123-hero__viewport" tabindex="0" data-hero-viewport>
		<div class="av123-hero__track">
			<?php foreach ( $posts as $index => $post ) : ?>
				<article class="featured av123-hero__slide" data-hero-slide data-post-id="<?php echo esc_attr( $post->ID ); ?>">
					<a class="featured__poster av123-hero__poster" href="<?php echo esc_url( get_permalink( $post ) ); ?>" data-av123-related-link data-target-id="<?php echo esc_attr( $post->ID ); ?>">
						<?php echo av123_homepage_image_html( $post->ID, 'av123-hero', 'featured__img', 0 === $index ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span class="featured__shade"></span>
						<?php $duration = av123_homepage_duration( $post->ID ); ?>
						<?php if ( $duration ) : ?><span class="featured__dur"><?php echo esc_html( $duration ); ?></span><?php endif; ?>
						<span class="av123-hero__caption"><span class="featured__title"><?php echo esc_html( get_the_title( $post ) ); ?></span></span>
					</a>
				</article>
			<?php endforeach; ?>
		</div>
	</div>

	<?php if ( count( $posts ) > 1 ) : ?>
		<div class="av123-hero__controls">
			<button type="button" class="av123-hero__arrow" data-hero-prev aria-label="<?php esc_attr_e( 'Previous video', 'av123' ); ?>">&larr;</button>
			<div class="av123-hero__dots" aria-hidden="true">
				<?php foreach ( $posts as $index => $post ) : ?>
					<span class="av123-hero__dot<?php echo 0 === $index ? ' is-active' : ''; ?>" data-hero-dot="<?php echo esc_attr( $index ); ?>"></span>
				<?php endforeach; ?>
			</div>
			<button type="button" class="av123-hero__arrow" data-hero-next aria-label="<?php esc_attr_e( 'Next video', 'av123' ); ?>">&rarr;</button>
		</div>
	<?php endif; ?>
</section>
