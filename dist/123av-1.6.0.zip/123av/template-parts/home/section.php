<?php
/**
 * Repeatable homepage section.
 *
 * @package 123AV
 */

$section     = isset( $args['section'] ) && is_array( $args['section'] ) ? $args['section'] : array();
$posts       = isset( $args['posts'] ) && is_array( $args['posts'] ) ? $args['posts'] : array();
$link        = isset( $args['link'] ) ? $args['link'] : '';
$heading_tag = isset( $section['heading_tag'] ) && in_array( $section['heading_tag'], array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ? $section['heading_tag'] : 'h2';
$section_id  = ! empty( $section['id'] ) ? sanitize_title( $section['id'] ) : wp_unique_id( 'section-' );
$style       = sprintf(
	'--av123-cols-desktop:%d;--av123-cols-tablet:%d;--av123-cols-mobile:%d;',
	av123_homepage_int_range( $section['columns_desktop'] ?? 4, 2, 6, 4 ),
	av123_homepage_int_range( $section['columns_tablet'] ?? 3, 2, 4, 3 ),
	av123_homepage_int_range( $section['columns_mobile'] ?? 2, 1, 3, 2 )
);

if ( ! $posts ) {
	return;
}
?>
<section class="section av123-video-section" id="av123-section-<?php echo esc_attr( $section_id ); ?>" style="<?php echo esc_attr( $style ); ?>">
	<div class="section__head">
		<<?php echo tag_escape( $heading_tag ); ?> class="section__title"><i></i><?php echo esc_html( $section['title'] ?? '' ); ?></<?php echo tag_escape( $heading_tag ); ?>>
		<?php if ( $link ) : ?>
			<a class="section__all av123-section-more" href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $section['more_label'] ?: __( 'View more', 'av123' ) ); ?><span aria-hidden="true">&rarr;</span></a>
		<?php endif; ?>
	</div>
	<div class="grid av123-video-grid">
		<?php foreach ( $posts as $post ) : ?>
			<?php get_template_part( 'template-parts/home/card', null, array( 'post' => $post ) ); ?>
		<?php endforeach; ?>
	</div>
</section>
