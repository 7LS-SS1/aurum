<?php
/**
 * Shared term directory UI.
 *
 * @package 123AV
 */

$config = isset( $args['config'] ) && is_array( $args['config'] ) ? $args['config'] : array();
$data   = av123_directory_data( $config );
$key    = sanitize_html_class( $config['key'] ?? 'terms' );
$title  = $config['title'] ?? get_the_title();
$url    = $config['url'] ?? get_permalink();
?>
<main class="feed av123-directory av123-directory--<?php echo esc_attr( $key ); ?>">
	<div class="wrap">
		<header class="av123-directory__hero">
			<div class="av123-directory__hero-copy">
				<p class="av123-directory__eyebrow"><?php esc_html_e( 'Browse library', 'av123' ); ?></p>
				<h1><?php echo esc_html( $title ); ?></h1>
				<p><?php echo esc_html( $config['description'] ?? '' ); ?></p>
			</div>
			<div class="av123-directory__total" aria-label="<?php esc_attr_e( 'Available terms', 'av123' ); ?>">
				<strong><?php echo esc_html( number_format_i18n( $data['total'] ) ); ?></strong>
				<span><?php esc_html_e( 'collections', 'av123' ); ?></span>
			</div>
		</header>

		<?php if ( trim( get_the_content() ) ) : ?>
			<div class="av123-directory__intro entry-content"><?php the_content(); ?></div>
		<?php endif; ?>

		<form class="av123-directory__toolbar" action="<?php echo esc_url( $url ); ?>" method="get" role="search">
			<label class="av123-directory__search">
				<span class="screen-reader-text"><?php echo esc_html( $config['search_label'] ?? __( 'Search directory', 'av123' ) ); ?></span>
				<svg aria-hidden="true" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"></circle><path d="m20 20-4-4"></path></svg>
				<input type="search" name="directory_search" value="<?php echo esc_attr( $data['search'] ); ?>" placeholder="<?php echo esc_attr( $config['search_label'] ?? __( 'Search directory', 'av123' ) ); ?>">
			</label>
			<label class="av123-directory__sort">
				<span><?php esc_html_e( 'Sort', 'av123' ); ?></span>
				<select name="directory_sort">
					<option value="popular" <?php selected( $data['sort'], 'popular' ); ?>><?php esc_html_e( 'Most popular', 'av123' ); ?></option>
					<option value="name" <?php selected( $data['sort'], 'name' ); ?>><?php esc_html_e( 'Name A–Z', 'av123' ); ?></option>
				</select>
			</label>
			<button type="submit"><?php esc_html_e( 'Apply', 'av123' ); ?></button>
			<?php if ( '' !== $data['search'] || 'popular' !== $data['sort'] ) : ?>
				<a class="av123-directory__clear" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Clear', 'av123' ); ?></a>
			<?php endif; ?>
		</form>

		<div class="av123-directory__summary" aria-live="polite">
			<?php
			printf(
				/* translators: 1: first displayed result, 2: last displayed result, 3: total results. */
				esc_html__( 'Showing %1$s–%2$s of %3$s', 'av123' ),
				esc_html( number_format_i18n( $data['range_start'] ) ),
				esc_html( number_format_i18n( $data['range_end'] ) ),
				esc_html( number_format_i18n( $data['total'] ) )
			);
			?>
		</div>

		<?php if ( ! $data['taxonomy'] ) : ?>
			<div class="av123-directory__empty">
				<h2><?php esc_html_e( 'Directory unavailable', 'av123' ); ?></h2>
				<p><?php esc_html_e( 'The required video taxonomy is not currently registered.', 'av123' ); ?></p>
			</div>
		<?php elseif ( $data['error'] ) : ?>
			<div class="av123-directory__empty">
				<h2><?php esc_html_e( 'Unable to load this directory', 'av123' ); ?></h2>
				<p><?php esc_html_e( 'Please refresh the page and try again.', 'av123' ); ?></p>
			</div>
		<?php elseif ( $data['terms'] ) : ?>
			<div class="av123-term-grid">
				<?php foreach ( $data['terms'] as $term ) : ?>
					<?php
					$term_link = get_term_link( $term );
					if ( is_wp_error( $term_link ) ) {
						continue;
					}
					$initial     = function_exists( 'mb_substr' ) ? mb_substr( $term->name, 0, 1 ) : substr( $term->name, 0, 1 );
					$videos_text = sprintf(
						/* translators: %s: number of videos. */
						_n( '%s video', '%s videos', $term->count, 'av123' ),
						number_format_i18n( $term->count )
					);
					?>
					<article class="av123-term-card av123-term-card--<?php echo esc_attr( $key ); ?>">
						<a href="<?php echo esc_url( $term_link ); ?>">
							<span class="av123-term-card__mark" aria-hidden="true">
								<?php if ( 'categories' === $key ) : ?>
									<svg viewBox="0 0 24 24"><path d="M3 6.5h6l2 2h10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
								<?php elseif ( 'tags' === $key ) : ?>
									#
								<?php else : ?>
									<?php echo esc_html( $initial ); ?>
								<?php endif; ?>
							</span>
							<span class="av123-term-card__copy">
								<strong><?php echo esc_html( $term->name ); ?></strong>
								<small><?php echo esc_html( $videos_text ); ?></small>
							</span>
							<svg class="av123-term-card__arrow" aria-hidden="true" viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"></path></svg>
						</a>
					</article>
				<?php endforeach; ?>
			</div>

			<?php if ( $data['total_pages'] > 1 ) : ?>
				<?php
				$pagination_args = array();
				if ( '' !== $data['search'] ) {
					$pagination_args['directory_search'] = $data['search'];
				}
				if ( 'popular' !== $data['sort'] ) {
					$pagination_args['directory_sort'] = $data['sort'];
				}
				$pagination = paginate_links(
					array(
						'base'      => add_query_arg( 'directory_page', '%#%', $url ),
						'format'    => '',
						'current'   => $data['page'],
						'total'     => $data['total_pages'],
						'mid_size'  => 2,
						'end_size'  => 1,
						'prev_text' => __( 'Previous', 'av123' ),
						'next_text' => __( 'Next', 'av123' ),
						'add_args'  => $pagination_args,
					)
				);
				?>
				<nav class="navigation pagination" aria-label="<?php esc_attr_e( 'Directory pagination', 'av123' ); ?>">
					<div class="nav-links"><?php echo wp_kses_post( $pagination ); ?></div>
				</nav>
			<?php endif; ?>
		<?php else : ?>
			<div class="av123-directory__empty">
				<h2><?php echo esc_html( $config['empty_message'] ?? __( 'No items found.', 'av123' ) ); ?></h2>
				<p><?php esc_html_e( 'Try a shorter search term or clear the current filters.', 'av123' ); ?></p>
				<a href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'View all collections', 'av123' ); ?></a>
			</div>
		<?php endif; ?>
	</div>
</main>
