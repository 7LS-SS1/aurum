import { NextRequest } from "next/server";
import type { Prisma, MovieStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { createMovieSchema } from "@/lib/validation";
import { apiError, jsonOk, ApiError } from "@/lib/api-response";
import { requireMinRole } from "@/lib/authz";
import { logAudit } from "@/lib/audit";
import { rateLimit } from "@/lib/rate-limit";
import { buildJwPlayerIframeUrl, getDefaultJwPlayerConfig } from "@/lib/jwplayer";
import { invalidatePublicMovieCaches } from "@/lib/cache";
import { slugifyTitle } from "@/lib/slug";

const MOVIE_STATUSES = [
  "DRAFT",
  "READY_FOR_REVIEW",
  "IN_REVIEW",
  "REJECTED",
  "READY_FOR_APPROVAL",
  "APPROVED",
  "PUBLISHING",
  "DONE",
  "PARTIAL",
  "FAILED",
  "ARCHIVED",
] as const;

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((v): v is string => typeof v === "string" && v.length > 0) : [];
}

async function getUniqueMovieSlug(title: string, requestedSlug?: string) {
  const base = requestedSlug?.trim() || slugifyTitle(title, "video");
  let slug = base;
  let suffix = 2;

  while (await prisma.movie.findUnique({ where: { slug }, select: { id: true } })) {
    slug = `${base}-${suffix}`;
    suffix += 1;
  }

  return slug;
}

export async function GET(req: NextRequest) {
  try {
    await requireMinRole("STAFF");

    const { searchParams } = req.nextUrl;
    const requestedTake = Number(searchParams.get("take") ?? 20);
    const take = Number.isFinite(requestedTake) ? Math.min(Math.max(1, requestedTake), 100) : 20;
    const requestedPage = Math.max(1, Number(searchParams.get("page") ?? 1) || 1);

    const status = searchParams.get("status");
    const mainCategory = searchParams.get("mainCategory");
    const createdById = searchParams.get("createdById");
    const dateFrom = searchParams.get("dateFrom");
    const dateTo = searchParams.get("dateTo");
    const q = searchParams.get("q")?.trim();

    const where: Prisma.MovieWhereInput = {
      ...(status && MOVIE_STATUSES.includes(status as MovieStatus) ? { status: status as MovieStatus } : {}),
      ...(mainCategory ? { mainCategory } : {}),
      ...(createdById ? { createdById } : {}),
      ...(dateFrom || dateTo
        ? {
            createdAt: {
              ...(dateFrom ? { gte: new Date(dateFrom) } : {}),
              ...(dateTo ? { lte: new Date(dateTo) } : {}),
            },
          }
        : {}),
      ...(q
        ? { OR: [{ title: { contains: q, mode: "insensitive" } }, { slug: { contains: q, mode: "insensitive" } }] }
        : {}),
    };

    const total = await prisma.movie.count({ where });
    const totalPages = Math.max(1, Math.ceil(total / take));
    const page = Math.min(requestedPage, totalPages);

    const movies = await prisma.movie.findMany({
      where,
      take,
      skip: (page - 1) * take,
      orderBy: { createdAt: "desc" },
      include: { createdBy: { select: { id: true, name: true, email: true } } },
    });

    return jsonOk({ movies, pagination: { page, totalPages, total, pageSize: take } });
  } catch (err) {
    return apiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const actor = await requireMinRole("STAFF");

    const { success } = await rateLimit(`movies:create:${actor.id}`, { limit: 30, windowMs: 60_000 });
    if (!success) throw new ApiError("too_many_requests", 429);

    const input = createMovieSchema.parse(await req.json());
    const defaultPlayer = input.videoProvider === "jwplayer" ? await getDefaultJwPlayerConfig() : undefined;
    const iframeUrl = input.iframeUrl ?? buildJwPlayerIframeUrl(input.jwPlayerMediaId, defaultPlayer);
    const slug = await getUniqueMovieSlug(input.title, input.slug);

    // The upload wizard doesn't expose a per-site picker — it publishes to
    // every active destination that accepts this movie's main category, so
    // default targetSiteIds here when the caller didn't explicitly choose a
    // subset (e.g. a future admin tool). Without this, movies would sit at
    // APPROVED forever: the publish cron only picks up movies that already
    // have a non-empty targetSiteIds. A site with an empty mainCategories
    // list is unrestricted (legacy/unconfigured behavior — receives every
    // main category); one with entries only receives matching movies.
    const targetSiteIds = input.targetSiteIds.length
      ? input.targetSiteIds
      : (await prisma.targetSite.findMany({ where: { isActive: true }, select: { id: true, mainCategories: true } }))
          .filter((s) => {
            const accepted = asStringArray(s.mainCategories);
            return accepted.length === 0 || accepted.includes(input.mainCategory);
          })
          .map((s) => s.id);

    const movie = await prisma.movie.create({
      data: {
        title: input.title,
        slug,
        excerpt: input.excerpt,
        content: input.content,
        mainCategory: input.mainCategory,
        categories: input.categories,
        tags: { connectOrCreate: input.tags.map((name) => ({ where: { name }, create: { name } })) },
        actors: { connect: input.actorIds.map((id) => ({ id })) },
        thumbnailUrl: input.thumbnailUrl,
        previewUrl: input.previewUrl,
        iframeUrl,
        videoUrl: input.videoUrl,
        videoProvider: input.videoProvider,
        jwPlayerMediaId: input.jwPlayerMediaId,
        extraMeta: input.extraMeta as Prisma.InputJsonValue,
        targetSiteIds: targetSiteIds as Prisma.InputJsonValue,
        createdById: actor.id,
      },
    });

    await logAudit({ actor, action: "create_movie", resourceType: "movie", resourceId: movie.id, metadata: { title: movie.title } });
    await invalidatePublicMovieCaches();

    return jsonOk(movie, 201);
  } catch (err) {
    return apiError(err);
  }
}
