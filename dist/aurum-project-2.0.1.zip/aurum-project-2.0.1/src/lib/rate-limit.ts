import { env } from "./env";

export interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  resetMs: number;
}

/**
 * In-memory sliding-window limiter. Good enough for a single Node.js
 * instance (local dev, small deployments) but does NOT share state across
 * serverless instances — configure UPSTASH_REDIS_REST_URL/TOKEN in any
 * multi-instance deployment so limits are enforced globally, not per-lambda.
 */
const buckets = new Map<string, number[]>();

function inMemoryLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  const now = Date.now();
  const windowStart = now - windowMs;
  const hits = (buckets.get(key) ?? []).filter((t) => t > windowStart);
  hits.push(now);
  buckets.set(key, hits);

  // Bound memory: drop the oldest bucket occasionally instead of growing forever.
  if (buckets.size > 50_000) {
    const oldestKey = buckets.keys().next().value;
    if (oldestKey) buckets.delete(oldestKey);
  }

  return {
    success: hits.length <= limit,
    limit,
    remaining: Math.max(0, limit - hits.length),
    resetMs: windowStart + windowMs,
  };
}

let upstash:
  | {
      limit: (key: string, opts: { limit: number; windowMs: number }) => Promise<RateLimitResult>;
    }
  | null
  | undefined;

async function getUpstash() {
  if (upstash !== undefined) return upstash;
  const { UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN } = env();
  if (!UPSTASH_REDIS_REST_URL || !UPSTASH_REDIS_REST_TOKEN) {
    upstash = null;
    return upstash;
  }
  try {
    const [{ Ratelimit }, { Redis }] = await Promise.all([
      import("@upstash/ratelimit"),
      import("@upstash/redis"),
    ]);
    const redis = new Redis({ url: UPSTASH_REDIS_REST_URL, token: UPSTASH_REDIS_REST_TOKEN });
    const limiters = new Map<string, InstanceType<typeof Ratelimit>>();
    upstash = {
      limit: async (key: string, opts: { limit: number; windowMs: number }) => {
        const limiterKey = `${opts.limit}:${opts.windowMs}`;
        let limiter = limiters.get(limiterKey);
        if (!limiter) {
          limiter = new Ratelimit({
            redis,
            limiter: Ratelimit.slidingWindow(opts.limit, `${Math.ceil(opts.windowMs / 1000)} s`),
          });
          limiters.set(limiterKey, limiter);
        }
        const r = await limiter.limit(key);
        return { success: r.success, limit: r.limit, remaining: r.remaining, resetMs: r.reset };
      },
    };
  } catch {
    upstash = null; // optional dep not installed — silently fall back
  }
  return upstash;
}

/**
 * @param identifier stable per-caller key, e.g. `ip:route` or `userId:route`
 */
export async function rateLimit(
  identifier: string,
  { limit = 20, windowMs = 60_000 }: { limit?: number; windowMs?: number } = {},
): Promise<RateLimitResult> {
  const client = await getUpstash();
  if (client) {
    try {
      return await client.limit(identifier, { limit, windowMs });
    } catch (err) {
      // Configured but unreachable/unauthorized (bad token, network outage,
      // etc.) — a broken Redis credential must never take down every
      // rate-limited route (including login) for the whole app. Log once,
      // fall back in-memory for the rest of this process's life so we don't
      // keep round-tripping to a Redis that's already known to be failing; a
      // redeploy with a fixed token clears this via a fresh process.
      if (upstash !== null) {
        console.error("[rate-limit] Upstash request failed — falling back to in-memory limiter for this process:", err);
        upstash = null;
      }
      return inMemoryLimit(identifier, limit, windowMs);
    }
  }
  return inMemoryLimit(identifier, limit, windowMs);
}

export function clientIp(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]?.trim() ?? "unknown";
  return req.headers.get("x-real-ip") ?? "unknown";
}
