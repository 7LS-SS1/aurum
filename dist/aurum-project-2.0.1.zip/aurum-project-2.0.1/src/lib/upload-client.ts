import { apiFetch } from "@/lib/api-client";
import { resolveUploadContentType } from "@/lib/upload-queue";
import { Upload } from "tus-js-client";

/**
 * Presigns and uploads a file straight to Cloudflare R2 (images, XHR PUT) or
 * Bunny Stream (video, tus resumable) — the bytes never pass through our
 * server, only the presigned URL/credential does. Shared by admin forms that
 * accept a thumbnail or video file.
 */
export async function presignAndUpload(
  file: File,
  provider: "r2" | "bunny",
  onProgress: (pct: number) => void,
): Promise<string> {
  const contentType = resolveUploadContentType(file);
  const presign = await apiFetch<Record<string, unknown>>("/api/uploads/presign", {
    method: "POST",
    body: JSON.stringify({ provider, filename: file.name, contentType, size: file.size }),
  });

  if (presign.strategy === "put") {
    await new Promise<void>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open(presign.method as string, presign.uploadUrl as string);
      const headers = (presign.headers as Record<string, string>) ?? {};
      Object.entries(headers).forEach(([k, v]) => xhr.setRequestHeader(k, v));
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) onProgress((e.loaded / e.total) * 100);
      };
      xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`HTTP ${xhr.status}`)));
      xhr.onerror = () => reject(new Error("network error"));
      xhr.send(file);
    });
    return presign.publicUrl as string;
  }

  // strategy === 'tus' (Bunny Stream)
  const tus = presign.tus as Record<string, string>;
  return new Promise<string>((resolve, reject) => {
    const upload = new Upload(file, {
      endpoint: presign.uploadUrl as string,
      retryDelays: [0, 1000, 3000, 5000],
      headers: tus,
      metadata: { filetype: contentType, title: file.name },
      onProgress: (loaded, total) => onProgress((loaded / total) * 100),
      onSuccess: () => resolve(presign.publicUrl as string),
      onError: (err) => reject(err),
    });
    upload.start();
  });
}

/**
 * Comic/doujin cover image upload — the Doujin-specific counterpart to
 * presignAndUpload's "r2" branch, hitting /api/comic-uploads/presign (the
 * separate Doujin R2 bucket) instead of /api/uploads/presign (video).
 */
export async function presignAndUploadComicImage(file: File, onProgress: (pct: number) => void): Promise<{ url: string; objectKey: string }> {
  const contentType = resolveUploadContentType(file);
  const presign = await apiFetch<Record<string, unknown>>("/api/comic-uploads/presign", {
    method: "POST",
    body: JSON.stringify({ provider: "r2", filename: file.name, contentType, size: file.size }),
  });

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(presign.method as string, presign.uploadUrl as string);
    const headers = (presign.headers as Record<string, string>) ?? {};
    Object.entries(headers).forEach(([k, v]) => xhr.setRequestHeader(k, v));
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress((e.loaded / e.total) * 100);
    };
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`HTTP ${xhr.status}`)));
    xhr.onerror = () => reject(new Error("network error"));
    xhr.send(file);
  });

  return { url: presign.publicUrl as string, objectKey: presign.objectKey as string };
}

export async function presignAndUploadWordpressThemeAsset(
  file: File,
  kind: "package" | "screenshot",
  onProgress: (pct: number) => void,
): Promise<string> {
  const presign = await apiFetch<Record<string, unknown>>("/api/wp-themes/presign", {
    method: "POST",
    body: JSON.stringify({ kind, filename: file.name, contentType: file.type || "application/octet-stream", size: file.size }),
  });

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(presign.method as string, presign.uploadUrl as string);
    const headers = (presign.headers as Record<string, string>) ?? {};
    Object.entries(headers).forEach(([k, v]) => xhr.setRequestHeader(k, v));
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress((e.loaded / e.total) * 100);
    };
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`HTTP ${xhr.status}`)));
    xhr.onerror = () => reject(new Error("network error"));
    xhr.send(file);
  });

  return presign.publicUrl as string;
}
