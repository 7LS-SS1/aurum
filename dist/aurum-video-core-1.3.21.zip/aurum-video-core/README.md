# AURUM Video Core

## 1.3.21 — CSV แก้หมวดหมู่และแท็กสำหรับ SEO

- จับคู่โพสต์ด้วย `post_id` ภายในเว็บไซต์เดิม พร้อมตรวจ signed snapshot และการแก้ไขที่เกิดหลัง Export
- `categories` และ `tags` รองรับชื่อหรือ slug (รวมภาษาไทยและ percent-encoded slug) คั่นด้วย `|`; ใช้รายการเดิมเมื่อพบ และสร้างรายการใหม่เมื่อยืนยันบันทึกเท่านั้น
- ชื่อที่ซ้ำหลายรายการให้ระบุ slug; หมวดหมู่ใหม่เป็นระดับบนสุด ไม่เปลี่ยนชื่อหรือโครงสร้างหมวดหมู่เดิม นักแสดงยังต้องมีอยู่แล้ว
- ค่าในคอลัมน์แทนที่รายการที่ผูกกับโพสต์ทั้งหมด: เว้นว่างเพื่อล้าง หรือลบคอลัมน์เพื่อรักษาค่าเดิม
- Preview แสดงรายการใหม่และแยกข้อผิดพลาดจากแถวที่ไม่เปลี่ยน ตรวจสิทธิ์สร้าง taxonomy และย้อนกลับ term/ความสัมพันธ์เมื่อบันทึกแถวนั้นล้มเหลว
- หลังอัปเดตให้ตรวจไฟล์ใหม่เพื่อสร้าง Preview ใหม่ ใช้ CSV เดิมได้เมื่อ snapshot ยังตรงกับข้อมูลในเว็บ

## 1.3.17 — Import แล้วเปลี่ยนสถานะอัตโนมัติ

- ยกเลิกขั้นตอนตรวจคลิปและกดส่ง Pending ซ้ำหลัง Import; เปลี่ยนเมนูเป็น “สถานะคลิป”
- ตั้งค่าใน AURUM → นำเข้า / ส่งออก CSV → สถานะหลัง Import: Pending (ค่าเริ่มต้น) หรือเผยแพร่ Public (WordPress ใช้ค่า publish)
- หลังยืนยัน Import แถวที่เปลี่ยนข้อมูลจริงและบันทึกสำเร็จจะเข้าสถานะที่เลือก รวมคลิปเก่าหรือคลิปที่เผยแพร่แล้ว ไม่บังคับว่าต้องแก้เฉพาะชื่อ
- คง Preview ก่อนบันทึก CSV เพื่อแสดงข้อมูลที่จะเปลี่ยนและสถานะปลายทาง; จำสถานะไว้กับชุด Preview ไม่เปลี่ยนกลางชุดตามการตั้งค่าภายหลัง
- แถวที่ไม่เปลี่ยน ถูกปฏิเสธ หรือบันทึกผิดพลาดไม่เปลี่ยนสถานะ ตรวจสิทธิ์เผยแพร่เมื่อเลือก Public และบันทึกข้อมูลกับสถานะใน transaction รายแถว
- คลิปใหม่จาก AURUM ยังเข้า Draft; Draft ที่ค้างในคิวตรวจเดิมไม่ถูกเผยแพร่ย้อนหลัง สามารถ Export มาแก้และ Import ใหม่หรือจัดการผ่าน WordPress
- ไม่มี schema migration/backfill ไม่เปลี่ยน IDs, metadata เครื่องเล่น, URLs หรือ API/embed; ประวัติเดิมยังอยู่
- ก่อนอัปเดตสำรองฐานข้อมูลและ ZIP เดิม ทดสอบ canary ด้วยคลิป Draft หนึ่งรายการทั้ง Pending/Public; งาน Preview เดิมที่ไม่มีสถานะปลายทางใช้ Pending แนะนำจบชุดที่กำลังทำก่อนอัปเดต ไม่ต้อง drain worker เพราะไม่มีการเปลี่ยน worker
- Rollback ด้วย ZIP 1.3.16 คืนกระบวนการเดิม แต่ไม่ย้อนสถานะคลิปที่ Import ไปแล้ว ให้คืนสถานะรายการที่ต้องการผ่าน WordPress; ใช้ฐานข้อมูลสำรองเฉพาะเมื่อจำเป็นต้องกู้ข้อมูลจริง

## 1.3.16 — หน้าควบคุมใหม่และเมนูที่เป็นระเบียบ

- จัดเมนูผู้ดูแลเป็น 6 กลุ่ม: ภาพรวม / วิดีโอ / คิวตรวจคลิป / CSV / นักแสดงและหมวดหมู่ / ตั้งค่า
- รวมทางเข้ารายการวิดีโอไว้ใต้ AURUM โดยใช้หน้าจัดการ WordPress เดิม รวมค้นหา เพิ่ม แก้ไข และ Bulk Actions
- หน้าแรกแสดงจำนวนคลิปตามขั้นตอน Draft → CSV → ตรวจ → Pending พร้อมลิงก์ไปยังงานแต่ละขั้น
- รวมโปรไฟล์เว็บไซต์ Google / Head และประวัติในหน้าตั้งค่า แยกเครื่องมือย้ายข้อมูลไว้ในส่วนพับได้; ลิงก์หน้าตั้งค่าเดิมยังใช้ได้
- ปรับสี ระยะห่าง การ์ด ปุ่ม ตาราง และแบบฟอร์มให้สม่ำเสมอ พร้อมเลย์เอาต์จอแคบ
- ไม่มี schema migration หรือ backfill ไม่แก้ IDs, metadata, API, embed หรือขั้นตอนตรวจคลิป สิทธิ์ผู้ใช้อื่นยังคงเดิม
- ก่อน Production เก็บ ZIP เดิมและสำรองฐานข้อมูล แล้วทดสอบ canary การเปิดเมนูและ CSV/คิวตรวจ; ไม่ต้อง drain worker เพราะไม่มีการเปลี่ยนคิวหรือสัญญา API
- Rollback ด้วย ZIP 1.3.15 เพื่อคืนหน้าควบคุมเดิม โดยไม่ต้องย้อนฐานข้อมูล

## 1.3.15 — คิวตรวจคลิป Draft → CSV → ตรวจอีกครั้ง → Pending

- คลิปใหม่ที่สร้างผ่าน REST พร้อม aurum_movie_id เข้า Draft ก่อนบันทึก แม้ผู้ส่งระบุ Publish; คลิปเดิมและโพสต์ที่ไม่มี AURUM identity ไม่ถูกย้ายสถานะย้อนหลัง
- เพิ่มเมนู AURUM → คิวตรวจคลิป: คลิปใหม่รอแก้ชื่อ / Import แล้วรอตรวจ / ส่ง Pending แล้ว
- เพิ่มตัวกรอง Export “คลิปใหม่รอแก้ชื่อผ่าน CSV (Draft)” และ “Import แก้ชื่อแล้วรอตรวจ (Draft)” ใช้ร่วมกับชุด Export ที่ล็อกรายชื่อ
- Import ที่เปลี่ยนชื่อจริงจากต้นฉบับจะเข้าคิวรอตรวจ แต่ยังเป็น Draft; แถวที่ไม่เปลี่ยนหรือแก้เฉพาะเนื้อหาไม่ผ่านขั้นแก้ชื่อ
- ผู้ดูแลเปิดดูคลิป/เนื้อหา แล้วติ๊กยืนยันและกดส่ง Pending แยกจาก Import; ตรวจสิทธิ์ nonce และ fingerprint ก่อนเปลี่ยนสถานะภายใน transaction
- หากแก้ชื่ออีกหลัง Import จะกลับไปรอ Import ชื่อใหม่; หากข้อมูลเปลี่ยนหลังเปิดหน้าตรวจต้องโหลดหน้าใหม่ก่อนส่ง ไม่ใช่การเผยแพร่อัตโนมัติ
- การ Push ซ้ำผ่าน REST ไม่เลื่อนคลิป Draft ข้ามการตรวจ และ Push ที่ระบุ AURUM ไม่เผยแพร่คลิป Pending โดยอัตโนมัติ
- ไม่มี schema migration ไม่มี backfill คลิปเก่า ไม่แก้ Video IDs, URLs, embeds หรือสัญญา payload ฝั่งส่ง ใช้ปลั๊กอินรับสถานะ Draft ได้โดยไม่ต้อง deploy AURUM ใหม่; แนะนำตั้ง defaultStatus=Draft ของเว็บไซต์ปลายทางใน AURUM ให้สอดคล้องด้วย
- ก่อน Production สำรองฐานข้อมูล/ZIP ทดสอบ canary 1 เว็บ: Push → Export → Import → ตรวจ → Pending รวมถึงคลิปเดิม คิวเดิมไม่ต้อง drain สำหรับการเปลี่ยนปลั๊กอินนี้
- Rollback ด้วย ZIP เดิมรักษา private meta ไว้ แต่การบังคับรับเป็น Draft จะหยุด จึงต้องตั้งผู้ส่งเป็น Draft ก่อน rollback หากยังต้องการขั้นตรวจ ไม่ต้อง restore ฐานข้อมูลทั้งเว็บเพื่อย้อน UI

## 1.3.14 — แก้ลากวางไฟล์ CSV

- แก้ drop handler ให้ส่ง FileList ไปยังช่องอัปโหลดจริงและป้องกันเบราว์เซอร์เปิดไฟล์แทน
- แสดงชื่อและขนาดไฟล์หลังเลือก ทั้งลากวางและคลิกเลือก พร้อมตรวจ .csv ครั้งละ 1 ไฟล์ / สูงสุด 64 MiB
- เมื่อเลือกไฟล์ไม่ถูกต้อง ล้างไฟล์เดิมเพื่อไม่ให้ส่งไฟล์ผิดโดยไม่รู้ตัว และแจ้งข้อผิดพลาดในหน้า
- ไม่เปลี่ยนข้อมูลวิดีโอ/CSV schema/Preview/API/embed ไม่ต้องย้ายฐานข้อมูลหรือหยุดคิว; อัปเดต ZIP แล้วโหลดหน้าใหม่เพื่อรับ JavaScript รุ่นใหม่ ย้อนกลับด้วย ZIP เดิมได้

## 1.3.13 — CSV สูงสุด 64 MB

- เพิ่มเพดาน Import/Export เป็น 64 MiB (67,108,864 bytes) โดยยังจำกัด 500 แถวต่อไฟล์
- Export ยังใช้ temporary stream ที่ย้ายไปดิสก์เมื่อเกิน 2 MiB; ค่า buffer นี้ไม่ใช่เพดานไฟล์
- Preview ขนาดใหญ่แบ่งเป็น transient ส่วนย่อยพร้อม checksum เพื่อไม่ให้บันทึกเป็นก้อนเดียวเกิน max_allowed_packet ของฐานข้อมูล และยังอ่าน Preview รุ่นเดิมได้
- ขอ memory allowance 512M เฉพาะคำขอจัดการ CSV เมื่อโฮสต์อนุญาต ไม่แก้ php.ini หรือค่าบน Production
- เซิร์ฟเวอร์ต้องมี upload_max_filesize >= 64M, post_max_size >= 80M และเพดาน request body ของเว็บเซิร์ฟเวอร์ >= 80 MB; ควรมี PHP memory_limit อย่างน้อย 512M สำหรับ Preview ขนาดใหญ่
- สำรองฐานข้อมูลและ ZIP เดิมก่อนติดตั้ง ทดลองไฟล์จริงบน staging/canary ไม่มี schema migration ไม่เปลี่ยน IDs/metadata/API/embed หรือคิวงาน; rollback เป็น ZIP เดิมได้ แต่ต้องสร้าง Preview ใหม่เพราะรุ่นเก่าไม่รู้จัก chunked storage และมีเพดาน 2 MB

## 1.3.12 — จำนวนวิดีโอ จำนวนหน้า และชุด Export ที่ล็อกรายชื่อ

- กด “นับวิดีโอและสร้างชุด Export” เพื่อแสดงจำนวนตามตัวกรอง จำนวนหน้า และช่วงรายการ พร้อมปุ่มก่อนหน้า/ถัดไป
- แสดงหน้าที่ส่งไฟล์ให้เบราว์เซอร์แล้วในหน้าจอปัจจุบัน ไม่ใช่การยืนยันว่าไฟล์ถูกบันทึกลงดิสก์; รีโหลดหน้าจะเริ่มชุดใหม่
- ล็อกรายชื่อผู้สมัครในคำขอแรกและประเมินตัวกรองเนื้อหาทีละ 200 รายการ รายชื่อที่ผ่านตัวกรองคงเดิมหลังเตรียมเสร็จ แม้มี Push หรือเปลี่ยนเนื้อหาระหว่างดาวน์โหลด
- ล็อกเฉพาะ IDs ไม่ใช่เนื้อหา CSV; เนื้อหาและ signed snapshot ใช้ค่าล่าสุดตอนดาวน์โหลด หากรายการถูกลบหรือไม่มีสิทธิ์ ระบบหยุดทั้งหน้าและแจ้งข้อผิดพลาด
- ชุดผูกกับผู้ใช้และหมดอายุใน 2 ชั่วโมง เปลี่ยนตัวกรอง/จำนวนต่อหน้าต้องสร้างใหม่ ค่ารวมไม่อัปเดตสดหลังล็อก
- รองรับผู้สมัครไม่เกิน 100,000 รายการต่อชุด เกินแล้วแจ้งให้แบ่งตามหมวด/สถานะ ไม่ตัดรายการเงียบ ๆ; ยังคงจำกัด CSV 500 แถว/2 MB หากเกินขนาดให้ลดจำนวนต่อหน้าและเริ่มชุดใหม่
- ใช้ JavaScript ในหน้าจอ Export และ nonce/สิทธิ์ manage_options ใน endpoint; download ต้องใช้ token ของชุดที่พร้อมและตัวกรองตรงกัน
- ไม่ย้าย schema ไม่แก้ข้อมูลวิดีโอหรือ API/embed เพิ่มเฉพาะ transient อายุจำกัด สำรองฐานข้อมูล/ZIP เดิมและทดลอง canary ก่อน Production; rollback กลับ ZIP 1.3.11 แล้วสร้าง Export ใหม่ ไม่ต้องหยุด worker หรือย้ายคิวสำหรับการเปลี่ยน UI นี้

## 1.3.11 — ประวัติชื่อและเนื้อหาตั้งแต่รับวิดีโอ

- เพิ่มตัวกรอง Export: ยังไม่เคยแก้ / เคยแก้แล้ว / ไม่ทราบประวัติเดิม
- เก็บต้นฉบับชื่อและ post_content หลังสร้างวิดีโอผ่าน REST ที่มี aurum_movie_id ไม่เขียนทับเมื่อ Push ซ้ำ
- บันทึกการเปลี่ยนจริงผ่าน WordPress hooks รวม CSV และ REST; เปลี่ยนกลับเป็นต้นฉบับยังนับว่าเคยแก้
- CSV เพิ่มคอลัมน์อ่านอย่างเดียว: content_history (untouched/changed/unknown), baseline_available, differs_from_original, title_ever_changed, content_ever_changed, first_content_change_at, last_content_change_at, last_content_change_source; เวลารูปแบบ UTC ISO 8601
- วิดีโอเก่าไม่สร้างต้นฉบับย้อนหลัง หากพบการแก้หลังติดตั้งแสดง changed แต่ baseline_available=no
- ติดตามเฉพาะชื่อและเนื้อหาหลัก ไม่รวม excerpt หรือ SEO meta ที่แก้แยกต่างหาก; Import CSV meta_description เดิมเขียน post_content ด้วยจึงถูกติดตาม
- แหล่งการแก้: aurum_push (header จากผู้ส่ง), rest_api, csv, wordpress_admin หรือ wordpress แหล่งจาก header เป็นข้อมูลประกอบ ไม่ใช่หลักฐานยืนยันตัวตนเพิ่มเติมจาก WordPress authentication
- ไม่ครอบคลุม SQL ตรงหรือช่วงปิดปลั๊กอิน; ต้องเปิดใช้งานต่อเนื่อง ข้อมูลต้นฉบับ/ประวัติเป็น private post meta ไม่เปิดให้ REST เขียน
- ก่อน Production: สำรองฐานข้อมูลและ ZIP รุ่นเดิม ทดลอง Push/แก้/Export บน staging ก่อน canary หนึ่งเว็บ ไม่มี schema migration หรือการแก้คิว; rollback ใช้ ZIP เดิมได้ แต่ช่วง rollback จะไม่ติดตามและ CSV ใหม่ต้อง Export ใหม่หากใช้รุ่นเก่า

## 1.3.10 — Google Search Console และ Google Analytics

- เพิ่มเมนู **AURUM → Google / โค้ด Head** พร้อมช่อง HTML สำหรับแท็กยืนยัน Search Console และ Google Analytics / JavaScript
- เปิด–ปิดการแทรกโค้ดใน `wp_head` ของหน้าเว็บไซต์ได้ โดยเริ่มต้นปิดใช้งาน
- จำกัดการบันทึกด้วยสิทธิ์ `manage_options`, `unfiltered_html` และตรวจ nonce
- ไม่มีการย้ายฐานข้อมูลหรือแก้ข้อมูลวิดีโอเดิม ปิดสวิตช์เพื่อนำโค้ดออกและล้างแคชเว็บไซต์หลังเปลี่ยนค่า
- ติดตั้งแท็กเท่านั้น ไม่ดึงรายงานหรือยืนยันเว็บไซต์กับ Google อัตโนมัติ

## 1.3.9 — ย้ายโพสต์วิดีโอเดิมเป็น CPT video

- เพิ่มโหมด Preview และย้าย `post` วิดีโอเดิมเป็น `video` จริง พร้อมกำหนด
  `video_category` ปลายทาง โดยรักษา ID, slug, เนื้อหา, รูป, meta และความคิดเห็น
- บันทึก URL เดิมของแต่ละวิดีโอและตอบกลับแบบ 301 ไปยัง URL `/videos/{slug}/`
  หลังย้าย รวมถึง redirect archive `category` เดิมไปยัง `video_category` ที่จับคู่ไว้
- เปิด pretty permalink ของหมวดวิดีโอเป็น `/video-category/{slug}/` และล้าง rewrite
  rules หนึ่งครั้งเมื่ออัปเดตปลั๊กอิน
- โหมดเพิ่มหมวดโดยไม่เปลี่ยน post type จากรุ่น 1.3.8 ยังคงใช้งานได้สำหรับเว็บที่ต้องการรักษา URL เดิม

## 1.3.8 — ย้ายหมวดวิดีโอเก่าโดยไม่เปลี่ยน URL

- เพิ่มหน้า **AURUM → ย้ายหมวดวิดีโอเก่า** สำหรับเชื่อม `category` เดิมไปยัง
  `video_category` โดย Preview รายการก่อนเขียนข้อมูลจริง
- เลือกเฉพาะโพสต์ที่มีรหัสตัวตนหรือลิงก์เล่นวิดีโอ และไม่รวมรายการที่ระบุ
  `_av123_content_kind=article` เพื่อป้องกันบทความทั่วไปปะปน
- เพิ่ม `video_category` แบบ append เป็นชุดละ 25 รายการ ไม่เปลี่ยน post type, ID,
  slug, URL หรือ category เดิม และเรียกซ้ำได้โดยไม่สร้างความสัมพันธ์ซ้ำ
- เมื่อมี mapping ระบบจะผูก `video_category` กับ `post` ด้วย ทำให้ Homepage Control
  แหล่งเดียวกันแสดงได้ทั้งวิดีโอ CPT ใหม่และโพสต์วิดีโอเดิม

## 1.3.7 — CSV workflow แบบ Minimal

- ปรับหน้า “นำเข้า / ส่งออก CSV” เป็น flow สามขั้นตอนที่มองเห็นได้ชัดเจน:
  ดาวน์โหลด แก้ไขไฟล์ และตรวจสอบก่อนบันทึก
- ลดฟอร์มที่แน่นเกินไป แสดงหมวดหมู่เมื่อเลือกส่งออกตามหมวดหมู่เท่านั้น
  และใช้ตัวเลือกสถานะแบบ chip ที่อ่านง่ายทั้ง desktop และ mobile
- เพิ่มพื้นที่เลือก/ลากไฟล์ สรุปจำนวนรายการใน Preview และซ่อนคำอธิบายทางเทคนิค
  ไว้ในส่วนช่วยเหลือ โดยไม่เปลี่ยน CSV schema หรือระบบป้องกัน conflict

## 1.3.6 — ตั้งค่าจุดเดียวและซิงก์อัตโนมัติ

- โปรไฟล์เว็บไซต์เลือก taxonomy ที่เข้ากันได้กับ post type จริงโดยอัตโนมัติ
  และไม่ใช้ค่าที่เคยบันทึกไว้หาก taxonomy นั้นไม่ได้ผูกกับ post type ปัจจุบัน
- AURUM Project อ่านโปรไฟล์ที่เว็บไซต์ใช้งานจาก Diagnostics แล้วปรับปลายทาง
  ให้ตรงกันเมื่อกดตรวจสอบ ผู้ใช้ไม่ต้องกรอก REST base หรือ taxonomy ซ้ำ
- หน้าตั้งค่าแสดงตัวเลือกหลักแบบเรียบง่าย ส่วนการเลือก taxonomy เองอยู่ใน
  “การตั้งค่าขั้นสูง” สำหรับเว็บไซต์ที่มีโครงสร้างเฉพาะเท่านั้น

## 1.3.4 — แยกวิดีโอและรวมเมนูนักแสดง

- ย้ายหน้าจัดการ `AURUM Actors` มาอยู่ใต้เมนู AURUM พร้อมใช้ชื่อเมนูภาษาไทย
- เมื่อเลือกโปรไฟล์ `video` รายการวิดีโอ WordPress จะอยู่ใต้เมนู AURUM และแยกจากบทความ `post`
- ไม่ย้ายหรือเปลี่ยน URL ของโพสต์เดิมอัตโนมัติ เว็บที่ใช้งานจริงจึงเปิดใช้กับวิดีโอใหม่ก่อนแล้วค่อยวางแผนย้ายข้อมูลเก่าได้

## 1.3.3 — ตัวกรองส่งออกเพื่อแก้เนื้อหาบาง

- เลือกส่งออกวิดีโอทั้งหมด ตามหมวดหมู่ วิดีโอใหม่ล่าสุด หรือวิดีโอที่เนื้อหาต่ำกว่าเกณฑ์
- กรองสถานะเผยแพร่ ฉบับร่าง และรอตรวจพร้อมกันได้
- กำหนดจำนวนส่งออกได้ตั้งแต่ 1–500 รายการ และใช้เลขหน้าเพื่อแบ่งชุดงาน
- กลุ่มเนื้อหาต่ำกว่าเกณฑ์ตรวจชื่อ แหล่งเล่น รูปปก คำอธิบายไม่เกิน 128 ตัวอักษร และคำอธิบายที่เกือบเหมือนชื่อเรื่อง

## 1.3.0 — การจัดการเว็บไซต์ AURUM

เมนู **AURUM** ใน WordPress มีภาพรวม วิดีโอ โปรไฟล์เว็บไซต์ ประวัติรับข้อมูล
และนำเข้า/ส่งออก CSV ใช้สิทธิ์ผู้ดูแลเว็บไซต์ ส่วน Project AURUM ยังคงเป็นเจ้าของ
คิวส่งงาน การตรวจตัวตน และสถานะเผยแพร่ส่วนกลาง

- เว็บไซต์เดิมใช้โปรไฟล์ `auto` โดยไม่ย้ายโพสต์หรือเปลี่ยน URL
  เลือกโปรไฟล์ `video` สำหรับเว็บที่ต้องการชนิดโพสต์วิดีโอ Core จะลงทะเบียน
  เฉพาะชนิดโพสต์และ taxonomy ที่ยังไม่มีเจ้าของ
- ตั้งค่า Project ตาม REST base ที่แสดงบนหน้าภาพรวม Diagnostics รุ่นนี้
  แสดงโปรไฟล์จริงของทั้ง `post` และ `video` พร้อมหมวดหมู่และแท็ก
- ประวัติในเว็บเก็บ 200 เหตุการณ์ล่าสุด โดยเก็บชื่อฟิลด์และรหัสรายการ
  ไม่เก็บ URL เครื่องเล่น รหัสผ่าน หรือ token ประวัตินี้เป็นบันทึกช่วยตรวจสอบ
  และไม่ใช้แทนประวัติงานส่วนกลาง
- CSV ใช้ schema 1 ของ AURUM เท่านั้น ไม่ใช่ไฟล์ CSV ของ 7M Videos Core
  รองรับ UTF-8, 500 แถว / 2 MB และมี snapshot ลงลายเซ็นเฉพาะเว็บ
  ส่งออกทีละหน้าโดยใช้จำนวนรายการต่อหน้าเท่าเดิม
- แก้ชื่อ ข้อความย่อ `meta_description` คีย์เวิร์ด และชื่อหรือ slug ของหมวดหมู่/แท็ก
  (สร้างใหม่เมื่อยืนยันได้) นักแสดงต้องมีอยู่แล้ว คั่นหลายค่าด้วย `|` โดยไม่แก้ตัวตนหรือ URL เครื่องเล่น
- `meta_description` ที่แก้จะบันทึกทั้งเนื้อหาวิดีโอและ Rank Math description
  แถวที่ไม่แก้จะถูกข้ามและรักษาเนื้อหา HTML เดิม คอลัมน์ที่ไม่มีรักษาค่าเดิม
  ช่องว่างที่แทนค่าเดิมจะล้างค่า
- ตรวจ Preview ก่อนบันทึก ตัวอย่างใช้ได้ 15 นาทีและเฉพาะผู้ที่อัปโหลด
  ระบบตรวจความขัดแย้งอีกครั้งก่อนบันทึกเป็นชุดละ 25 รายการ
  ถ้าข้อมูลเปลี่ยนหลัง Export ต้อง Export ใหม่ ไม่มีการเขียนทับโดยอัตโนมัติ
- การนำเข้าแต่ละแถวใช้ InnoDB transaction และย้อนคืนเมื่อบันทึกไม่สำเร็จ
  รายการที่บันทึกสำเร็จก่อนหน้าในไฟล์เดียวกันยังคงอยู่ จึงควรตรวจผลรายแถว
  หากคำขอบันทึกหยุดกลางทาง ให้ตรวจผลและ Export ใหม่ก่อนลองอีกครั้ง

ทดสอบฐานข้อมูลท้องถิ่นด้วย temporary drafts/terms และคืนค่า history หลังจบ:

```bash
php tests/management-integration.php auto
php tests/management-integration.php video
```

Build ของ Project รวมเฉพาะไฟล์ติดตั้ง bootstrap, includes, assets และ README
ไม่รวม tests หรือเอกสารพัฒนา

## 1.2.4 - AURUM theme compatibility

Supported consumer themes: 123AV, misiav, rakhee, tiktik, missav, aurum-video,
aurum-video-thai and aurum-video-avjb. Keep this plugin active for metadata,
actor synchronization, native playback and self-hosted HLS.

- REST metadata now enables custom-fields support on each supported post type.
- The AURUM actor taxonomy attaches after public REST post types register,
  including the video CPT.
- Theme ownership also prevents a duplicate player for marked legacy sources.
- WebM/Ogg sources use their own MIME types; iframe pages do not load HLS assets.
- Theme integration tests create temporary drafts for both post/video REST
  profiles, render real watch templates, verify metadata/actors/playback and
  remove all fixtures in finally. Run one PHP process per theme:

    WP_LOAD_PATH=/var/www/html/wp-load.php php tests/theme-integration.php 123av

Theme-independent integration for AURUM-distributed WordPress videos.

## Install

1. Run `npm run wordpress:build-plugin` in the AURUM repository.
2. Upload `dist/aurum-video-core.zip` in **Plugins → Add New → Upload Plugin** and activate it. Do not change the active theme.
3. Open `/wp-json/aurum-video-core/v1/diagnostics` while authenticated with an editor account. `ready` must be `true` and the active REST post type must have no missing fields.
4. Save permalinks once, or deactivate/reactivate the plugin, to register the video-sitemap routes.

The optional real REST integration test creates and then removes one local draft:

```bash
WP_LOAD_PATH=/var/www/html/wp-load.php php tests/rest-integration.php
```

For an MU-plugin deployment, copy the `aurum-video-core` directory into `wp-content/mu-plugins/` and add a root loader such as `wp-content/mu-plugins/aurum-video-core-loader.php` containing:

```php
<?php require_once WPMU_PLUGIN_DIR . '/aurum-video-core/aurum-video-core.php';
```

## Repair existing posts

Dry run is the default and performs no writes:

```bash
npm run wordpress:repair-video-meta -- --site-id TARGET_SITE_ID --post-id 48
```

Review the JSON plan, then apply it to the same post:

```bash
npm run wordpress:repair-video-meta -- --site-id TARGET_SITE_ID --post-id 48 --apply
```

The command only calls the existing post's meta update endpoint. It never calls the post-creation endpoint and never changes title, slug, or content. Re-running after a successful repair reports `noop`. Every applied repair writes an `AuditLog` entry with the post, movie, match strategy, and changed fields.

## Rendering and SEO ownership

- Direct/HLS videos are emitted as standard `<video><source>` markup in the first response. HLS.js is self-hosted and attaches only on explicit play intent in non-native browsers.
- Iframe providers receive a titled 16:9 iframe with explicit permissions.
- The legacy `<!-- aurum-video -->` link is stripped from displayed content. If meta is still missing, its safe HTTP(S) URL is used temporarily and `_aurum_video_core_needs_backfill` is stamped for diagnostics.
- The active `misiav` theme and the repository's `aurum-video` theme are detected so an existing theme player is not duplicated.
- Yoast private metadata is not registered. Public Yoast description/image filters are used only when Yoast has no value. Basic Yoast and AURUM can coexist; Yoast Video SEO remains the VideoObject owner when installed.
- `/aurum-video-sitemap.xml` is a sitemap index. Page files are `/aurum-video-sitemap-1.xml`, etc. The index is advertised in virtual `robots.txt`.
- Adult rating and `<video:family_friendly>no</video:family_friendly>` are opt-in through `aurum_explicit=1` or the `aurum_video_core_is_explicit` filter. Nothing is inferred merely from the site category.

## CDN and Search Console checklist

1. Keep Bunny token/hotlink protection for ordinary third-party traffic, but add a crawler-safe rule that permits verified Googlebot. Verification must use forward-confirmed reverse DNS or an equivalent trusted edge signal; never trust `User-Agent` alone.
2. Permit `GET`, `HEAD`, and byte/range requests to the poster, master/media M3U8 files, encryption keys if used, and media segments. Return the correct media MIME types and CORS headers for `https://javhub24.com`.
3. Keep media URLs stable. Do not generate a new expiring URL on each watch-page request.
4. Confirm an ordinary off-site hotlink still receives the intended denial, while a verified Googlebot request receives the manifest and at least one segment successfully.
5. Submit `/aurum-video-sitemap.xml` in Google Search Console. Run URL Inspection on repaired watch pages and review the Video indexing report after recrawl.
6. Validate the live response in Rich Results Test and Schema Markup Validator. Explicit pages may be ineligible for some search features even when technically valid.

## Rollback

1. Deactivate/remove `aurum-video-core`; this restores the prior theme behavior and removes its sitemap route after rewrite rules are flushed.
2. Revert the AURUM application commit if post-write verification must be rolled back. Existing WordPress posts are not deleted.
3. Repaired meta is safe to leave in place. If removal is required, restore only the fields recorded in the repair audit log; do not delete or recreate posts.

## Ownership filters (1.2.0)

Exactly one component per page may own the player, the VideoObject, the video
sitemap and the explicit-content signal. AURUM assumes ownership by default and
stands down when another component answers one of these filters:

| Filter | Default | Ownership signal |
| --- | --- | --- |
| `aurum_video_core_theme_renders_player` | `false` | return true when the theme prints the primary player, so AURUM does not prepend one |
| `aurum_video_core_emit_schema` | `true` | another component emits the VideoObject |
| `aurum_video_core_enable_sitemap` | `true` | another component serves the video sitemap; AURUM stops rendering `/aurum-video-sitemap*.xml` and stops advertising it in robots.txt |
| `aurum_video_core_enable_rating_meta` | `true` | another component prints the `rating` meta tag |

`aurum_video_core_enable_sitemap` intentionally leaves the rewrite rules
registered, so switching ownership back does not need a rewrite flush. While it
is disabled those URLs return 410 Gone.

When a theme claims the player through `aurum_video_core_theme_renders_player`,
AURUM also stops enqueueing its player stylesheet and HLS script, since it prints
no player markup on that page. Themes that render a legacy source also own that
player. Integrated themes explicitly enqueue the plugin player assets when they
use its server-rendered player helper.

While `aurum_video_core_enable_sitemap` is false the sitemap routes stay
registered and answer **410 Gone**, not 404 and never a redirect. Returning
quietly would let WordPress resolve the still-matching route as a home query and
`redirect_canonical()` would 301 the URL to the front page - a soft 404 that
search engines keep following. 410 tells them to drop the address instead.


## 1.2.2 - Editable WordPress imports

Playback persistence is integrated into this same plugin. Marked legacy AURUM sources are saved to metadata before editorial replacement and before Gutenberg preloads metadata. Existing playback metadata remains authoritative. Title, slug, content, excerpt and Rank Math fields remain editable. Already missing sources require verified recovery from AURUM; no source is guessed. Regression coverage: tests/editor-integration.php (temporary local drafts only).


## 1.2.3 - Actor permalink consolidation

The `aurum_actor` CPT is registered with `rewrite => false`, so its only reachable
address is the internal query URL `?aurum_actor=<slug>`. That address is publicly
queryable and therefore indexable, competing with the real actor profile page.

1.2.3 stops exposing it:

- `post_type_link` returns the paired `aurum_video_actor` term URL, so
  `get_permalink()` on an actor record no longer prints the query URL.
- `template_redirect` answers `is_singular('aurum_actor')` with a 301 to that same
  term URL, so addresses already indexed are consolidated instead of left as
  duplicates.

The pairing is `_aurum_actor_id` on the post matched against `_aurum_actor_id` on
the term. An actor with no matching term keeps its original URL and is not
redirected. An ambiguous match (more than one term carrying the same external ID)
resolves to no URL, so nothing is redirected on a guess.

Two limits to be aware of before deploying this:

1. The redirect target is whatever `get_term_link()` returns for
   `aurum_video_actor`. That taxonomy is also `rewrite => false`, so on a bare site
   the destination is `?aurum_video_actor=<slug>`. The 123AV theme filters
   `term_link` to `/actres/{slug}/`, and that is what a site running that theme
   will serve. The quality of the destination therefore depends on the active
   theme, which is unusual for this plugin.
2. Unlike the player, the VideoObject, the video sitemap and the rating signal,
   this behaviour has **no ownership filter**. If another component should own
   actor URL consolidation, a filter has to be added first; there is currently no
   way for AURUM to stand down from it.

This is a URL change. Count the affected `aurum_actor` records and check what is
already indexed before deploying, the same way any other permalink change is
treated.
