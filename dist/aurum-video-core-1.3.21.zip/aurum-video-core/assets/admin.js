(function () {
	'use strict';
	var exportType = document.getElementById('aurum-export-type');
	var categoryField = document.getElementById('aurum-category-field');
	if (exportType && categoryField) {
		var syncCategory = function () { categoryField.hidden = exportType.value !== 'category'; };
		exportType.addEventListener('change', syncCategory); syncCategory();
	}
	var fileInput = document.getElementById('aurum-csv-file');
	var drop = fileInput && fileInput.closest('.aurum-csv-drop');
	var fileName = document.getElementById('aurum-csv-file-name');
	if (fileInput && drop && fileName) {
		var feedback = document.createElement('p');
		feedback.className = 'description'; feedback.setAttribute('role', 'status'); feedback.setAttribute('aria-live', 'polite');
		feedback.id = 'aurum-csv-file-status'; drop.insertAdjacentElement('afterend', feedback);
		fileInput.setAttribute('aria-describedby', feedback.id);
		var rejectFile = function (message) {
			fileInput.value = ''; fileName.textContent = 'เลือกไฟล์ CSV';
			feedback.textContent = message; fileInput.setCustomValidity(message);
		};
		var showFile = function () {
			fileInput.setCustomValidity(''); feedback.textContent = '';
			var files = fileInput.files;
			if (!files || !files.length) { fileName.textContent = 'เลือกไฟล์ CSV'; return; }
			if (files.length !== 1) { rejectFile('กรุณาเลือกไฟล์ CSV ครั้งละ 1 ไฟล์'); return; }
			if (!/\.csv$/i.test(files[0].name)) { rejectFile('รองรับเฉพาะไฟล์ .csv กรุณาเลือกไฟล์ใหม่'); return; }
			if (files[0].size > 64 * 1024 * 1024) { rejectFile('ไฟล์ต้องมีขนาดไม่เกิน 64 MB'); return; }
			fileName.textContent = files[0].name;
			feedback.textContent = 'เลือกไฟล์แล้ว · ' + (files[0].size / (1024 * 1024)).toFixed(2) + ' MB · กดตรวจสอบไฟล์เพื่อดูตัวอย่างก่อนบันทึก';
		};
		fileInput.addEventListener('change', showFile);
		['dragenter', 'dragover'].forEach(function (name) { drop.addEventListener(name, function (event) {
			event.preventDefault(); drop.classList.add('is-dragging');
			if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
		}); });
		drop.addEventListener('dragleave', function (event) {
			if (!event.relatedTarget || !drop.contains(event.relatedTarget)) drop.classList.remove('is-dragging');
		});
		drop.addEventListener('drop', function (event) {
			event.preventDefault(); event.stopPropagation(); drop.classList.remove('is-dragging');
			var files = event.dataTransfer && event.dataTransfer.files;
			if (!files || !files.length) { rejectFile('ไม่พบไฟล์ กรุณาลากไฟล์ CSV หรือคลิกเลือกไฟล์'); return; }
			if (files.length !== 1) { rejectFile('กรุณาวางไฟล์ CSV ครั้งละ 1 ไฟล์'); return; }
			try {
				fileInput.files = files;
				fileInput.dispatchEvent(new Event('change', { bubbles: true }));
			} catch (error) { rejectFile('เบราว์เซอร์ไม่รองรับการวางไฟล์ กรุณาคลิกเลือกไฟล์ CSV'); }
		});
	}
	var form = document.getElementById('aurum-csv-apply');
	if (form) form.addEventListener('submit', async function (event) {
		event.preventDefault();
		var button = form.querySelector('[type=submit]');
		var status = document.getElementById('aurum-csv-progress');
		button.disabled = true;
		try {
			var finished = false;
			while (!finished) {
				var data = new FormData(form); data.set('ajax', '1');
				// A hidden input named action shadows HTMLFormElement.action.
				var response = await fetch(form.getAttribute('action'), { method: 'POST', body: data, credentials: 'same-origin' });
				if (!(response.headers.get('content-type') || '').includes('application/json')) throw new Error('ไม่ได้รับผลการบันทึก กรุณาตรวจผลและเข้าสู่ระบบใหม่ก่อนลองอีกครั้ง');
				var result = await response.json();
				if (!response.ok || !result.success) throw new Error(result.data && result.data.message || 'บันทึกไม่สำเร็จ กรุณาตรวจผลก่อนลองใหม่');
				finished = result.data.finished;
				var counts = result.data.counts;
				status.textContent = result.data.processed + ' / ' + result.data.total + ' รายการ · บันทึก ' + counts.updated + ' · ข้าม ' + counts.skipped + ' · ไม่ผ่าน ' + (counts.invalid + counts.error);
			}
			button.textContent = 'ดำเนินการครบแล้ว'; button.value = 'ดำเนินการครบแล้ว';
			window.location.reload();
		} catch (error) {
			status.textContent = error.message; button.disabled = false;
		}
	});
	var legacyForm = document.getElementById('aurum-legacy-apply');
	if (legacyForm) legacyForm.addEventListener('submit', async function (event) {
		event.preventDefault();
		var button = legacyForm.querySelector('[type=submit]');
		var status = document.getElementById('aurum-legacy-progress');
		button.disabled = true;
		try {
			var finished = false;
			while (!finished) {
				var data = new FormData(legacyForm); data.set('ajax', '1');
				var response = await fetch(legacyForm.getAttribute('action'), { method: 'POST', body: data, credentials: 'same-origin' });
				if (!(response.headers.get('content-type') || '').includes('application/json')) throw new Error('ไม่ได้รับผลการย้าย กรุณาตรวจผลและเข้าสู่ระบบใหม่ก่อนลองอีกครั้ง');
				var result = await response.json();
				if (!response.ok || !result.success) throw new Error(result.data && result.data.message || 'ย้ายหมวดไม่สำเร็จ กรุณาตรวจผลก่อนลองใหม่');
				finished = result.data.finished;
				var counts = result.data.counts;
				status.textContent = result.data.processed + ' / ' + result.data.total + ' รายการ · ย้ายแล้ว ' + counts.migrated + ' · ข้าม ' + counts.skipped + ' · ผิดพลาด ' + counts.error;
			}
			button.textContent = 'ย้ายข้อมูลครบแล้ว'; button.value = 'ย้ายข้อมูลครบแล้ว';
		} catch (error) {
			status.textContent = error.message; button.disabled = false;
		}
	});
}());
