(function () {
  'use strict';
  var c = window.AurumMeasuredAnalytics;
  if (!c || navigator.doNotTrack === '1' || navigator.globalPrivacyControl) return;
  var visitor;
  try {
    var saved = JSON.parse(localStorage.getItem('aurum-analytics-visitor') || 'null');
    visitor = saved && saved.until > Date.now() ? saved.id : crypto.randomUUID();
    if (!saved || saved.until <= Date.now()) localStorage.setItem('aurum-analytics-visitor', JSON.stringify({id: visitor, until: Date.now() + 30 * 86400000}));
  } catch (_) { return; }
  document.cookie = 'aurum_analytics_visitor=' + visitor + ';path=/;max-age=2592000;SameSite=Lax' + (location.protocol === 'https:' ? ';Secure' : '');
  function send(kind) {
    return fetch(c.endpoint, {method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:kind,postId:c.postId,visitor:visitor})}).then(function(response){if(!response.ok)throw new Error('analytics request failed');return response.json();}).then(function(data){if(kind==='view' && Number.isFinite(data.views)){document.querySelectorAll('[data-aurum-measured-views]').forEach(function(element){element.textContent=Number(data.views).toLocaleString();});}return data;}).catch(function(){return null;});
  }
  var visited=false;
  function visit(){
    if(visited || document.visibilityState!=='visible')return;
    visited=true;
    send('visitor');
    // A view is a visit to the video page, not proof of media playback.
    if(c.postId)send('view').then(function(result){if(!result)visited=false;});
  }
  visit();
  document.addEventListener('visibilitychange',visit);
}());
