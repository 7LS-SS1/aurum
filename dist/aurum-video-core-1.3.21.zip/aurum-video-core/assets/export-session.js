(function () {
 'use strict';
 var panel = document.getElementById('aurum-export-session');
 if (!panel) return;
 var form = panel.closest('form'), prepare = document.getElementById('aurum-export-prepare');
 var summary = document.getElementById('aurum-export-summary'), delivered = document.getElementById('aurum-export-downloaded');
 var prev = document.getElementById('aurum-export-prev'), next = document.getElementById('aurum-export-next');
 var page = form.elements.export_page, count = form.elements.export_count, token = form.elements.export_token;
 var download = form.querySelector('[type=submit]'), session = null, done = new Set(), generation = 0, busy = false;
 function controls() {
  var ready = session && session.ready && session.total > 0 && session.expires * 1000 > Date.now();
  download.disabled = busy || !ready;
  prev.disabled = busy || !ready || Number(page.value) <= 1;
  next.disabled = busy || !ready || Number(page.value) >= session.pages;
  prepare.disabled = busy;
  page.disabled = busy;
  form.querySelectorAll('[name="export_type"],[name="export_category"],[name="export_count"],[name="export_status[]"]').forEach(function (input) { input.disabled = busy; });
 }
 function render() {
  if (session && session.ready) {
   page.max = String(Math.max(1, session.pages));
   page.value = String(Math.min(Math.max(1, Math.floor(Number(page.value) || 1)), Math.max(1, session.pages)));
   var start = session.total ? (Number(page.value) - 1) * Number(count.value) + 1 : 0;
   var end = Math.min(Number(page.value) * Number(count.value), session.total);
   summary.textContent = 'พบ ' + session.total.toLocaleString() + ' วิดีโอ · ' + count.value + ' รายการ/หน้า · ทั้งหมด ' + session.pages + ' หน้า · หน้าปัจจุบัน ' + (session.total ? page.value : '0') + '/' + session.pages + ' · รายการ ' + start + '–' + end;
   delivered.textContent = done.size ? 'ส่งไฟล์ให้เบราว์เซอร์แล้ว ' + done.size + '/' + session.pages + ' หน้า: ' + Array.from(done).sort(function (a,b) { return a-b; }).join(', ') + ' (กรุณาตรวจไฟล์ในโฟลเดอร์ดาวน์โหลด)' : 'ยังไม่ได้ดาวน์โหลดในชุดนี้';
  }
  controls();
 }
 function invalidate() {
  generation++; session = null; token.value = ''; done.clear(); page.value = '1'; page.removeAttribute('max');
  summary.textContent = 'ตัวกรองเปลี่ยน กรุณากดนับวิดีโอและสร้างชุด Export ใหม่'; delivered.textContent = ''; controls();
 }
 form.querySelectorAll('[name="export_type"],[name="export_category"],[name="export_count"],[name="export_status[]"]').forEach(function (input) { input.addEventListener('change', invalidate); input.addEventListener('input', invalidate); });
 page.addEventListener('change', render);
 prev.addEventListener('click', function () { page.value = String(Number(page.value)-1); render(); });
 next.addEventListener('click', function () { page.value = String(Number(page.value)+1); render(); });
 prepare.addEventListener('click', async function () {
  if (!form.reportValidity()) return;
  invalidate(); var run = generation;
  var data = new FormData(form); data.set('action','aurum_core_export_session'); data.set('export_page','1');
  busy = true; controls();
  try {
   do {
    summary.textContent = session ? 'กำลังตรวจ ' + session.processed + '/' + session.candidates + ' รายการ…' : 'กำลังนับและเตรียมรายชื่อวิดีโอ…';
    var response = await fetch(form.getAttribute('action'), { method:'POST', body:data, credentials:'same-origin' });
    if (!(response.headers.get('content-type') || '').includes('application/json')) throw new Error('ไม่ได้รับข้อมูลชุด Export กรุณาตรวจการเข้าสู่ระบบแล้วลองใหม่');
    var result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.data && result.data.message || 'เตรียมชุดไม่สำเร็จ');
    if (run !== generation) return;
    session = result.data; token.value = session.token; data.set('export_token',session.token);
   } while (!session.ready);
  } catch (error) { session = null; token.value = ''; summary.textContent = error.message; }
  finally { busy = false; render(); }
 });
 form.addEventListener('submit', async function (event) {
  event.preventDefault();
  if (!session || !session.ready || busy) return;
  if (session.expires * 1000 <= Date.now()) { invalidate(); summary.textContent = 'ชุด Export หมดอายุ กรุณาสร้างชุดใหม่'; return; }
  if (!form.reportValidity()) return;
  var data = new FormData(form), requestedPage = Number(page.value);
  busy = true; controls();
  try {
   var response = await fetch(form.getAttribute('action'), { method:'POST', body:data, credentials:'same-origin' });
   if (!response.ok || !(response.headers.get('content-type') || '').includes('text/csv')) {
    var html = new DOMParser().parseFromString(await response.text(), 'text/html');
    var message = html.querySelector('.wp-die-message');
    throw new Error(message ? message.textContent.trim() : 'ดาวน์โหลดไม่สำเร็จ กรุณาตรวจการเข้าสู่ระบบหรือสร้างชุดใหม่');
   }
   var blob = await response.blob(), url = URL.createObjectURL(blob), link = document.createElement('a');
   link.href = url; link.download = 'aurum-videos-' + form.elements.export_type.value + '-' + token.value.slice(0,8) + '-page-' + requestedPage + '.csv';
   document.body.appendChild(link); link.click(); link.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 30000);
   done.add(requestedPage); busy = false; render();
  } catch (error) { busy = false; controls(); summary.textContent = error.message; }
 });
 controls();
}());

