<?php
/**
 * Plugin Name: AURUM Video Core
 * Description: AURUM video management, site profiles, safe CSV editing, metadata, playback, diagnostics, and video SEO.
 * Version: 1.3.21
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: 7LS
 * Text Domain: aurum-video-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AURUM_VIDEO_CORE_VERSION', '1.3.21' );
define( 'AURUM_VIDEO_CORE_FILE', __FILE__ );
define( 'AURUM_VIDEO_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'AURUM_VIDEO_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once AURUM_VIDEO_CORE_DIR . 'includes/meta.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/site-profile.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/actor-sync.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/actor-pages.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/player.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/editor-persistence.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/seo.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/audit.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/analytics.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/content-history.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/editorial-workflow.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/csv.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/csv-storage.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/export-session.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/legacy-taxonomy.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/admin.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/admin-navigation.php';
require_once AURUM_VIDEO_CORE_DIR . 'includes/google-head.php';

register_activation_hook( __FILE__, 'aurum_video_core_activate' );
register_deactivation_hook( __FILE__, 'aurum_video_core_deactivate' );

/** Flushes only after the video-sitemap rewrite has been registered. */
function aurum_video_core_activate() {
	aurum_video_core_register_profile();
	aurum_video_core_register_legacy_taxonomies();
	aurum_video_core_register_sitemap_rewrites();
	flush_rewrite_rules();
	update_option( 'aurum_video_core_rewrite_version', '1.3.9', false );
}

/** Removes the plugin's rewrite rules from WordPress's cached rule set. */
function aurum_video_core_deactivate() {
	flush_rewrite_rules();
}
