<?php
/** Admin navigation only; preserve all registered screens and content contracts. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function aurum_video_core_library_url() {
 return admin_url( 'edit.php' . ( post_type_exists( 'video' ) ? '?post_type=video' : '' ) );
}
function aurum_video_core_navigation() {
 if ( ! current_user_can( 'manage_options' ) ) { return; }
 global $submenu;
 add_submenu_page( 'aurum-video-core', 'นักแสดงและหมวดหมู่', 'นักแสดง / หมวดหมู่', 'manage_options', 'aurum-library', 'aurum_video_core_library_page' );
 add_submenu_page( 'aurum-video-core', 'ตั้งค่าและเครื่องมือ', 'ตั้งค่า', 'manage_options', 'aurum-settings', 'aurum_video_core_settings_page' );
 $video = get_post_type_object( 'video' );
 if ( $video && $video->show_ui ) {
  add_submenu_page( 'aurum-video-core', 'วิดีโอทั้งหมด', 'วิดีโอ', $video->cap->edit_posts, 'edit.php?post_type=video' );
  remove_menu_page( 'edit.php?post_type=video' );
 }
 foreach ( array( 'aurum-profile', 'aurum-history', 'aurum-legacy-taxonomy', 'aurum-google-head', 'edit.php?post_type=aurum_actor' ) as $slug ) { remove_submenu_page( 'aurum-video-core', $slug ); }
 if ( $video && $video->show_ui ) { remove_submenu_page( 'aurum-video-core', 'aurum-videos' ); }
 // Hidden screens need an admin_page hook after removal from the visible parent.
 $hidden = array( 'aurum-profile' => 'aurum_video_core_admin_profile', 'aurum-history' => 'aurum_video_core_admin_history', 'aurum-legacy-taxonomy' => 'aurum_video_core_admin_legacy_taxonomy', 'aurum-google-head' => 'aurum_video_core_google_head_page' );
 if ( $video && $video->show_ui ) { $hidden['aurum-videos'] = 'aurum_video_core_admin_videos'; }
 foreach ( $hidden as $slug => $callback ) { add_submenu_page( '', 'AURUM', 'AURUM', 'manage_options', $slug, $callback ); }
 $order = array( 'aurum-video-core', $video && $video->show_ui ? 'edit.php?post_type=video' : 'aurum-videos', 'aurum-editorial', 'aurum-csv', 'aurum-library', 'aurum-settings' );
 if ( isset( $submenu['aurum-video-core'] ) ) {
  usort( $submenu['aurum-video-core'], function ( $a, $b ) use ( $order ) {
   $left = array_search( $a[2], $order, true ); $right = array_search( $b[2], $order, true );
   return ( false === $left ? 99 : $left ) <=> ( false === $right ? 99 : $right );
  } );
 }
}
add_action( 'admin_menu', 'aurum_video_core_navigation', 999 );
function aurum_video_core_navigation_parent( $parent ) {
 if ( ! current_user_can( 'manage_options' ) ) { return $parent; }
 $screen = get_current_screen();
 if ( isset( $_GET['page'] ) && in_array( $_GET['page'], array( 'aurum-profile', 'aurum-history', 'aurum-legacy-taxonomy', 'aurum-google-head', 'aurum-videos' ), true ) ) { return 'aurum-video-core'; }
 if ( $screen && in_array( $screen->post_type, array( 'video', 'aurum_actor' ), true ) ) { return 'aurum-video-core'; }
 return $parent;
}
add_filter( 'parent_file', 'aurum_video_core_navigation_parent' );
function aurum_video_core_navigation_child( $child ) {
 if ( ! current_user_can( 'manage_options' ) ) { return $child; }
 $screen = get_current_screen(); $page = isset( $_GET['page'] ) && is_string( $_GET['page'] ) ? $_GET['page'] : '';
 if ( in_array( $page, array( 'aurum-profile', 'aurum-history', 'aurum-legacy-taxonomy', 'aurum-google-head' ), true ) ) { return 'aurum-settings'; }
 if ( $screen && ( 'aurum_actor' === $screen->post_type || ( 'video' === $screen->post_type && 'edit-tags' === $screen->base ) ) ) { return 'aurum-library'; }
 if ( $screen && 'video' === $screen->post_type ) { return 'edit.php?post_type=video'; }
 return $child;
}
add_filter( 'submenu_file', 'aurum_video_core_navigation_child' );
function aurum_video_core_action_card( $title, $description, $url, $icon ) {
 echo '<a class="aurum-action-card" href="' . esc_url( $url ) . '"><span class="dashicons ' . esc_attr( $icon ) . '" aria-hidden="true"></span><span><strong>' . esc_html( $title ) . '</strong><small>' . esc_html( $description ) . '</small></span><span class="aurum-card-arrow" aria-hidden="true">→</span></a>';
}
function aurum_video_core_settings_page() {
 aurum_video_core_admin_start( 'ตั้งค่าและเครื่องมือ', 'การเชื่อมต่อเว็บไซต์ โค้ด Google และเครื่องมือดูแลข้อมูล' );
 echo '<div class="aurum-action-grid">';
 aurum_video_core_action_card( 'การเชื่อมต่อ AURUM', 'เลือกชนิดวิดีโอและโปรไฟล์เว็บไซต์', admin_url( 'admin.php?page=aurum-profile' ), 'dashicons-admin-links' );
 aurum_video_core_action_card( 'Google และโค้ด Head', 'แท็กยืนยันเว็บไซต์และโค้ด Analytics', admin_url( 'admin.php?page=aurum-google-head' ), 'dashicons-chart-area' );
 aurum_video_core_action_card( 'ประวัติรับข้อมูล', 'ตรวจรายการรับข้อมูลและผลการทำงานล่าสุด', admin_url( 'admin.php?page=aurum-history' ), 'dashicons-backup' );
 echo '</div><details class="aurum-core-panel aurum-tool-details"><summary>เครื่องมือขั้นสูง</summary><p>ใช้เมื่อต้องการจัดระเบียบวิดีโอเดิม ควรตรวจตัวอย่างและสำรองข้อมูลก่อนดำเนินการ</p>';
 aurum_video_core_action_card( 'ย้ายหมวดวิดีโอเก่า', 'ตรวจตัวอย่างก่อนย้ายหมวดหรือชนิดโพสต์', admin_url( 'admin.php?page=aurum-legacy-taxonomy' ), 'dashicons-category' );
 echo '</details></div>';
}
function aurum_video_core_library_page() {
 aurum_video_core_admin_start( 'นักแสดงและหมวดหมู่', 'จัดการข้อมูลประกอบวิดีโอจากจุดเดียว' );
 echo '<div class="aurum-action-grid">';
 if ( post_type_exists( 'aurum_actor' ) ) { aurum_video_core_action_card( 'โปรไฟล์นักแสดง AURUM', 'ข้อมูลนักแสดงที่รับจาก AURUM', admin_url( 'edit.php?post_type=aurum_actor' ), 'dashicons-groups' ); }
 $type = post_type_exists( 'video' ) ? 'video' : 'post';
 foreach ( get_object_taxonomies( $type, 'objects' ) as $taxonomy ) {
  if ( ! $taxonomy->show_ui || ! current_user_can( $taxonomy->cap->manage_terms ) ) { continue; }
  aurum_video_core_action_card( $taxonomy->labels->name, 'จัดการรายการที่ใช้จัดกลุ่มวิดีโอ', admin_url( 'edit-tags.php?taxonomy=' . $taxonomy->name . '&post_type=' . $type ), 'dashicons-category' );
 }
 echo '</div></div>';
}
function aurum_video_core_dashboard() {
 aurum_video_core_admin_start( 'ภาพรวม', 'คลิปใหม่ สถานะหลัง Import และเครื่องมือสำหรับทำงานวันนี้' );
 echo '<div class="aurum-workflow-banner"><span>ขั้นตอนทำงาน</span><strong>รับคลิปเป็น Draft <b>→</b> แก้ข้อมูลผ่าน CSV <b>→</b> Import <b>→</b> Pending / Public</strong><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=aurum-editorial&stage=needs_title' ) ) . '">ดูสถานะคลิป</a></div><div class="aurum-core-cards aurum-dashboard-counts">';
 foreach ( array( 'needs_title' => array( 'คลิปใหม่รอแก้ชื่อ', 'draft' ), 'publish' => array( 'เผยแพร่หลัง Import', 'publish' ), 'pending' => array( 'ส่ง Pending แล้ว', 'pending' ) ) as $stage => $item ) {
  $query = aurum_video_core_managed_query( array( 'fields' => 'ids', 'posts_per_page' => 1, 'post_status' => $item[1], 'meta_query' => array( array( 'key' => '_aurum_editorial_stage', 'value' => $stage ) ) ) );
  echo '<a class="aurum-core-card" href="' . esc_url( admin_url( 'admin.php?page=aurum-editorial&stage=' . $stage ) ) . '"><span>' . esc_html( $item[0] ) . '</span><strong>' . esc_html( number_format_i18n( $query->found_posts ) ) . '</strong><small>ดูรายการ →</small></a>';
 }
 echo '</div><h2 class="aurum-section-heading">เครื่องมือหลัก</h2><div class="aurum-action-grid">';
 aurum_video_core_action_card( 'วิดีโอทั้งหมด', 'ค้นหา แก้ไข และจัดการสถานะวิดีโอ', aurum_video_core_library_url(), 'dashicons-video-alt3' );
 aurum_video_core_action_card( 'นำเข้า / ส่งออก CSV', 'แก้ข้อมูลหลายคลิป พร้อมตรวจตัวอย่างก่อนบันทึก', admin_url( 'admin.php?page=aurum-csv' ), 'dashicons-media-spreadsheet' );
 aurum_video_core_action_card( 'นักแสดงและหมวดหมู่', 'จัดระเบียบข้อมูลประกอบวิดีโอ', admin_url( 'admin.php?page=aurum-library' ), 'dashicons-groups' );
 aurum_video_core_action_card( 'ตั้งค่าเว็บไซต์', 'การเชื่อมต่อ Google และเครื่องมือขั้นสูง', admin_url( 'admin.php?page=aurum-settings' ), 'dashicons-admin-settings' );
 echo '</div><details class="aurum-core-panel aurum-tool-details"><summary>สถานะการเชื่อมต่อ</summary>';
 $profile = aurum_video_core_profile(); $diagnostics = aurum_video_core_diagnostics()->get_data();
 echo '<p>การรับข้อมูล: <strong>' . ( $profile['ready'] && $diagnostics['ready'] ? 'พร้อมใช้งาน' : 'ควรตรวจสอบการตั้งค่า' ) . '</strong> · เวอร์ชัน ' . esc_html( AURUM_VIDEO_CORE_VERSION ) . '</p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=aurum-profile' ) ) . '">ดูการเชื่อมต่อ</a></details></div>';
}
