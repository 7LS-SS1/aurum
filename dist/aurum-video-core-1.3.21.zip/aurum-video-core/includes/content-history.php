<?php
/** Persistent title/body history; never infer an original from legacy content. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function aurum_video_core_content_values( $post ) {
 return array( 'title' => $post->post_title, 'content' => $post->post_content );
}
function aurum_video_core_content_source() {
 if ( ! empty( $GLOBALS['aurum_content_request'] ) ) { return $GLOBALS['aurum_content_request']; }
 $action = isset( $_POST['action'] ) && is_string( $_POST['action'] ) ? sanitize_key( $_POST['action'] ) : '';
 return array( 'source' => false !== strpos( $action, 'aurum_core_csv' ) ? 'csv' : ( is_admin() ? 'wordpress_admin' : 'wordpress' ), 'request_id' => '' );
}
function aurum_video_core_content_request_start( $response, $handler, $request ) {
 $GLOBALS['aurum_content_request_stack'][] = $GLOBALS['aurum_content_request'] ?? null;
 // Informational provenance of an authenticated request, never an authorization mechanism.
 $push = 'aurum' === $request->get_header( 'x-aurum-source' );
 $GLOBALS['aurum_content_request'] = array( 'source' => $push ? 'aurum_push' : 'rest_api', 'request_id' => $push ? substr( sanitize_text_field( $request->get_header( 'x-aurum-request-id' ) ), 0, 100 ) : '' );
 return $response;
}
add_filter( 'rest_request_before_callbacks', 'aurum_video_core_content_request_start', 10, 3 );
function aurum_video_core_content_request_end( $response ) {
 $GLOBALS['aurum_content_request'] = ! empty( $GLOBALS['aurum_content_request_stack'] ) ? array_pop( $GLOBALS['aurum_content_request_stack'] ) : null;
 return $response;
}
add_filter( 'rest_request_after_callbacks', 'aurum_video_core_content_request_end' );
function aurum_video_core_content_received( $post, $request, $creating ) {
 if ( ! $creating || ! get_post_meta( $post->ID, 'aurum_movie_id', true ) ) { return; }
 $post = get_post( $post->ID );
 $baseline = array_merge( aurum_video_core_content_source(), array( 'values' => aurum_video_core_content_values( $post ), 'received_at' => gmdate( 'c' ) ) );
 add_post_meta( $post->ID, '_aurum_content_baseline', wp_slash( $baseline ), true );
}
function aurum_video_core_content_updated( $id, $after, $before ) {
 if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ! get_post_meta( $id, 'aurum_movie_id', true ) ) { return; }
 $changed = array();
 foreach ( array( 'title' => 'post_title', 'content' => 'post_content' ) as $field => $property ) {
  if ( $before->$property !== $after->$property ) { $changed[] = $field; }
 }
 if ( ! $changed ) { return; }
 $event = array_merge( aurum_video_core_content_source(), array( 'at' => gmdate( 'c' ), 'user_id' => get_current_user_id(), 'fields' => $changed ) );
 add_post_meta( $id, '_aurum_content_first_change', $event, true );
 update_post_meta( $id, '_aurum_content_last_change', $event );
 foreach ( $changed as $field ) { add_post_meta( $id, '_aurum_content_changed_' . $field, $event, true ); }
}
add_action( 'post_updated', 'aurum_video_core_content_updated', 10, 3 );
function aurum_video_core_register_content_history() {
 foreach ( aurum_video_core_post_types() as $type ) { add_action( 'rest_after_insert_' . $type, 'aurum_video_core_content_received', 100, 3 ); }
}
add_action( 'init', 'aurum_video_core_register_content_history', 120 );
function aurum_video_core_content_history( $id ) {
 $baseline = get_post_meta( $id, '_aurum_content_baseline', true );
 $first = get_post_meta( $id, '_aurum_content_first_change', true );
 $last = get_post_meta( $id, '_aurum_content_last_change', true );
 $known = is_array( $baseline ) && isset( $baseline['values']['title'], $baseline['values']['content'] );
 $current = aurum_video_core_content_values( get_post( $id ) );
 $different = $known && $current !== $baseline['values'];
 return array(
  'content_history' => $first || $different ? 'changed' : ( $known ? 'untouched' : 'unknown' ),
  'baseline_available' => $known ? 'yes' : 'no',
  'differs_from_original' => $known ? ( $different ? 'yes' : 'no' ) : 'unknown',
  'title_ever_changed' => get_post_meta( $id, '_aurum_content_changed_title', true ) || ( $known && $current['title'] !== $baseline['values']['title'] ) ? 'yes' : ( $known ? 'no' : 'unknown' ),
  'content_ever_changed' => get_post_meta( $id, '_aurum_content_changed_content', true ) || ( $known && $current['content'] !== $baseline['values']['content'] ) ? 'yes' : ( $known ? 'no' : 'unknown' ),
  'first_content_change_at' => $first['at'] ?? '',
  'last_content_change_at' => $last['at'] ?? '',
  'last_content_change_source' => $last['source'] ?? '',
 );
}
