<?php
/** CSV byte limit and chunked preview storage (backward compatible with small previews). */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function aurum_video_core_csv_max_bytes() { return 64 * 1024 * 1024; }
function aurum_video_core_csv_memory() {
 // Request-local admin memory allowance. Hosting policy may still impose a lower ceiling.
 $filter = function ( $limit ) { return -1 === wp_convert_hr_to_bytes( $limit ) || wp_convert_hr_to_bytes( $limit ) >= 512 * 1024 * 1024 ? $limit : '512M'; };
 add_filter( 'admin_memory_limit', $filter ); wp_raise_memory_limit( 'admin' ); remove_filter( 'admin_memory_limit', $filter );
}
function aurum_video_core_csv_stage_load( $key ) {
 $stored = get_transient( $key );
 if ( ! is_array( $stored ) || empty( $stored['csv_chunks'] ) ) { return $stored; }
 aurum_video_core_csv_memory();
 $data = '';
 for ( $i = 0; $i < $stored['csv_chunks']; $i++ ) {
  $part = get_transient( $stored['prefix'] . '_' . $i );
  if ( ! is_string( $part ) ) { return false; }
  $part = base64_decode( $part, true );
  if ( false === $part ) { return false; }
  $data .= $part;
 }
 if ( ! hash_equals( $stored['sha256'], hash( 'sha256', $data ) ) ) { return false; }
 return unserialize( $data, array( 'allowed_classes' => false ) );
}
function aurum_video_core_csv_stage_save( $key, $stage, $ttl ) {
 aurum_video_core_csv_memory();
 $old = get_transient( $key ); $data = serialize( $stage );
 if ( strlen( $data ) <= 1024 * 1024 ) {
  set_transient( $key, $stage, $ttl );
  $ok = get_transient( $key ) === $stage;
 } else {
  $prefix = $key . '_' . bin2hex( random_bytes( 8 ) );
  $count = (int) ceil( strlen( $data ) / ( 1024 * 1024 ) );
  for ( $i = 0; $i < $count; $i++ ) {
   if ( ! set_transient( $prefix . '_' . $i, base64_encode( substr( $data, $i * 1024 * 1024, 1024 * 1024 ) ), $ttl ) ) {
    for ( $j = 0; $j <= $i; $j++ ) { delete_transient( $prefix . '_' . $j ); }
    return false;
   }
  }
  $manifest = array( 'csv_chunks' => $count, 'prefix' => $prefix, 'sha256' => hash( 'sha256', $data ) );
  set_transient( $key, $manifest, $ttl ); $ok = get_transient( $key ) === $manifest;
  if ( ! $ok ) { for ( $i = 0; $i < $count; $i++ ) { delete_transient( $prefix . '_' . $i ); } }
 }
 if ( $ok && is_array( $old ) && ! empty( $old['csv_chunks'] ) ) {
  for ( $i = 0; $i < $old['csv_chunks']; $i++ ) { delete_transient( $old['prefix'] . '_' . $i ); }
 }
 return $ok;
}
