<?php
/** New AURUM posts: draft -> CSV rename -> CSV import -> configured status. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function aurum_video_core_editorial_gate( $prepared, $request ) {
 if ( is_wp_error( $prepared ) ) { return $prepared; }
 $id = absint( $request['id'] ?? 0 ); $meta = $request->get_param( 'meta' );
 if ( ! $id && is_array( $meta ) && ! empty( $meta['aurum_movie_id'] ) ) { $prepared->post_status = 'draft'; }
 elseif ( $id && get_post_meta( $id, '_aurum_editorial_stage', true ) ) {
  // REST updates cannot bypass the CSV import for enrolled drafts.
  $status = get_post_status( $id );
  if ( 'draft' === $status ) { $prepared->post_status = 'draft'; }
  if ( 'pending' === $status && ( 'aurum' === $request->get_header( 'x-aurum-source' ) || ( is_array( $meta ) && ! empty( $meta['aurum_movie_id'] ) ) ) ) { $prepared->post_status = 'pending'; }
 }
 return $prepared;
}
function aurum_video_core_editorial_received( $post, $request, $creating ) {
 if ( $creating && 'draft' === get_post_status( $post->ID ) && get_post_meta( $post->ID, 'aurum_movie_id', true ) ) {
  add_post_meta( $post->ID, '_aurum_editorial_stage', 'needs_title', true );
 }
}
function aurum_video_core_editorial_register() {
 foreach ( aurum_video_core_post_types() as $type ) {
  add_filter( 'rest_pre_insert_' . $type, 'aurum_video_core_editorial_gate', 100, 2 );
  add_action( 'rest_after_insert_' . $type, 'aurum_video_core_editorial_received', 110, 3 );
 }
}
add_action( 'init', 'aurum_video_core_editorial_register', 120 );
function aurum_video_core_import_status() {
 $status = get_option( 'aurum_video_core_import_status', 'pending' );
 return in_array( $status, array( 'pending', 'publish' ), true ) ? $status : 'pending';
}
function aurum_video_core_import_label( $status ) { return 'publish' === $status ? 'เผยแพร่ (Public)' : 'รอตรวจ (Pending)'; }
function aurum_video_core_import_settings_form() {
 echo '<section class="aurum-core-panel"><h2>สถานะหลัง Import</h2>';
 aurum_video_core_admin_form( 'aurum_import_settings' );
 echo '<label for="aurum-import-status">เมื่อบันทึกแถวที่แก้ไขสำเร็จ ให้เปลี่ยนเป็น</label> <select id="aurum-import-status" name="import_status">';
 foreach ( array( 'pending', 'publish' ) as $status ) { echo '<option value="' . esc_attr( $status ) . '"' . selected( aurum_video_core_import_status(), $status, false ) . '>' . esc_html( aurum_video_core_import_label( $status ) ) . '</option>'; }
 echo '</select><p class="description">มีผลกับคลิปที่เปลี่ยนข้อมูลจริงผ่าน CSV รวมคลิปเก่าและคลิปที่เผยแพร่แล้ว แถวที่ไม่เปลี่ยนหรือผิดพลาดจะคงสถานะเดิม หากเลือก Public คลิปจะเผยแพร่ทันทีหลังบันทึกสำเร็จ</p>';
 submit_button( 'บันทึกสถานะหลัง Import', 'secondary', 'submit', false ); echo '</form></section>';
}
function aurum_video_core_import_settings_save() {
 aurum_video_core_admin_guard( 'aurum_import_settings' );
 $status = $_POST['import_status'] ?? '';
 if ( ! in_array( $status, array( 'pending', 'publish' ), true ) ) { wp_die( 'สถานะไม่ถูกต้อง' ); }
 update_option( 'aurum_video_core_import_status', $status, false );
 wp_safe_redirect( admin_url( 'admin.php?page=aurum-csv&saved=1' ) ); exit;
}
add_action( 'admin_post_aurum_import_settings', 'aurum_video_core_import_settings_save' );
/** Called only after a changed row has passed verification, inside its transaction. */
function aurum_video_core_editorial_csv( $id, $plan, $target ) {
 if ( ! in_array( $target, array( 'pending', 'publish' ), true ) ) { throw new RuntimeException( 'invalid_import_status' ); }
 $type = get_post_type_object( get_post_type( $id ) );
 if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_post', $id ) || ( 'publish' === $target && ! current_user_can( $type->cap->publish_posts ) ) ) { throw new RuntimeException( 'import_status_forbidden' ); }
 $result = wp_update_post( array( 'ID' => $id, 'post_status' => $target ), true );
 if ( is_wp_error( $result ) || get_post_status( $id ) !== $target ) { throw new RuntimeException( 'import_status_failed' ); }
 update_post_meta( $id, '_aurum_editorial_stage', $target );
 update_post_meta( $id, '_aurum_editorial_import', array( 'at' => gmdate( 'c' ), 'user_id' => get_current_user_id(), 'status' => $target ) );
}
function aurum_video_core_editorial_matches( $id, $type ) {
 return 'draft' === get_post_status( $id ) && ( 'workflow_new' === $type ? 'needs_title' : 'review' ) === get_post_meta( $id, '_aurum_editorial_stage', true );
}
function aurum_video_core_editorial_menu() {
 add_submenu_page( 'aurum-video-core', 'สถานะคลิป', 'สถานะคลิป', 'manage_options', 'aurum-editorial', 'aurum_video_core_editorial_page' );
}
add_action( 'admin_menu', 'aurum_video_core_editorial_menu', 20 );
function aurum_video_core_editorial_page() {
 aurum_video_core_admin_start( 'สถานะคลิป', 'รับเป็น Draft → แก้ข้อมูลผ่าน CSV → Import แล้วเปลี่ยนสถานะอัตโนมัติ' );
 $stage = in_array( $_GET['stage'] ?? '', array( 'needs_title', 'review', 'pending', 'publish' ), true ) ? $_GET['stage'] : 'needs_title';
 echo '<section class="aurum-core-panel"><p>';
 foreach ( array( 'needs_title' => 'คลิปใหม่รอแก้ชื่อ', 'review' => 'Draft จากระบบเดิม', 'pending' => 'Pending', 'publish' => 'เผยแพร่แล้ว' ) as $value => $label ) {
  echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=aurum-editorial&stage=' . $value ) ) . '">' . esc_html( $label ) . '</a> ';
 }
 echo '</p><p><a href="' . esc_url( admin_url( 'admin.php?page=aurum-csv' ) ) . '">เปิด Export แล้วเลือก “คลิปใหม่รอแก้ชื่อ”</a> · คลิปเก่าก่อนเปิดใช้ขั้นตอนนี้ไม่ถูกนำเข้าคิวอัตโนมัติ</p>';
 $page = max( 1, absint( $_GET['paged'] ?? 1 ) );
 $query = aurum_video_core_managed_query( array( 'post_status' => in_array( $stage, array( 'pending', 'publish' ), true ) ? $stage : 'draft', 'posts_per_page' => 20, 'paged' => $page, 'meta_query' => array( array( 'key' => '_aurum_editorial_stage', 'value' => $stage ) ) ) );
 foreach ( $query->posts as $post ) {
  $baseline = get_post_meta( $post->ID, '_aurum_content_baseline', true );
  echo '<article class="aurum-core-panel"><h2>#' . (int) $post->ID . ' ' . esc_html( $post->post_title ) . '</h2><p><strong>ชื่อเมื่อรับเข้า:</strong> ' . esc_html( $baseline['values']['title'] ?? '' ) . '</p><p><strong>เนื้อหาปัจจุบัน:</strong> ' . esc_html( mb_substr( wp_strip_all_tags( $post->post_content ), 0, 1200 ) ) . '</p><p><a class="button" target="_blank" rel="noopener" href="' . esc_url( get_preview_post_link( $post ) ) . '">เปิดดูคลิปและเนื้อหาทั้งหมด</a> <a class="button" href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">แก้ไขใน WordPress</a></p>';
  if ( 'review' === $stage ) { echo '<p>คลิปจากระบบเดิมยังเป็น Draft: Export และ Import แถวที่แก้ไขเพื่อใช้สถานะใหม่ หรือเปลี่ยนสถานะผ่าน WordPress</p>'; }
  echo '</article>';
 }
 if ( ! $query->posts ) { echo '<p>ไม่มีคลิปในขั้นตอนนี้</p>'; }
 echo wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'current' => $page, 'total' => $query->max_num_pages ) ) );
 echo '</section></div>';
}

