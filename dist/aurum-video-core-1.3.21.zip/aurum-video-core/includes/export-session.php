<?php
/** User-owned, expiring ID snapshots for paged CSV downloads. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function aurum_video_core_export_key( $token ) {
 return is_string( $token ) && preg_match( '/^[a-f0-9]{32}$/', $token ) ? 'aurum_export_' . get_current_user_id() . '_' . $token : '';
}
function aurum_video_core_export_load( $token ) {
 $key = aurum_video_core_export_key( $token );
 $state = $key ? get_transient( $key ) : false;
 return is_array( $state ) && $state['expires'] > time() ? $state : new WP_Error( 'expired', 'ชุด Export หมดอายุหรือไม่ใช่ของบัญชีนี้ กรุณาสร้างชุดใหม่' );
}
function aurum_video_core_export_begin( $filters ) {
 $args = array( 'post_status' => $filters['statuses'], 'fields' => 'ids', 'posts_per_page' => 100001, 'no_found_rows' => true,
  'meta_query' => array( array( 'key' => 'aurum_movie_id', 'value' => '', 'compare' => '!=' ) ),
  'orderby' => 'new' === $filters['type'] ? array( 'date' => 'DESC', 'ID' => 'DESC' ) : 'ID', 'order' => 'DESC' );
 if ( $filters['category'] ) { $args['tax_query'] = array( array( 'taxonomy' => $filters['category']['taxonomy'], 'field' => 'term_id', 'terms' => array( $filters['category']['term_id'] ), 'include_children' => true ) ); }
 $query = aurum_video_core_managed_query( $args );
 if ( count( $query->posts ) > 100000 ) { return new WP_Error( 'too_large', 'พบมากกว่า 100,000 รายการ กรุณาแบ่งตามหมวดหมู่หรือสถานะ ระบบยังไม่สร้างชุด Export' ); }
 $filters['page'] = 1;
 $token = bin2hex( random_bytes( 16 ) );
 $state = array( 'filters' => $filters, 'candidates' => array_map( 'intval', $query->posts ), 'ids' => array(), 'processed' => 0, 'ready' => false, 'expires' => time() + 2 * HOUR_IN_SECONDS );
 if ( ! in_array( $filters['type'], array( 'thin', 'untouched', 'changed', 'unknown', 'workflow_new', 'workflow_review' ), true ) ) { $state['ids'] = $state['candidates']; $state['processed'] = count( $state['candidates'] ); $state['ready'] = true; }
 if ( ! set_transient( aurum_video_core_export_key( $token ), $state, 2 * HOUR_IN_SECONDS ) ) { return new WP_Error( 'storage', 'จัดเก็บชุด Export ไม่สำเร็จ กรุณาลองใหม่' ); }
 return $token;
}
function aurum_video_core_export_step( $token ) {
 $state = aurum_video_core_export_load( $token );
 if ( is_wp_error( $state ) ) { return $state; }
 if ( ! $state['ready'] ) {
  $batch = array_slice( $state['candidates'], $state['processed'], 200 );
  foreach ( $batch as $id ) {
   if ( ! get_post( $id ) ) { return new WP_Error( 'removed', 'มีรายการถูกลบระหว่างเตรียมชุด กรุณาสร้างชุดใหม่' ); }
   $match = 'thin' === $state['filters']['type'] ? aurum_video_core_csv_is_thin_content( $id ) : aurum_video_core_content_history( $id )['content_history'] === $state['filters']['type'];
   if ( in_array( $state['filters']['type'], array( 'workflow_new', 'workflow_review' ), true ) ) { $match = aurum_video_core_editorial_matches( $id, $state['filters']['type'] ); }
   if ( $match ) { $state['ids'][] = $id; }
  }
  $state['processed'] += count( $batch );
  $state['ready'] = $state['processed'] >= count( $state['candidates'] );
  set_transient( aurum_video_core_export_key( $token ), $state, max( 1, $state['expires'] - time() ) );
  $saved = aurum_video_core_export_load( $token );
  if ( is_wp_error( $saved ) || $saved !== $state ) { return new WP_Error( 'storage', 'บันทึกความคืบหน้าชุด Export ไม่สำเร็จ กรุณาสร้างชุดใหม่' ); }
 }
 return array( 'token' => $token, 'ready' => $state['ready'], 'processed' => $state['processed'], 'candidates' => count( $state['candidates'] ), 'total' => count( $state['ids'] ), 'pages' => (int) ceil( count( $state['ids'] ) / $state['filters']['count'] ), 'expires' => $state['expires'] );
}
function aurum_video_core_export_page_ids( $token, $filters ) {
 $state = aurum_video_core_export_load( $token );
 if ( is_wp_error( $state ) ) { return $state; }
 $normalized = $filters; $normalized['page'] = 1;
 if ( ! $state['ready'] || $normalized !== $state['filters'] ) { return new WP_Error( 'changed', 'ตัวกรองเปลี่ยนหรือชุดยังไม่พร้อม กรุณาเตรียมชุด Export ใหม่' ); }
 $pages = (int) ceil( count( $state['ids'] ) / $filters['count'] );
 if ( $filters['page'] < 1 || $filters['page'] > $pages ) { return new WP_Error( 'page', 'เลขหน้าเกินจำนวนหน้าของชุด Export' ); }
 $ids = array_slice( $state['ids'], ( $filters['page'] - 1 ) * $filters['count'], $filters['count'] );
 foreach ( $ids as $id ) {
  if ( ! get_post( $id ) || ! current_user_can( 'edit_post', $id ) || ! get_post_meta( $id, 'aurum_movie_id', true ) ) { return new WP_Error( 'missing', 'มีรายการถูกลบ เปลี่ยนตัวตน หรือไม่มีสิทธิ์เข้าถึง ระบบไม่ข้ามรายการเงียบ ๆ กรุณาสร้างชุดใหม่' ); }
 }
 return $ids;
}
function aurum_video_core_export_session_action() {
 aurum_video_core_admin_guard( 'aurum_core_csv_export' );
 $token = isset( $_POST['export_token'] ) && is_string( $_POST['export_token'] ) ? $_POST['export_token'] : '';
 if ( ! $token ) {
  $filters = aurum_video_core_csv_export_filters( $_POST );
  if ( is_wp_error( $filters ) ) { wp_send_json_error( array( 'message' => $filters->get_error_message() ), 400 ); }
  $token = aurum_video_core_export_begin( $filters );
 }
 $result = is_wp_error( $token ) ? $token : aurum_video_core_export_step( $token );
 if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 ); }
 wp_send_json_success( $result );
}
add_action( 'admin_post_aurum_core_export_session', 'aurum_video_core_export_session_action' );
