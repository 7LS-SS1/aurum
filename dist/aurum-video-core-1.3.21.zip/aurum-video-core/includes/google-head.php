<?php
/** Administrator-managed verification and analytics snippets for the public head. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function aurum_video_core_google_head_settings() {
	$value = get_option( 'aurum_video_core_google_head', array() );
	return wp_parse_args( is_array( $value ) ? $value : array(), array( 'enabled' => false, 'search_console' => '', 'analytics' => '' ) );
}

function aurum_video_core_google_head_menu() {
	add_submenu_page( 'aurum-video-core', 'Google / โค้ด Head', 'Google / โค้ด Head', 'manage_options', 'aurum-google-head', 'aurum_video_core_google_head_page' );
}
add_action( 'admin_menu', 'aurum_video_core_google_head_menu' );

function aurum_video_core_google_head_guard() {
	aurum_video_core_admin_guard();
	if ( ! current_user_can( 'unfiltered_html' ) ) {
		wp_die( 'บัญชีนี้ไม่มีสิทธิ์ใส่ HTML / JavaScript กรุณาใช้บัญชีผู้ดูแลที่มีสิทธิ์ unfiltered_html (สำหรับ Multisite ต้องใช้ Super Admin)', '', array( 'response' => 403 ) );
	}
}

function aurum_video_core_google_head_page() {
	aurum_video_core_google_head_guard();
	aurum_video_core_admin_start( 'Google / โค้ด Head', 'ติดตั้งแท็กยืนยันเว็บไซต์และโค้ดวัดสถิติในส่วน <head> ของเว็บไซต์' );
	$settings = aurum_video_core_google_head_settings();
	echo '<section class="aurum-core-panel">';
	aurum_video_core_admin_form( 'aurum_core_save_google_head' );
	echo '<p><label><input type="checkbox" name="enabled" value="1"' . checked( ! empty( $settings['enabled'] ), true, false ) . '> เปิดใช้งานโค้ดใน Head</label></p>';
	echo '<h2><label for="aurum-search-console">Google Search Console</label></h2><p>วาง HTML tag ที่ Google ให้มา เช่น <code>&lt;meta name="google-site-verification" content="..." /&gt;</code> แล้วกลับไปกดยืนยันใน Search Console ใช้สำหรับพร็อพเพอร์ตีแบบ URL-prefix; แบบ Domain ต้องยืนยันผ่าน DNS</p>';
	echo '<textarea class="large-text code" id="aurum-search-console" name="search_console" rows="5" spellcheck="false" dir="ltr">' . esc_textarea( $settings['search_console'] ) . '</textarea>';
	echo '<h2><label for="aurum-analytics">Google Analytics / HTML ใน Head</label></h2><p>วางโค้ด Google tag (GA4) ทั้งชุด รวมแท็ก <code>&lt;script&gt;</code> โดยไม่ต้องใส่ <code>&lt;html&gt;</code> หรือ <code>&lt;head&gt;</code> ครอบ หลีกเลี่ยงการติดตั้งแท็กเดียวกันซ้ำกับธีมหรือปลั๊กอินอื่น</p>';
	echo '<textarea class="large-text code" id="aurum-analytics" name="analytics" rows="14" spellcheck="false" dir="ltr">' . esc_textarea( $settings['analytics'] ) . '</textarea>';
	echo '<p class="description">โค้ดจะทำงานตามที่วางไว้ในหน้าเว็บไซต์ทุกหน้าที่ธีมเรียก wp_head ไม่แสดงในหน้าผู้ดูแล การบันทึกไม่ได้ยืนยันสถานะกับ Google และไม่ได้ดึงรายงานสถิติมาแสดง หากใช้แคช ให้ล้างแคชหลังแก้ไข</p>';
	submit_button( 'บันทึกโค้ด' );
	echo '</form></section></div>';
}

function aurum_video_core_save_google_head() {
	aurum_video_core_google_head_guard();
	check_admin_referer( 'aurum_core_save_google_head' );
	$settings = array( 'enabled' => isset( $_POST['enabled'] ) && '1' === $_POST['enabled'] );
	foreach ( array( 'search_console', 'analytics' ) as $field ) {
		if ( ! isset( $_POST[ $field ] ) || ! is_string( $_POST[ $field ] ) ) {
			wp_die( 'ข้อมูลโค้ดไม่ครบหรือรูปแบบไม่ถูกต้อง กรุณาโหลดหน้าใหม่แล้วลองอีกครั้ง', '', array( 'response' => 400 ) );
		}
		// Raw scripts are intentional: both manage_options and unfiltered_html are required above.
		$settings[ $field ] = wp_unslash( $_POST[ $field ] );
	}
	update_option( 'aurum_video_core_google_head', $settings, false );
	wp_safe_redirect( admin_url( 'admin.php?page=aurum-google-head&saved=1' ) );
	exit;
}
add_action( 'admin_post_aurum_core_save_google_head', 'aurum_video_core_save_google_head' );

function aurum_video_core_render_google_head() {
	if ( is_admin() || is_feed() || is_embed() ) { return; }
	$settings = aurum_video_core_google_head_settings();
	if ( empty( $settings['enabled'] ) ) { return; }
	foreach ( array( 'search_console', 'analytics' ) as $field ) {
		if ( is_string( $settings[ $field ] ) && '' !== trim( $settings[ $field ] ) ) {
			// Deliberately unescaped HTML saved only by an authorized, nonce-checked administrator.
			echo "\n" . $settings[ $field ] . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}
add_action( 'wp_head', 'aurum_video_core_render_google_head', 2 );
