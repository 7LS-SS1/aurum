<?php
/** Safely bridge legacy video posts from category to video_category. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function aurum_video_core_legacy_mappings() {
	$mappings = get_option( 'aurum_video_core_legacy_taxonomy_mappings', array() );
	return is_array( $mappings ) ? $mappings : array();
}

/** A saved mapping also tells WordPress that legacy posts may use video_category. */
function aurum_video_core_register_legacy_taxonomies() {
	foreach ( aurum_video_core_legacy_mappings() as $mapping ) {
		$mode = sanitize_key( $mapping['mode'] ?? 'taxonomy_only' );
		if ( 'convert_post_type' === $mode ) { continue; }
		$taxonomy = sanitize_key( $mapping['target_taxonomy'] ?? '' );
		if ( $taxonomy && taxonomy_exists( $taxonomy ) ) {
			register_taxonomy_for_object_type( $taxonomy, 'post' );
		}
	}
}
add_action( 'init', 'aurum_video_core_register_legacy_taxonomies', 40 );

function aurum_video_core_is_legacy_video_post( $post_id ) {
	$post = get_post( $post_id );
	if ( ! $post || 'post' !== $post->post_type ) { return false; }
	$kind = sanitize_key( (string) get_post_meta( $post_id, '_av123_content_kind', true ) );
	if ( 'article' === $kind ) { return false; }
	foreach ( array( 'aurum_movie_id', '_sevenls_vp_external_id' ) as $key ) {
		if ( '' !== trim( (string) get_post_meta( $post_id, $key, true ) ) ) { return true; }
	}
	foreach ( array( 'aurum_video_url', 'video_url', '_sevenls_vp_playback_url', '_sevenls_vp_video_url', '_misiav_video_url', 'aurum_iframe_url', 'iframe_url' ) as $key ) {
		if ( '' !== trim( (string) get_post_meta( $post_id, $key, true ) ) ) { return true; }
	}
	return false;
}

function aurum_video_core_legacy_candidate_ids( $source_term_id, $include_children = false ) {
	$query = new WP_Query( array(
		'post_type'              => 'post',
		'post_status'            => array( 'publish', 'future', 'draft', 'pending', 'private' ),
		'posts_per_page'         => -1,
		'fields'                 => 'ids',
		'orderby'                => 'ID',
		'order'                  => 'ASC',
		'no_found_rows'          => true,
		'cache_results'          => false,
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
		'tax_query'              => array( array(
			'taxonomy'         => 'category',
			'field'            => 'term_id',
			'terms'            => array( absint( $source_term_id ) ),
			'include_children' => (bool) $include_children,
		) ),
	) );
	return array_values( array_filter( array_map( 'absint', $query->posts ), 'aurum_video_core_is_legacy_video_post' ) );
}

function aurum_video_core_legacy_stage_key( $token ) {
	return preg_match( '/^[a-zA-Z0-9]{32}$/', $token ) ? 'aurum_legacy_' . get_current_user_id() . '_' . $token : '';
}

function aurum_video_core_legacy_has_source_term( $post_id, $source_term_id, $include_children ) {
	if ( has_term( (int) $source_term_id, 'category', $post_id ) ) { return true; }
	if ( ! $include_children ) { return false; }
	$children = get_term_children( (int) $source_term_id, 'category' );
	return ! is_wp_error( $children ) && $children && has_term( array_map( 'absint', $children ), 'category', $post_id );
}

function aurum_video_core_legacy_prepare( $source_term_id, $target_term_id, $include_children = false, $mode = 'taxonomy_only' ) {
	$mode = sanitize_key( $mode );
	if ( ! in_array( $mode, array( 'taxonomy_only', 'convert_post_type' ), true ) ) { return new WP_Error( 'invalid_mode', 'รูปแบบการย้ายไม่ถูกต้อง' ); }
	$source = get_term( absint( $source_term_id ), 'category' );
	$target = get_term( absint( $target_term_id ), 'video_category' );
	if ( ! $source || is_wp_error( $source ) ) { return new WP_Error( 'invalid_source', 'ไม่พบหมวดหมู่บทความต้นทาง' ); }
	if ( ! $target || is_wp_error( $target ) ) { return new WP_Error( 'invalid_target', 'ไม่พบหมวดหมู่วิดีโอ AURUM ปลายทาง' ); }
	$ids = aurum_video_core_legacy_candidate_ids( $source->term_id, $include_children );
	$ready = array(); $already = 0;
	foreach ( $ids as $id ) {
		$has_target = has_term( $target->term_id, 'video_category', $id );
		if ( $has_target ) { ++$already; }
		if ( 'convert_post_type' === $mode || ! $has_target ) { $ready[] = $id; }
	}
	return array(
		'source_taxonomy' => 'category', 'source_term_id' => (int) $source->term_id,
		'target_taxonomy' => 'video_category', 'target_term_id' => (int) $target->term_id,
		'include_children' => (bool) $include_children, 'mode' => $mode, 'ids' => $ready,
		'eligible' => count( $ids ), 'already' => $already, 'cursor' => 0,
		'expires' => time() + 1800, 'counts' => array( 'migrated' => 0, 'skipped' => 0, 'error' => 0 ),
	);
}

function aurum_video_core_add_legacy_mapping( $stage ) {
	$mappings = aurum_video_core_legacy_mappings();
	$key = implode( ':', array( $stage['source_taxonomy'], (int) $stage['source_term_id'], $stage['target_taxonomy'], (int) $stage['target_term_id'] ) );
	$mode = sanitize_key( $stage['mode'] ?? 'taxonomy_only' );
	$mappings[ $key ] = array(
		'source_taxonomy' => 'category', 'source_term_id' => (int) $stage['source_term_id'],
		'target_taxonomy' => 'video_category', 'target_term_id' => (int) $stage['target_term_id'],
		'include_children' => ! empty( $stage['include_children'] ),
		'mode' => $mode, 'completed' => 'taxonomy_only' === $mode || ! empty( $mappings[ $key ]['completed'] ),
		'updated_at' => current_time( 'mysql' ),
	);
	update_option( 'aurum_video_core_legacy_taxonomy_mappings', $mappings, false );
	register_taxonomy_for_object_type( 'video_category', 'post' );
}

function aurum_video_core_complete_legacy_mapping( $stage ) {
	$mappings = aurum_video_core_legacy_mappings();
	$key = implode( ':', array( $stage['source_taxonomy'], (int) $stage['source_term_id'], $stage['target_taxonomy'], (int) $stage['target_term_id'] ) );
	if ( isset( $mappings[ $key ] ) ) {
		$mappings[ $key ]['completed'] = true; $mappings[ $key ]['updated_at'] = current_time( 'mysql' );
		update_option( 'aurum_video_core_legacy_taxonomy_mappings', $mappings, false );
	}
}

function aurum_video_core_legacy_url_path( $url ) {
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	return $path ? '/' . ltrim( user_trailingslashit( untrailingslashit( $path ) ), '/' ) : '';
}

function aurum_video_core_store_legacy_redirect( $old_url, $post_id ) {
	$path = aurum_video_core_legacy_url_path( $old_url );
	if ( ! $path ) { return; }
	$redirects = get_option( 'aurum_video_core_legacy_redirects', array() );
	$redirects = is_array( $redirects ) ? $redirects : array();
	$redirects[ $path ] = absint( $post_id );
	update_option( 'aurum_video_core_legacy_redirects', array_slice( $redirects, -10000, null, true ), false );
}

function aurum_video_core_convert_legacy_post( $post_id, $stage ) {
	$post = get_post( $post_id );
	if ( ! $post || 'post' !== $post->post_type || ! post_type_exists( 'video' ) ) { return 'skipped'; }
	if ( ! aurum_video_core_is_legacy_video_post( $post_id ) || ! aurum_video_core_legacy_has_source_term( $post_id, $stage['source_term_id'], ! empty( $stage['include_children'] ) ) ) { return 'skipped'; }
	$old_url = get_permalink( $post_id );
	$old_categories = wp_get_object_terms( $post_id, 'category', array( 'fields' => 'ids' ) );
	$had_target = has_term( (int) $stage['target_term_id'], 'video_category', $post_id );
	if ( ! $had_target ) {
		$assigned = wp_set_object_terms( $post_id, array( (int) $stage['target_term_id'] ), 'video_category', true );
		if ( is_wp_error( $assigned ) ) { return 'error'; }
	}
	$updated = wp_update_post( array( 'ID' => $post_id, 'post_type' => 'video' ), true );
	if ( is_wp_error( $updated ) ) {
		if ( ! $had_target ) { wp_remove_object_terms( $post_id, array( (int) $stage['target_term_id'] ), 'video_category' ); }
		return 'error';
	}
	update_post_meta( $post_id, '_aurum_legacy_post_type', 'post' );
	update_post_meta( $post_id, '_aurum_legacy_permalink', esc_url_raw( $old_url ) );
	update_post_meta( $post_id, '_aurum_migrated_at', current_time( 'mysql' ) );
	aurum_video_core_store_legacy_redirect( $old_url, $post_id );
	if ( ! is_wp_error( $old_categories ) && $old_categories ) { wp_update_term_count( array_map( 'absint', $old_categories ), 'category' ); }
	clean_post_cache( $post_id );
	aurum_video_core_audit( 'legacy_post_converted', $post_id, array( 'post_type', 'category', 'video_category' ) );
	return 'migrated';
}

/** Preserve individual and archive traffic after post-type conversion. */
function aurum_video_core_legacy_redirects() {
	if ( is_category() ) {
		$source_id = get_queried_object_id();
		foreach ( aurum_video_core_legacy_mappings() as $mapping ) {
			if ( 'convert_post_type' !== ( $mapping['mode'] ?? '' ) || empty( $mapping['completed'] ) || $source_id !== (int) ( $mapping['source_term_id'] ?? 0 ) ) { continue; }
			$url = get_term_link( (int) $mapping['target_term_id'], 'video_category' );
			if ( ! is_wp_error( $url ) ) { wp_safe_redirect( $url, 301, 'AURUM Video Core' ); exit; }
		}
	}
	if ( ! is_404() || ! in_array( strtoupper( $_SERVER['REQUEST_METHOD'] ?? 'GET' ), array( 'GET', 'HEAD' ), true ) ) { return; }
	$path = aurum_video_core_legacy_url_path( home_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ) );
	$redirects = get_option( 'aurum_video_core_legacy_redirects', array() );
	$post_id = is_array( $redirects ) ? absint( $redirects[ $path ] ?? 0 ) : 0;
	if ( $post_id && 'video' === get_post_type( $post_id ) && 'publish' === get_post_status( $post_id ) ) {
		wp_safe_redirect( get_permalink( $post_id ), 301, 'AURUM Video Core' ); exit;
	}
}
add_action( 'template_redirect', 'aurum_video_core_legacy_redirects', 1 );

/** Apply a preview in bounded, replay-safe batches. */
function aurum_video_core_legacy_apply_batch( $token ) {
	$key = aurum_video_core_legacy_stage_key( $token ); $stage = $key ? get_transient( $key ) : false;
	if ( ! current_user_can( 'manage_options' ) || ! $stage || $stage['expires'] < time() ) {
		return new WP_Error( 'preview_expired', 'ตัวอย่างหมดอายุหรือไม่มีสิทธิ์ กรุณาตรวจใหม่' );
	}
	$lock = 'aurum_legacy_lock_' . $token;
	if ( ! add_option( $lock, time(), '', false ) ) { return new WP_Error( 'busy', 'กำลังย้ายข้อมูลชุดนี้อยู่ กรุณารอสักครู่' ); }
	try {
		$stage = get_transient( $key );
		if ( ! $stage || $stage['expires'] < time() ) { return new WP_Error( 'preview_expired', 'ตัวอย่างหมดอายุ กรุณาตรวจใหม่' ); }
		$stage['mode'] = sanitize_key( $stage['mode'] ?? 'taxonomy_only' );
		aurum_video_core_add_legacy_mapping( $stage );
		$end = min( count( $stage['ids'] ), $stage['cursor'] + 25 );
		while ( $stage['cursor'] < $end ) {
			$post_id = absint( $stage['ids'][ $stage['cursor'] ] ); $result = 'skipped';
			if ( 'convert_post_type' === $stage['mode'] ) {
				$result = aurum_video_core_convert_legacy_post( $post_id, $stage );
			} elseif ( aurum_video_core_is_legacy_video_post( $post_id ) && aurum_video_core_legacy_has_source_term( $post_id, $stage['source_term_id'], ! empty( $stage['include_children'] ) ) ) {
				if ( has_term( (int) $stage['target_term_id'], 'video_category', $post_id ) ) { $result = 'skipped'; }
				else {
					$assigned = wp_set_object_terms( $post_id, array( (int) $stage['target_term_id'] ), 'video_category', true );
					$result = is_wp_error( $assigned ) ? 'error' : 'migrated';
					if ( 'migrated' === $result ) { aurum_video_core_audit( 'legacy_category_migrated', $post_id, array( 'category', 'video_category' ) ); }
				}
			}
			++$stage['counts'][ $result ]; ++$stage['cursor'];
		}
		$finished = $stage['cursor'] >= count( $stage['ids'] );
		if ( $finished && 'convert_post_type' === $stage['mode'] && 0 === (int) $stage['counts']['error'] ) { aurum_video_core_complete_legacy_mapping( $stage ); }
		set_transient( $key, $stage, max( 1, $stage['expires'] - time() ) );
		return array( 'processed' => $stage['cursor'], 'total' => count( $stage['ids'] ), 'counts' => $stage['counts'], 'finished' => $finished );
	} finally { delete_option( $lock ); }
}

function aurum_video_core_admin_legacy_taxonomy() {
	aurum_video_core_admin_start( 'ย้ายวิดีโอเก่า', 'ตรวจและย้ายโพสต์วิดีโอเดิมเข้าสู่ CPT video พร้อมเก็บเส้นทางเดิมสำหรับ redirect' );
	$categories = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false ) );
	$targets = taxonomy_exists( 'video_category' ) ? get_terms( array( 'taxonomy' => 'video_category', 'hide_empty' => false ) ) : array();
	echo '<section class="aurum-core-panel"><h2>เลือกต้นทางและปลายทาง</h2><p>ระบบเลือกเฉพาะโพสต์ที่มีรหัสหรือแหล่งเล่นวิดีโอ และตัดรายการที่ระบุว่าเป็นบทความออก ต้องตรวจ Preview ก่อนจึงจะเขียนข้อมูลจริง</p>';
	if ( ! taxonomy_exists( 'video_category' ) ) { echo '<div class="notice notice-error inline"><p>ยังไม่พบ taxonomy <code>video_category</code> กรุณาเลือกโปรไฟล์วิดีโอและบันทึกก่อน</p></div></section></div>'; return; }
	aurum_video_core_admin_form( 'aurum_core_legacy_preview' );
	echo '<table class="form-table"><tr><th><label for="legacy_source">หมวดหมู่บทความต้นทาง</label></th><td><select required id="legacy_source" name="source_term_id"><option value="">เลือก category เดิม</option>';
	foreach ( is_wp_error( $categories ) ? array() : $categories as $term ) { echo '<option value="' . (int) $term->term_id . '">' . esc_html( $term->name . ' — category (' . $term->count . ')' ) . '</option>'; }
	echo '</select></td></tr><tr><th><label for="legacy_target">หมวดหมู่วิดีโอปลายทาง</label></th><td><select required id="legacy_target" name="target_term_id"><option value="">เลือก video_category</option>';
	foreach ( is_wp_error( $targets ) ? array() : $targets as $term ) { echo '<option value="' . (int) $term->term_id . '">' . esc_html( $term->name . ' — video_category (' . $term->count . ')' ) . '</option>'; }
	echo '</select></td></tr><tr><th>รูปแบบการย้าย</th><td><label><input type="radio" name="migration_mode" value="convert_post_type" checked> <strong>ย้ายเป็น CPT video</strong> — URL ใหม่อยู่ใต้ <code>/videos/</code> และ URL เดิมจะ 301 ไปที่ใหม่</label><br><label><input type="radio" name="migration_mode" value="taxonomy_only"> เพิ่ม video_category เท่านั้น — รักษา post type และ URL เดิม</label></td></tr><tr><th>ขอบเขต</th><td><label><input type="checkbox" name="include_children" value="1"> รวมหมวดย่อยของ category ต้นทาง</label><p class="description">ปิดไว้เป็นค่าเริ่มต้นเพื่อไม่ดึงวิดีโอจากหมวดย่อยโดยไม่ตั้งใจ</p></td></tr></table>';
	submit_button( 'ตรวจ Preview', 'primary' ); echo '</form></section>';
	$token = sanitize_text_field( wp_unslash( $_GET['preview'] ?? '' ) ); $key = aurum_video_core_legacy_stage_key( $token ); $stage = $key ? get_transient( $key ) : false;
	if ( $stage && $stage['expires'] >= time() ) {
		$stage['mode'] = sanitize_key( $stage['mode'] ?? 'taxonomy_only' );
		$source = get_term( $stage['source_term_id'], 'category' ); $target = get_term( $stage['target_term_id'], 'video_category' );
		echo '<section class="aurum-core-panel"><h2>Preview ก่อนย้าย</h2><p><strong>' . esc_html( $source ? $source->name : '#' . $stage['source_term_id'] ) . '</strong> — category → <strong>' . esc_html( $target ? $target->name : '#' . $stage['target_term_id'] ) . '</strong> — video_category</p><p><strong>โหมด:</strong> ' . esc_html( 'convert_post_type' === $stage['mode'] ? 'ย้าย post เป็น video พร้อม 301 URL เดิม' : 'เพิ่ม video_category โดยไม่เปลี่ยน post type' ) . '</p>';
		echo '<div class="aurum-preview-stats"><div><strong>' . (int) $stage['eligible'] . '</strong><span>วิดีโอที่ตรวจพบ</span></div><div class="is-change"><strong>' . count( $stage['ids'] ) . '</strong><span>พร้อมย้าย</span></div><div><strong>' . (int) $stage['already'] . '</strong><span>มีหมวดนี้แล้ว</span></div></div>';
		if ( $stage['ids'] ) {
			echo '<div class="aurum-core-table"><table class="widefat striped"><thead><tr><th>ID</th><th>ชื่อ</th><th>สถานะ</th><th>URL เดิม</th><th>ชนิดใหม่</th></tr></thead><tbody>';
			foreach ( array_slice( $stage['ids'], 0, 50 ) as $id ) { $post = get_post( $id ); echo '<tr><td>#' . (int) $id . '</td><td>' . esc_html( $post->post_title ) . '</td><td>' . esc_html( $post->post_status ) . '</td><td><code>' . esc_html( wp_make_link_relative( get_permalink( $id ) ) ) . '</code></td><td>' . esc_html( 'convert_post_type' === $stage['mode'] ? 'video' : 'post' ) . '</td></tr>'; }
			echo '</tbody></table></div>'; if ( count( $stage['ids'] ) > 50 ) { echo '<p class="description">แสดงตัวอย่าง 50 รายการแรกจากทั้งหมด ' . count( $stage['ids'] ) . ' รายการ</p>'; }
		} else { echo '<p>ไม่มีรายการใหม่ที่ต้องเพิ่มหมวด แต่สามารถเปิดการเชื่อมโยงเพื่อให้ Homepage Control อ่านโพสต์เดิมที่มีหมวดนี้แล้วได้</p>'; }
		if ( $stage['eligible'] || $stage['already'] ) {
			echo '<p id="aurum-legacy-progress" role="status" aria-live="polite">ยังไม่ได้ย้ายข้อมูล</p><form id="aurum-legacy-apply" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="aurum_core_legacy_apply"><input type="hidden" name="preview" value="' . esc_attr( $token ) . '">';
			wp_nonce_field( 'aurum_core_legacy_apply' ); submit_button( $stage['ids'] ? ( 'convert_post_type' === $stage['mode'] ? 'ยืนยันและย้ายเป็น video' : 'ยืนยันและเพิ่มหมวดวิดีโอ' ) : 'เปิดการเชื่อมโยงหมวด', 'primary', 'submit', false ); echo '</form>';
		}
		echo '</section>';
	} elseif ( $token ) { echo '<div class="notice notice-warning"><p>Preview หมดอายุหรือไม่พบข้อมูล กรุณาตรวจใหม่</p></div>'; }
	$mappings = aurum_video_core_legacy_mappings();
	if ( $mappings ) { echo '<section class="aurum-core-panel"><h2>การเชื่อมโยงที่เปิดใช้งาน</h2><ul>'; foreach ( $mappings as $mapping ) { $source = get_term( $mapping['source_term_id'], 'category' ); $target = get_term( $mapping['target_term_id'], 'video_category' ); echo '<li>' . esc_html( ( $source ? $source->name : '#' . $mapping['source_term_id'] ) . ' — category → ' . ( $target ? $target->name : '#' . $mapping['target_term_id'] ) . ' — video_category · ' . ( 'convert_post_type' === ( $mapping['mode'] ?? '' ) ? ( ! empty( $mapping['completed'] ) ? 'ย้ายเป็น video ครบแล้ว' : 'กำลังย้ายเป็น video' ) : 'เพิ่ม taxonomy' ) ) . '</li>'; } echo '</ul><p class="description">โหมดแปลง post type จะ redirect archive เดิมเมื่อย้ายครบโดยไม่มีข้อผิดพลาด ส่วนโหมดเพิ่ม taxonomy จะใช้เพื่อให้ Homepage Control อ่าน post และ video ร่วมกัน</p></section>'; }
	echo '</div>';
}

function aurum_video_core_legacy_preview_action() {
	aurum_video_core_admin_guard( 'aurum_core_legacy_preview' );
	$stage = aurum_video_core_legacy_prepare( absint( $_POST['source_term_id'] ?? 0 ), absint( $_POST['target_term_id'] ?? 0 ), ! empty( $_POST['include_children'] ), sanitize_key( $_POST['migration_mode'] ?? 'convert_post_type' ) );
	if ( is_wp_error( $stage ) ) { wp_die( esc_html( $stage->get_error_message() ) ); }
	$token = wp_generate_password( 32, false, false ); set_transient( aurum_video_core_legacy_stage_key( $token ), $stage, 1800 );
	wp_safe_redirect( admin_url( 'admin.php?page=aurum-legacy-taxonomy&preview=' . $token ) ); exit;
}
add_action( 'admin_post_aurum_core_legacy_preview', 'aurum_video_core_legacy_preview_action' );

function aurum_video_core_legacy_apply_action() {
	aurum_video_core_admin_guard( 'aurum_core_legacy_apply' );
	$token = sanitize_text_field( wp_unslash( $_POST['preview'] ?? '' ) ); $result = aurum_video_core_legacy_apply_batch( $token );
	if ( isset( $_POST['ajax'] ) ) {
		if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 409 ); }
		wp_send_json_success( $result );
	}
	if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ) ); }
	wp_safe_redirect( admin_url( 'admin.php?page=aurum-legacy-taxonomy&preview=' . $token ) ); exit;
}
add_action( 'admin_post_aurum_core_legacy_apply', 'aurum_video_core_legacy_apply_action' );
